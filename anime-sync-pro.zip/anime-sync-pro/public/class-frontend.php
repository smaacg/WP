<?php
/**
 * Frontend Controller
 *
 * File: public/class-frontend.php
 * Handles all public-facing behaviour for the anime CPT:
 *   - Enqueue public assets
 *   - Single-anime template override
 *   - JSON-LD structured data (Schema.org TVSeries / Movie)
 *   - Open Graph / Twitter Card meta tags
 *   - SEO: custom title tag, meta description, canonical URL
 *   - Breadcrumb structured data
 *   - Shortcodes: [anime_score], [anime_streaming], [anime_themes]
 *   - REST API endpoint: /wp-json/anime-sync/v1/anime/{id}
 *
 * @package Anime_Sync_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Anime_Sync_Frontend {

    /* ─────────────────────────────────────────────
       Constants
    ───────────────────────────────────────────── */
    const REST_NAMESPACE = 'anime-sync/v1';

    /* ─────────────────────────────────────────────
       Constructor — register all hooks
    ───────────────────────────────────────────── */
    public function __construct() {

        // Assets
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );

        // Template override
        add_filter( 'single_template', [ $this, 'load_single_template' ] );

        // <head> SEO / meta
        add_action( 'wp_head', [ $this, 'output_seo_meta' ],       1  );
        add_action( 'wp_head', [ $this, 'output_json_ld' ],        5  );
        add_filter( 'document_title_parts', [ $this, 'filter_title' ] );

        // Shortcodes
        add_shortcode( 'anime_score',     [ $this, 'shortcode_score'     ] );
        add_shortcode( 'anime_streaming', [ $this, 'shortcode_streaming' ] );
        add_shortcode( 'anime_themes',    [ $this, 'shortcode_themes'    ] );

        // REST API
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );

        // Body class
        add_filter( 'body_class', [ $this, 'add_body_classes' ] );
    }

    /* ═══════════════════════════════════════════════════════════
       1. ASSETS
    ══════════════════════════════════════════════════════════ */

    public function enqueue_assets() {
        if ( ! is_singular( 'anime' ) && ! is_post_type_archive( 'anime' ) ) {
            return;
        }

        wp_enqueue_style(
            'anime-sync-public',
            ANIME_SYNC_PRO_URL . 'public/assets/css/public.css',
            [],
            ANIME_SYNC_PRO_VERSION
        );

        wp_enqueue_script(
            'anime-sync-public',
            ANIME_SYNC_PRO_URL . 'public/assets/js/public.js',
            [ 'jquery' ],
            ANIME_SYNC_PRO_VERSION,
            true
        );

        wp_localize_script( 'anime-sync-public', 'animeSyncPublic', [
            'restUrl'  => esc_url_raw( rest_url( self::REST_NAMESPACE ) ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'postId'   => is_singular( 'anime' ) ? get_the_ID() : 0,
            'i18n'     => [
                'score_na'     => __( '暫無', 'anime-sync-pro' ),
                'loading'      => __( '載入中…', 'anime-sync-pro' ),
                'no_streaming' => __( '目前無已知串流平台資訊。', 'anime-sync-pro' ),
                'no_themes'    => __( '目前無 OP/ED 資訊。', 'anime-sync-pro' ),
            ],
        ] );
    }

    /* ═══════════════════════════════════════════════════════════
       2. TEMPLATE OVERRIDE
    ══════════════════════════════════════════════════════════ */

    /**
     * Use plugin template for single anime if theme doesn't provide one.
     *
     * @param string $template
     * @return string
     */
    public function load_single_template( string $template ): string {
        if ( ! is_singular( 'anime' ) ) {
            return $template;
        }

        // Theme can override by placing single-anime.php in its root
        $theme_template = locate_template( [ 'single-anime.php', 'single.php' ] );
        if ( $theme_template ) {
            return $theme_template;
        }

        $plugin_template = ANIME_SYNC_PRO_DIR . 'public/templates/single-anime.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }

        return $template;
    }

    /* ═══════════════════════════════════════════════════════════
       3. SEO META TAGS
    ══════════════════════════════════════════════════════════ */

    /**
     * Output Open Graph, Twitter Card, and canonical tags.
     * Skips output if an SEO plugin (Yoast / RankMath / AIOSEO) is active.
     */
    public function output_seo_meta() {
        if ( ! is_singular( 'anime' ) ) {
            return;
        }
        // Defer to major SEO plugins
        if (
            defined( 'WPSEO_VERSION' )      ||  // Yoast
            defined( 'RANK_MATH_VERSION' )  ||  // RankMath
            class_exists( 'AIOSEO\Plugin\AIOSEO' )
        ) {
            return;
        }

        $post_id     = get_the_ID();
        $title_cn    = get_post_meta( $post_id, 'anime_title_chinese',  true );
        $title_en    = get_post_meta( $post_id, 'anime_title_english',  true );
        $synopsis    = get_post_meta( $post_id, 'anime_synopsis_chinese', true );
        $cover       = get_post_meta( $post_id, 'anime_cover_image',    true );
        $banner      = get_post_meta( $post_id, 'anime_banner_image',   true );
        $season      = get_post_meta( $post_id, 'anime_season',         true );
        $year        = get_post_meta( $post_id, 'anime_season_year',    true );
        $anilist_id  = get_post_meta( $post_id, 'anime_anilist_id',     true );

        $display_title = $title_cn ?: get_the_title();
        $og_image      = $banner ?: $cover;

        // Build description: first 160 chars of synopsis
        $description = '';
        if ( $synopsis ) {
            $description = mb_substr( wp_strip_all_tags( $synopsis ), 0, 160 );
            if ( mb_strlen( $synopsis ) > 160 ) {
                $description .= '…';
            }
        }

        // Append season / year to title
        $meta_title = $display_title;
        if ( $season && $year ) {
            $season_map = [
                'WINTER' => '冬', 'SPRING' => '春',
                'SUMMER' => '夏', 'FALL'   => '秋',
            ];
            $season_zh  = $season_map[ $season ] ?? $season;
            $meta_title .= ' (' . $year . ' ' . $season_zh . '季)';
        }

        $canonical = get_permalink( $post_id );
        $site_name = get_bloginfo( 'name' );

        ?>
        <!-- Anime Sync Pro SEO -->
        <meta name="description" content="<?php echo esc_attr( $description ); ?>" />
        <link rel="canonical" href="<?php echo esc_url( $canonical ); ?>" />

        <!-- Open Graph -->
        <meta property="og:type"        content="video.tv_show" />
        <meta property="og:title"       content="<?php echo esc_attr( $meta_title ); ?>" />
        <meta property="og:description" content="<?php echo esc_attr( $description ); ?>" />
        <meta property="og:url"         content="<?php echo esc_url( $canonical ); ?>" />
        <meta property="og:site_name"   content="<?php echo esc_attr( $site_name ); ?>" />
        <meta property="og:locale"      content="zh_TW" />
        <?php if ( $og_image ) : ?>
        <meta property="og:image"       content="<?php echo esc_url( $og_image ); ?>" />
        <meta property="og:image:width" content="460" />
        <meta property="og:image:height" content="650" />
        <?php endif; ?>

        <!-- Twitter Card -->
        <meta name="twitter:card"        content="summary_large_image" />
        <meta name="twitter:title"       content="<?php echo esc_attr( $meta_title ); ?>" />
        <meta name="twitter:description" content="<?php echo esc_attr( $description ); ?>" />
        <?php if ( $og_image ) : ?>
        <meta name="twitter:image"       content="<?php echo esc_url( $og_image ); ?>" />
        <?php endif; ?>
        <!-- /Anime Sync Pro SEO -->
        <?php
    }

    /* ─────────────────────────────────────────────
       Custom <title> tag
    ───────────────────────────────────────────── */

    /**
     * @param array $parts
     * @return array
     */
    public function filter_title( array $parts ): array {
        if ( ! is_singular( 'anime' ) ) {
            return $parts;
        }
        $post_id   = get_the_ID();
        $title_cn  = get_post_meta( $post_id, 'anime_title_chinese', true );
        if ( $title_cn ) {
            $parts['title'] = $title_cn;
        }
        return $parts;
    }

    /* ═══════════════════════════════════════════════════════════
       4. JSON-LD STRUCTURED DATA
    ══════════════════════════════════════════════════════════ */

    public function output_json_ld() {
        if ( ! is_singular( 'anime' ) ) {
            return;
        }

        $post_id      = get_the_ID();
        $title_cn     = get_post_meta( $post_id, 'anime_title_chinese',  true );
        $title_en     = get_post_meta( $post_id, 'anime_title_english',  true );
        $title_native = get_post_meta( $post_id, 'anime_title_native',   true );
        $synopsis_cn  = get_post_meta( $post_id, 'anime_synopsis_chinese', true );
        $synopsis_en  = get_post_meta( $post_id, 'anime_synopsis_english', true );
        $cover        = get_post_meta( $post_id, 'anime_cover_image',    true );
        $start_date   = get_post_meta( $post_id, 'anime_start_date',     true );
        $end_date     = get_post_meta( $post_id, 'anime_end_date',       true );
        $episodes     = (int) get_post_meta( $post_id, 'anime_episodes', true );
        $format       = get_post_meta( $post_id, 'anime_format',         true );
        $studio       = get_post_meta( $post_id, 'anime_studio',         true );
        $score_al     = get_post_meta( $post_id, 'anime_score_anilist',  true );
        $official_url = get_post_meta( $post_id, 'anime_official_site',  true );
        $trailer_url  = get_post_meta( $post_id, 'anime_trailer_url',    true );

        $display_title = $title_cn ?: get_the_title();
        $description   = $synopsis_cn ?: $synopsis_en ?: '';
        $url           = get_permalink( $post_id );

        // Determine schema type
        $schema_type = ( $format === 'MOVIE' ) ? 'Movie' : 'TVSeries';

        $schema = [
            '@context'    => 'https://schema.org',
            '@type'       => $schema_type,
            'name'        => $display_title,
            'url'         => $url,
            'description' => wp_strip_all_tags( $description ),
        ];

        // Alternate names
        $alt_names = array_filter( [ $title_en, $title_native ] );
        if ( $alt_names ) {
            $schema['alternateName'] = array_values( $alt_names );
        }

        // Image
        if ( $cover ) {
            $schema['image'] = $cover;
        }

        // Dates
        if ( $start_date ) {
            $schema['startDate'] = $start_date;
        }
        if ( $end_date && $schema_type === 'TVSeries' ) {
            $schema['endDate'] = $end_date;
        }
        if ( $end_date && $schema_type === 'Movie' ) {
            $schema['datePublished'] = $start_date ?: $end_date;
        }

        // Episode count
        if ( $episodes > 0 && $schema_type === 'TVSeries' ) {
            $schema['numberOfEpisodes'] = $episodes;
        }

        // Production company
        if ( $studio ) {
            $schema['productionCompany'] = [
                '@type' => 'Organization',
                'name'  => $studio,
            ];
        }

        // Aggregate rating from AniList score (scale 0–100 → 0–10)
        if ( $score_al ) {
            $schema['aggregateRating'] = [
                '@type'       => 'AggregateRating',
                'ratingValue' => round( (float) $score_al / 10, 1 ),
                'bestRating'  => 10,
                'worstRating' => 0,
                'ratingCount' => 1,   // placeholder; real count not stored
            ];
        }

        // Official site as sameAs
        $same_as = [];
        if ( $official_url ) { $same_as[] = $official_url; }
        if ( $same_as ) {
            $schema['sameAs'] = $same_as;
        }

        // Trailer (VideoObject)
        if ( $trailer_url ) {
            $schema['trailer'] = [
                '@type'       => 'VideoObject',
                'name'        => $display_title . ' Trailer',
                'embedUrl'    => $trailer_url,
                'description' => $display_title . ' official trailer',
            ];
        }

        // Breadcrumb
        $breadcrumb = $this->build_breadcrumb_schema( $display_title, $url );

        $output = [
            $schema,
            $breadcrumb,
        ];

        echo "\n" . '<script type="application/ld+json">'
             . wp_json_encode( $output, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT )
             . '</script>' . "\n";
    }

    /**
     * Build BreadcrumbList schema.
     *
     * @param string $title
     * @param string $url
     * @return array
     */
    private function build_breadcrumb_schema( string $title, string $url ): array {
        $archive_url = get_post_type_archive_link( 'anime' ) ?: home_url( '/anime/' );

        return [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type'    => 'ListItem',
                    'position' => 1,
                    'name'     => __( '首頁', 'anime-sync-pro' ),
                    'item'     => home_url( '/' ),
                ],
                [
                    '@type'    => 'ListItem',
                    'position' => 2,
                    'name'     => __( '動畫列表', 'anime-sync-pro' ),
                    'item'     => $archive_url,
                ],
                [
                    '@type'    => 'ListItem',
                    'position' => 3,
                    'name'     => $title,
                    'item'     => $url,
                ],
            ],
        ];
    }

    /* ═══════════════════════════════════════════════════════════
       5. BODY CLASSES
    ══════════════════════════════════════════════════════════ */

    /**
     * @param array $classes
     * @return array
     */
    public function add_body_classes( array $classes ): array {
        if ( is_singular( 'anime' ) ) {
            $post_id = get_the_ID();
            $format  = get_post_meta( $post_id, 'anime_format', true );
            $status  = get_post_meta( $post_id, 'anime_status', true );

            $classes[] = 'single-anime';
            if ( $format ) {
                $classes[] = 'anime-format-' . sanitize_html_class( strtolower( $format ) );
            }
            if ( $status ) {
                $classes[] = 'anime-status-' . sanitize_html_class( strtolower( $status ) );
            }
        }
        if ( is_post_type_archive( 'anime' ) ) {
            $classes[] = 'archive-anime';
        }
        return $classes;
    }

    /* ═══════════════════════════════════════════════════════════
       6. SHORTCODES
    ══════════════════════════════════════════════════════════ */

    /* ── [anime_score post_id=""] ── */
    public function shortcode_score( array $atts ): string {
        $atts    = shortcode_atts( [ 'post_id' => get_the_ID() ], $atts );
        $post_id = (int) $atts['post_id'];
        if ( ! $post_id ) { return ''; }

        $al  = get_post_meta( $post_id, 'anime_score_anilist',  true );
        $mal = get_post_meta( $post_id, 'anime_score_mal',      true );
        $bgm = get_post_meta( $post_id, 'anime_score_bangumi',  true );

        $na = esc_html__( '暫無', 'anime-sync-pro' );

        ob_start();
        ?>
        <div class="anime-score-widget">
            <div class="score-item score-anilist">
                <span class="score-label">AniList</span>
                <span class="score-value"><?php echo $al ? esc_html( $al ) : $na; ?></span>
            </div>
            <div class="score-item score-mal">
                <span class="score-label">MAL</span>
                <span class="score-value"><?php echo $mal ? esc_html( $mal ) : $na; ?></span>
            </div>
            <div class="score-item score-bangumi">
                <span class="score-label">Bangumi</span>
                <span class="score-value"><?php echo $bgm ? esc_html( $bgm ) : $na; ?></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ── [anime_streaming post_id=""] ── */
    public function shortcode_streaming( array $atts ): string {
        $atts    = shortcode_atts( [ 'post_id' => get_the_ID() ], $atts );
        $post_id = (int) $atts['post_id'];
        if ( ! $post_id ) { return ''; }

        $json = get_post_meta( $post_id, 'anime_streaming_json', true );
        if ( ! $json ) {
            return '<p class="anime-no-data">'
                   . esc_html__( '目前無已知串流平台資訊。', 'anime-sync-pro' )
                   . '</p>';
        }

        $platforms = json_decode( $json, true );
        if ( ! is_array( $platforms ) || empty( $platforms ) ) {
            return '<p class="anime-no-data">'
                   . esc_html__( '目前無已知串流平台資訊。', 'anime-sync-pro' )
                   . '</p>';
        }

        ob_start();
        echo '<div class="anime-streaming-list">';
        foreach ( $platforms as $p ) {
            $name = isset( $p['site'] )  ? sanitize_text_field( $p['site'] )  : '';
            $url  = isset( $p['url'] )   ? esc_url( $p['url'] )               : '';
            if ( ! $name || ! $url ) { continue; }
            printf(
                '<a class="streaming-link streaming-%s" href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
                esc_attr( sanitize_html_class( strtolower( $name ) ) ),
                $url,
                esc_html( $name )
            );
        }
        echo '</div>';
        return ob_get_clean();
    }

    /* ── [anime_themes post_id="" type=""] ── */
    public function shortcode_themes( array $atts ): string {
        $atts    = shortcode_atts( [
            'post_id' => get_the_ID(),
            'type'    => '',   // '' = all, 'OP' = openings only, 'ED' = endings only
        ], $atts );
        $post_id  = (int) $atts['post_id'];
        $type_filter = strtoupper( sanitize_text_field( $atts['type'] ) );
        if ( ! $post_id ) { return ''; }

        $json = get_post_meta( $post_id, 'anime_themes_json', true );
        if ( ! $json ) {
            return '<p class="anime-no-data">'
                   . esc_html__( '目前無 OP/ED 資訊。', 'anime-sync-pro' )
                   . '</p>';
        }

        $themes = json_decode( $json, true );
        if ( ! is_array( $themes ) || empty( $themes ) ) {
            return '<p class="anime-no-data">'
                   . esc_html__( '目前無 OP/ED 資訊。', 'anime-sync-pro' )
                   . '</p>';
        }

        ob_start();
        echo '<div class="anime-themes-list">';
        foreach ( $themes as $theme ) {
            $theme_type  = strtoupper( $theme['type']  ?? '' );
            $theme_title = $theme['title'] ?? '';
            $theme_by    = $theme['by']    ?? '';
            $theme_video = $theme['video'] ?? '';

            if ( $type_filter && $theme_type !== $type_filter ) { continue; }

            $label_class = ( $theme_type === 'OP' ) ? 'theme-op' : 'theme-ed';
            $label_text  = ( $theme_type === 'OP' )
                ? esc_html__( 'OP', 'anime-sync-pro' )
                : esc_html__( 'ED', 'anime-sync-pro' );

            echo '<div class="anime-theme-item ' . esc_attr( $label_class ) . '">';
            echo '<span class="theme-type-badge">' . $label_text . '</span>';
            echo '<span class="theme-title">' . esc_html( $theme_title ) . '</span>';
            if ( $theme_by ) {
                echo ' <span class="theme-artist">— ' . esc_html( $theme_by ) . '</span>';
            }
            if ( $theme_video ) {
                echo ' <a class="theme-video-link" href="' . esc_url( $theme_video ) . '"'
                     . ' target="_blank" rel="noopener noreferrer">'
                     . esc_html__( '▶ 影片', 'anime-sync-pro' )
                     . '</a>';
            }
            echo '</div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    /* ═══════════════════════════════════════════════════════════
       7. REST API
    ══════════════════════════════════════════════════════════ */

    public function register_rest_routes() {
        // GET /wp-json/anime-sync/v1/anime/{id}
        register_rest_route( self::REST_NAMESPACE, '/anime/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'rest_get_anime' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'id' => [
                    'validate_callback' => fn( $v ) => is_numeric( $v ) && (int) $v > 0,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ] );

        // GET /wp-json/anime-sync/v1/season?season=SPRING&year=2025
        register_rest_route( self::REST_NAMESPACE, '/season', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'rest_get_season' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'season' => [
                    'sanitize_callback' => 'sanitize_text_field',
                    'validate_callback' => fn( $v ) => in_array(
                        strtoupper( $v ),
                        [ 'WINTER', 'SPRING', 'SUMMER', 'FALL' ],
                        true
                    ),
                ],
                'year' => [
                    'sanitize_callback' => 'absint',
                    'validate_callback' => fn( $v ) => (int) $v >= 1960 && (int) $v <= 2099,
                ],
            ],
        ] );
    }

    /* ── REST: single anime ── */
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function rest_get_anime( WP_REST_Request $request ) {
        $post_id = $request->get_param( 'id' );
        $post    = get_post( $post_id );

        if ( ! $post || $post->post_type !== 'anime' || $post->post_status !== 'publish' ) {
            return new WP_Error(
                'anime_not_found',
                __( '找不到該動畫。', 'anime-sync-pro' ),
                [ 'status' => 404 ]
            );
        }

        return new WP_REST_Response( $this->build_rest_response( $post_id ), 200 );
    }

    /* ── REST: season listing ── */
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function rest_get_season( WP_REST_Request $request ) {
        $season = strtoupper( $request->get_param( 'season' ) ?? '' );
        $year   = (int) ( $request->get_param( 'year' ) ?? 0 );

        $args = [
            'post_type'      => 'anime',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'orderby'        => 'meta_value_num',
            'meta_key'       => 'anime_popularity',
            'order'          => 'DESC',
            'meta_query'     => [ 'relation' => 'AND' ],
        ];

        if ( $season ) {
            $args['meta_query'][] = [
                'key'     => 'anime_season',
                'value'   => $season,
                'compare' => '=',
            ];
        }
        if ( $year ) {
            $args['meta_query'][] = [
                'key'     => 'anime_season_year',
                'value'   => $year,
                'compare' => '=',
                'type'    => 'NUMERIC',
            ];
        }

        $query   = new WP_Query( $args );
        $results = [];

        while ( $query->have_posts() ) {
            $query->the_post();
            $pid       = get_the_ID();
            $results[] = [
                'id'          => $pid,
                'title'       => get_post_meta( $pid, 'anime_title_chinese',  true ) ?: get_the_title(),
                'title_en'    => get_post_meta( $pid, 'anime_title_english',  true ),
                'format'      => get_post_meta( $pid, 'anime_format',         true ),
                'status'      => get_post_meta( $pid, 'anime_status',         true ),
                'episodes'    => (int) get_post_meta( $pid, 'anime_episodes', true ),
                'cover_image' => get_post_meta( $pid, 'anime_cover_image',    true ),
                'url'         => get_permalink( $pid ),
                'anilist_id'  => (int) get_post_meta( $pid, 'anime_anilist_id', true ),
            ];
        }
        wp_reset_postdata();

        return new WP_REST_Response( [
            'season'      => $season,
            'year'        => $year,
            'total'       => count( $results ),
            'anime_list'  => $results,
        ], 200 );
    }

    /* ─────────────────────────────────────────────
       Build REST response payload
    ───────────────────────────────────────────── */
    /**
     * @param int $post_id
     * @return array
     */
    private function build_rest_response( int $post_id ): array {
        $meta_keys = [
            'anime_anilist_id', 'anime_mal_id', 'anime_bangumi_id',
            'anime_title_chinese', 'anime_title_native', 'anime_title_romaji', 'anime_title_english',
            'anime_format', 'anime_status', 'anime_source',
            'anime_season', 'anime_season_year',
            'anime_episodes', 'anime_episodes_aired', 'anime_duration',
            'anime_start_date', 'anime_end_date', 'anime_next_airing',
            'anime_score_anilist', 'anime_score_mal', 'anime_score_bangumi',
            'anime_popularity', 'anime_ranking',
            'anime_synopsis_chinese', 'anime_synopsis_english',
            'anime_cover_image', 'anime_banner_image', 'anime_trailer_url',
            'anime_studio', 'anime_official_site', 'anime_twitter_url',
            'anime_wikipedia_url', 'anime_tw_distributor', 'anime_tw_broadcast',
            'anime_last_sync', 'anime_last_updated',
        ];

        $data = [
            'post_id'  => $post_id,
            'url'      => get_permalink( $post_id ),
        ];

        foreach ( $meta_keys as $key ) {
            $raw = get_post_meta( $post_id, $key, true );
            // Cast numeric fields
            if ( in_array( $key, [
                'anime_anilist_id', 'anime_mal_id', 'anime_bangumi_id',
                'anime_episodes', 'anime_episodes_aired', 'anime_duration',
                'anime_season_year', 'anime_popularity', 'anime_ranking',
            ], true ) ) {
                $data[ $key ] = $raw !== '' ? (int) $raw : null;
            } elseif ( in_array( $key, [
                'anime_score_anilist', 'anime_score_mal', 'anime_score_bangumi',
            ], true ) ) {
                $data[ $key ] = $raw !== '' ? (float) $raw : null;
            } else {
                $data[ $key ] = $raw ?: null;
            }
        }

        // JSON fields decoded for REST consumers
        foreach ( [ 'anime_themes_json', 'anime_streaming_json',
                    'anime_cast_json', 'anime_staff_json' ] as $jk ) {
            $raw = get_post_meta( $post_id, $jk, true );
            $data[ $jk ] = $raw ? json_decode( $raw, true ) : null;
        }

        return $data;
    }

}
