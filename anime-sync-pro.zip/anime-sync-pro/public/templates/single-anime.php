<?php
/**
 * Single Anime Template
 *
 * File: public/templates/single-anime.php
 * Full-page layout for a single anime post.
 * Respects the active theme's header/footer via get_header() / get_footer().
 * All meta is read from post meta (anime_* keys).
 *
 * @package Anime_Sync_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

// ── Guard: must be a valid published anime post ──────────────────────────────
if ( ! have_posts() ) {
    get_footer();
    return;
}

the_post();
$post_id = get_the_ID();

// ── Pull all meta ────────────────────────────────────────────────────────────
$anilist_id     = get_post_meta( $post_id, 'anime_anilist_id',       true );
$mal_id         = get_post_meta( $post_id, 'anime_mal_id',           true );
$bangumi_id     = get_post_meta( $post_id, 'anime_bangumi_id',       true );
$title_cn       = get_post_meta( $post_id, 'anime_title_chinese',    true );
$title_en       = get_post_meta( $post_id, 'anime_title_english',    true );
$title_native   = get_post_meta( $post_id, 'anime_title_native',     true );
$title_romaji   = get_post_meta( $post_id, 'anime_title_romaji',     true );
$format         = get_post_meta( $post_id, 'anime_format',           true );
$status         = get_post_meta( $post_id, 'anime_status',           true );
$source         = get_post_meta( $post_id, 'anime_source',           true );
$season         = get_post_meta( $post_id, 'anime_season',           true );
$season_year    = get_post_meta( $post_id, 'anime_season_year',      true );
$episodes       = get_post_meta( $post_id, 'anime_episodes',         true );
$episodes_aired = get_post_meta( $post_id, 'anime_episodes_aired',   true );
$duration       = get_post_meta( $post_id, 'anime_duration',         true );
$start_date     = get_post_meta( $post_id, 'anime_start_date',       true );
$end_date       = get_post_meta( $post_id, 'anime_end_date',         true );
$next_airing    = get_post_meta( $post_id, 'anime_next_airing',      true );
$score_al       = get_post_meta( $post_id, 'anime_score_anilist',    true );
$score_mal      = get_post_meta( $post_id, 'anime_score_mal',        true );
$score_bgm      = get_post_meta( $post_id, 'anime_score_bangumi',    true );
$popularity     = get_post_meta( $post_id, 'anime_popularity',       true );
$ranking        = get_post_meta( $post_id, 'anime_ranking',          true );
$synopsis_cn    = get_post_meta( $post_id, 'anime_synopsis_chinese', true );
$synopsis_en    = get_post_meta( $post_id, 'anime_synopsis_english', true );
$cover_image    = get_post_meta( $post_id, 'anime_cover_image',      true );
$banner_image   = get_post_meta( $post_id, 'anime_banner_image',     true );
$trailer_url    = get_post_meta( $post_id, 'anime_trailer_url',      true );
$studio         = get_post_meta( $post_id, 'anime_studio',           true );
$official_site  = get_post_meta( $post_id, 'anime_official_site',    true );
$twitter_url    = get_post_meta( $post_id, 'anime_twitter_url',      true );
$wikipedia_url  = get_post_meta( $post_id, 'anime_wikipedia_url',    true );
$tiktok_url     = get_post_meta( $post_id, 'anime_tiktok_url',       true );
$tw_distributor = get_post_meta( $post_id, 'anime_tw_distributor',   true );
$tw_broadcast   = get_post_meta( $post_id, 'anime_tw_broadcast',     true );
$streaming_json = get_post_meta( $post_id, 'anime_streaming_json',   true );
$themes_json    = get_post_meta( $post_id, 'anime_themes_json',      true );
$cast_json      = get_post_meta( $post_id, 'anime_cast_json',        true );
$staff_json     = get_post_meta( $post_id, 'anime_staff_json',       true );
$last_updated   = get_post_meta( $post_id, 'anime_last_updated',     true );

// ── Decode JSON fields ───────────────────────────────────────────────────────
$streaming_list = $streaming_json ? json_decode( $streaming_json, true ) : [];
$themes_list    = $themes_json    ? json_decode( $themes_json,    true ) : [];
$cast_list      = $cast_json      ? json_decode( $cast_json,      true ) : [];
$staff_list     = $staff_json     ? json_decode( $staff_json,     true ) : [];

$streaming_list = is_array( $streaming_list ) ? $streaming_list : [];
$themes_list    = is_array( $themes_list )    ? $themes_list    : [];
$cast_list      = is_array( $cast_list )      ? $cast_list      : [];
$staff_list     = is_array( $staff_list )     ? $staff_list     : [];

// ── Display helpers ──────────────────────────────────────────────────────────
$display_title  = $title_cn ?: get_the_title();

$season_map = [
    'WINTER' => __( '冬季', 'anime-sync-pro' ),
    'SPRING' => __( '春季', 'anime-sync-pro' ),
    'SUMMER' => __( '夏季', 'anime-sync-pro' ),
    'FALL'   => __( '秋季', 'anime-sync-pro' ),
];
$season_label = ( $season && $season_year )
    ? ( $season_year . ' ' . ( $season_map[ $season ] ?? $season ) )
    : '';

$format_map = [
    'TV'        => 'TV',
    'TV_SHORT'  => 'TV Short',
    'MOVIE'     => __( '劇場版', 'anime-sync-pro' ),
    'SPECIAL'   => 'Special',
    'OVA'       => 'OVA',
    'ONA'       => 'ONA',
    'MUSIC'     => __( '音樂', 'anime-sync-pro' ),
];
$format_label = $format_map[ $format ?? '' ] ?? $format;

$status_map = [
    'FINISHED'         => [ __( '已完結',  'anime-sync-pro' ), 'status-finished'  ],
    'RELEASING'        => [ __( '連載中',  'anime-sync-pro' ), 'status-releasing' ],
    'NOT_YET_RELEASED' => [ __( '尚未播出', 'anime-sync-pro' ), 'status-upcoming'  ],
    'CANCELLED'        => [ __( '已取消',  'anime-sync-pro' ), 'status-cancelled' ],
    'HIATUS'           => [ __( '休刊中',  'anime-sync-pro' ), 'status-hiatus'    ],
];
[ $status_label, $status_class ] = $status_map[ $status ?? '' ] ?? [ $status, 'status-unknown' ];

$source_map = [
    'MANGA'              => __( '漫畫', 'anime-sync-pro' ),
    'LIGHT_NOVEL'        => __( '輕小說', 'anime-sync-pro' ),
    'VISUAL_NOVEL'       => __( '視覺小說', 'anime-sync-pro' ),
    'VIDEO_GAME'         => __( '電子遊戲', 'anime-sync-pro' ),
    'ORIGINAL'           => __( '原創', 'anime-sync-pro' ),
    'OTHER'              => __( '其他', 'anime-sync-pro' ),
    'NOVEL'              => __( '小說', 'anime-sync-pro' ),
    'DOUJINSHI'          => __( '同人誌', 'anime-sync-pro' ),
    'ANIME'              => __( '動畫', 'anime-sync-pro' ),
    'LIVE_ACTION'        => __( '真人', 'anime-sync-pro' ),
    'GAME'               => __( '遊戲', 'anime-sync-pro' ),
    'COMIC'              => __( '漫畫', 'anime-sync-pro' ),
    'MULTIMEDIA_PROJECT' => __( '多媒體企劃', 'anime-sync-pro' ),
    'PICTURE_BOOK'       => __( '繪本', 'anime-sync-pro' ),
    'WEB_MANGA'          => __( '網路漫畫', 'anime-sync-pro' ),
    'WEB_NOVEL'          => __( '網路小說', 'anime-sync-pro' ),
    'CARD_GAME'          => __( '卡牌遊戲', 'anime-sync-pro' ),
];
$source_label = $source_map[ $source ?? '' ] ?? $source;

// ── Separate OP / ED ─────────────────────────────────────────────────────────
$openings = array_filter( $themes_list, fn( $t ) => strtoupper( $t['type'] ?? '' ) === 'OP' );
$endings  = array_filter( $themes_list, fn( $t ) => strtoupper( $t['type'] ?? '' ) === 'ED' );

// ── Parse next airing ────────────────────────────────────────────────────────
$next_airing_data = $next_airing ? json_decode( $next_airing, true ) : null;
?>

<!-- ════════════════════════════════════════════════════════════
     PAGE WRAPPER
════════════════════════════════════════════════════════════ -->
<div id="anime-page-<?php echo esc_attr( $post_id ); ?>"
     class="anime-single-page <?php echo esc_attr( $status_class ); ?>">

    <!-- ── Banner ──────────────────────────────────────────── -->
    <?php if ( $banner_image ) : ?>
    <div class="anime-banner"
         style="background-image:url('<?php echo esc_url( $banner_image ); ?>');"
         aria-hidden="true">
        <div class="anime-banner-overlay"></div>
    </div>
    <?php endif; ?>

    <!-- ════════════════════════════════════════════════════
         HERO SECTION  (cover + basic info)
    ═════════════════════════════════════════════════════ -->
    <div class="anime-hero <?php echo $banner_image ? 'has-banner' : ''; ?>">
        <div class="anime-hero-inner">

            <!-- Cover image -->
            <div class="anime-cover-wrap">
                <?php if ( $cover_image ) : ?>
                    <img class="anime-cover-img"
                         src="<?php echo esc_url( $cover_image ); ?>"
                         alt="<?php echo esc_attr( $display_title ); ?>"
                         width="230" height="325"
                         loading="eager" decoding="async" />
                <?php else : ?>
                    <div class="anime-cover-placeholder">
                        <span><?php esc_html_e( '無封面', 'anime-sync-pro' ); ?></span>
                    </div>
                <?php endif; ?>

                <!-- Streaming quick-links below cover -->
                <?php if ( ! empty( $streaming_list ) ) : ?>
                <div class="anime-streaming-compact">
                    <?php foreach ( $streaming_list as $pl ) :
                        $pl_name = sanitize_text_field( $pl['site'] ?? '' );
                        $pl_url  = esc_url( $pl['url'] ?? '' );
                        if ( ! $pl_name || ! $pl_url ) continue;
                    ?>
                        <a class="streaming-btn streaming-<?php echo esc_attr( sanitize_html_class( strtolower( $pl_name ) ) ); ?>"
                           href="<?php echo $pl_url; ?>"
                           target="_blank" rel="noopener noreferrer"
                           title="<?php echo esc_attr( $pl_name ); ?>">
                            <?php echo esc_html( $pl_name ); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div><!-- /cover-wrap -->

            <!-- Hero info block -->
            <div class="anime-hero-info">

                <!-- Titles -->
                <h1 class="anime-title-main">
                    <?php echo esc_html( $display_title ); ?>
                </h1>
                <?php if ( $title_native && $title_native !== $display_title ) : ?>
                    <p class="anime-title-native"><?php echo esc_html( $title_native ); ?></p>
                <?php endif; ?>
                <?php if ( $title_en && $title_en !== $display_title ) : ?>
                    <p class="anime-title-en"><?php echo esc_html( $title_en ); ?></p>
                <?php endif; ?>
                <?php if ( $title_romaji && $title_romaji !== $display_title ) : ?>
                    <p class="anime-title-romaji"><?php echo esc_html( $title_romaji ); ?></p>
                <?php endif; ?>

                <!-- Status badge + format -->
                <div class="anime-badges">
                    <span class="anime-badge <?php echo esc_attr( $status_class ); ?>">
                        <?php echo esc_html( $status_label ); ?>
                    </span>
                    <?php if ( $format_label ) : ?>
                        <span class="anime-badge badge-format">
                            <?php echo esc_html( $format_label ); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ( $season_label ) : ?>
                        <span class="anime-badge badge-season">
                            <?php echo esc_html( $season_label ); ?>
                        </span>
                    <?php endif; ?>
                </div>

                <!-- Score row -->
                <div class="anime-score-row">
                    <?php
                    $scores = [
                        'AniList'  => $score_al,
                        'MAL'      => $score_mal,
                        'Bangumi'  => $score_bgm,
                    ];
                    foreach ( $scores as $sname => $sval ) :
                        if ( ! $sval ) continue;
                    ?>
                        <div class="score-chip score-<?php echo esc_attr( strtolower( $sname ) ); ?>">
                            <span class="score-chip-label"><?php echo esc_html( $sname ); ?></span>
                            <span class="score-chip-value"><?php echo esc_html( $sval ); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Quick info grid -->
                <dl class="anime-info-grid">
                    <?php
                    $info_pairs = [
                        __( '播出季度', 'anime-sync-pro' ) => $season_label,
                        __( '集數',     'anime-sync-pro' ) => ( $episodes_aired && $episodes_aired != $episodes )
                            ? $episodes_aired . ' / ' . ( $episodes ?: '?' )
                            : ( $episodes ?: null ),
                        __( '每集時長', 'anime-sync-pro' ) => $duration ? $duration . ' ' . __( '分鐘', 'anime-sync-pro' ) : null,
                        __( '開始日期', 'anime-sync-pro' ) => $start_date,
                        __( '結束日期', 'anime-sync-pro' ) => $end_date,
                        __( '原作類型', 'anime-sync-pro' ) => $source_label,
                        __( '製作公司', 'anime-sync-pro' ) => $studio,
                        __( '台灣代理', 'anime-sync-pro' ) => $tw_distributor,
                        __( '台灣播出', 'anime-sync-pro' ) => $tw_broadcast,
                    ];
                    foreach ( $info_pairs as $label => $value ) :
                        if ( ! $value ) continue;
                    ?>
                        <dt><?php echo esc_html( $label ); ?></dt>
                        <dd><?php echo esc_html( $value ); ?></dd>
                    <?php endforeach; ?>

                    <!-- Next airing (dynamic) -->
                    <?php if ( $next_airing_data && $status === 'RELEASING' ) :
                        $ep_num    = (int) ( $next_airing_data['episode']       ?? 0 );
                        $airing_at = (int) ( $next_airing_data['airingAt']      ?? 0 );
                        $time_until = (int) ( $next_airing_data['timeUntilAiring'] ?? 0 );
                        if ( $ep_num && $airing_at ) :
                            $days    = floor( $time_until / 86400 );
                            $hours   = floor( ( $time_until % 86400 ) / 3600 );
                            $countdown = $days > 0
                                ? sprintf( __( '%d 天 %d 小時後', 'anime-sync-pro' ), $days, $hours )
                                : sprintf( __( '%d 小時後', 'anime-sync-pro' ), $hours );
                    ?>
                        <dt><?php esc_html_e( '下集播出', 'anime-sync-pro' ); ?></dt>
                        <dd>
                            <?php printf(
                                /* translators: 1: episode number, 2: date, 3: countdown */
                                esc_html__( '第 %1$s 集 · %2$s（%3$s）', 'anime-sync-pro' ),
                                esc_html( $ep_num ),
                                esc_html( date_i18n( 'Y-m-d H:i', $airing_at ) ),
                                esc_html( $countdown )
                            ); ?>
                        </dd>
                    <?php endif; endif; ?>
                </dl>

                <!-- External links -->
                <div class="anime-external-links">
                    <?php
                    $ext_links = [
                        [ 'url' => $official_site,   'label' => __( '官方網站', 'anime-sync-pro' ),  'class' => 'link-official'  ],
                        [ 'url' => $twitter_url,     'label' => 'Twitter / X',                       'class' => 'link-twitter'   ],
                        [ 'url' => $wikipedia_url,   'label' => 'Wikipedia',                         'class' => 'link-wikipedia' ],
                        [ 'url' => $tiktok_url,      'label' => 'TikTok',                            'class' => 'link-tiktok'    ],
                        [ 'url' => $anilist_id ? 'https://anilist.co/anime/' . $anilist_id . '/' : '',
                          'label' => 'AniList', 'class' => 'link-anilist' ],
                        [ 'url' => $mal_id    ? 'https://myanimelist.net/anime/' . $mal_id   : '',
                          'label' => 'MyAnimeList', 'class' => 'link-mal' ],
                        [ 'url' => $bangumi_id ? 'https://bgm.tv/subject/' . $bangumi_id    : '',
                          'label' => 'Bangumi', 'class' => 'link-bangumi' ],
                    ];
                    foreach ( $ext_links as $lnk ) :
                        if ( empty( $lnk['url'] ) ) continue;
                    ?>
                        <a class="anime-ext-link <?php echo esc_attr( $lnk['class'] ); ?>"
                           href="<?php echo esc_url( $lnk['url'] ); ?>"
                           target="_blank" rel="noopener noreferrer">
                            <?php echo esc_html( $lnk['label'] ); ?>
                        </a>
                    <?php endforeach; ?>
                </div>

            </div><!-- /hero-info -->
        </div><!-- /hero-inner -->
    </div><!-- /anime-hero -->

    <!-- ════════════════════════════════════════════════════
         MAIN CONTENT AREA
    ═════════════════════════════════════════════════════ -->
    <div class="anime-main-content">
        <div class="anime-content-inner">

            <!-- ── Synopsis ──────────────────────────────── -->
            <?php if ( $synopsis_cn || $synopsis_en ) : ?>
            <section class="anime-section anime-synopsis" id="synopsis">
                <h2 class="anime-section-title">
                    <?php esc_html_e( '簡介', 'anime-sync-pro' ); ?>
                </h2>
                <div class="anime-synopsis-text">
                    <?php
                    $synopsis_display = $synopsis_cn ?: $synopsis_en;
                    // Convert newlines to <br> but strip all other HTML
                    echo nl2br( esc_html( $synopsis_display ) );
                    ?>
                </div>
                <?php if ( $synopsis_cn && $synopsis_en ) : ?>
                    <button type="button" class="btn-toggle-synopsis-en">
                        <?php esc_html_e( '顯示英文原文', 'anime-sync-pro' ); ?>
                    </button>
                    <div class="anime-synopsis-en" style="display:none;">
                        <?php echo nl2br( esc_html( $synopsis_en ) ); ?>
                    </div>
                <?php endif; ?>
            </section>
            <?php endif; ?>

            <!-- ── Trailer ───────────────────────────────── -->
            <?php if ( $trailer_url ) : ?>
            <section class="anime-section anime-trailer" id="trailer">
                <h2 class="anime-section-title">
                    <?php esc_html_e( '預告片', 'anime-sync-pro' ); ?>
                </h2>
                <div class="anime-trailer-wrap">
                    <?php
                    // Support YouTube embed URLs
                    $embed_url = $trailer_url;
                    if ( preg_match( '/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]{11})/', $trailer_url, $m ) ) {
                        $embed_url = 'https://www.youtube-nocookie.com/embed/' . $m[1];
                    }
                    ?>
                    <iframe class="anime-trailer-iframe"
                            src="<?php echo esc_url( $embed_url ); ?>"
                            title="<?php echo esc_attr( $display_title . ' Trailer' ); ?>"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen
                            loading="lazy">
                    </iframe>
                </div>
            </section>
            <?php endif; ?>

            <!-- ── OP / ED Themes ────────────────────────── -->
            <?php if ( ! empty( $themes_list ) ) : ?>
            <section class="anime-section anime-themes" id="themes">
                <h2 class="anime-section-title">
                    <?php esc_html_e( 'OP / ED', 'anime-sync-pro' ); ?>
                </h2>

                <?php if ( ! empty( $openings ) ) : ?>
                <div class="themes-group themes-op">
                    <h3 class="themes-group-title">
                        <?php esc_html_e( '片頭曲 Opening', 'anime-sync-pro' ); ?>
                    </h3>
                    <?php foreach ( $openings as $i => $theme ) : ?>
                        <div class="anime-theme-row">
                            <span class="theme-index">OP<?php echo esc_html( $i + 1 ); ?></span>
                            <span class="theme-title">
                                <?php echo esc_html( $theme['title'] ?? '' ); ?>
                            </span>
                            <?php if ( ! empty( $theme['by'] ) ) : ?>
                                <span class="theme-artist">
                                    — <?php echo esc_html( $theme['by'] ); ?>
                                </span>
                            <?php endif; ?>
                            <?php if ( ! empty( $theme['video'] ) ) : ?>
                                <a class="theme-video-btn"
                                   href="<?php echo esc_url( $theme['video'] ); ?>"
                                   target="_blank" rel="noopener noreferrer">
                                    ▶
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if ( ! empty( $endings ) ) : ?>
                <div class="themes-group themes-ed">
                    <h3 class="themes-group-title">
                        <?php esc_html_e( '片尾曲 Ending', 'anime-sync-pro' ); ?>
                    </h3>
                    <?php foreach ( $endings as $i => $theme ) : ?>
                        <div class="anime-theme-row">
                            <span class="theme-index">ED<?php echo esc_html( $i + 1 ); ?></span>
                            <span class="theme-title">
                                <?php echo esc_html( $theme['title'] ?? '' ); ?>
                            </span>
                            <?php if ( ! empty( $theme['by'] ) ) : ?>
                                <span class="theme-artist">
                                    — <?php echo esc_html( $theme['by'] ); ?>
                                </span>
                            <?php endif; ?>
                            <?php if ( ! empty( $theme['video'] ) ) : ?>
                                <a class="theme-video-btn"
                                   href="<?php echo esc_url( $theme['video'] ); ?>"
                                   target="_blank" rel="noopener noreferrer">
                                    ▶
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

            </section>
            <?php endif; ?>

            <!-- ── Cast ──────────────────────────────────── -->
            <?php if ( ! empty( $cast_list ) ) : ?>
            <section class="anime-section anime-cast" id="cast">
                <h2 class="anime-section-title">
                    <?php esc_html_e( '登場人物 / 聲優', 'anime-sync-pro' ); ?>
                </h2>
                <div class="anime-cast-grid">
                    <?php
                    $cast_display = array_slice( $cast_list, 0, 12 );
                    foreach ( $cast_display as $member ) :
                        $char_name  = sanitize_text_field( $member['character_name']  ?? '' );
                        $char_img   = esc_url( $member['character_image'] ?? '' );
                        $va_name    = sanitize_text_field( $member['va_name']  ?? '' );
                        $va_img     = esc_url( $member['va_image'] ?? '' );
                        $va_lang    = sanitize_text_field( $member['va_language'] ?? 'JAPANESE' );
                        if ( ! $char_name ) continue;
                    ?>
                        <div class="cast-card">
                            <div class="cast-images">
                                <?php if ( $char_img ) : ?>
                                    <img class="cast-char-img"
                                         src="<?php echo $char_img; ?>"
                                         alt="<?php echo esc_attr( $char_name ); ?>"
                                         width="60" height="85"
                                         loading="lazy" />
                                <?php endif; ?>
                                <?php if ( $va_img ) : ?>
                                    <img class="cast-va-img"
                                         src="<?php echo $va_img; ?>"
                                         alt="<?php echo esc_attr( $va_name ); ?>"
                                         width="60" height="85"
                                         loading="lazy" />
                                <?php endif; ?>
                            </div>
                            <div class="cast-names">
                                <span class="cast-char-name"><?php echo esc_html( $char_name ); ?></span>
                                <?php if ( $va_name ) : ?>
                                    <span class="cast-va-name"><?php echo esc_html( $va_name ); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if ( count( $cast_list ) > 12 ) : ?>
                    <button type="button" class="btn-show-all-cast" data-total="<?php echo esc_attr( count( $cast_list ) ); ?>">
                        <?php printf(
                            esc_html__( '顯示全部 %d 位角色', 'anime-sync-pro' ),
                            count( $cast_list )
                        ); ?>
                    </button>
                    <div class="anime-cast-grid cast-hidden" style="display:none;">
                        <?php foreach ( array_slice( $cast_list, 12 ) as $member ) :
                            $char_name  = sanitize_text_field( $member['character_name']  ?? '' );
                            $char_img   = esc_url( $member['character_image'] ?? '' );
                            $va_name    = sanitize_text_field( $member['va_name']  ?? '' );
                            $va_img     = esc_url( $member['va_image'] ?? '' );
                            if ( ! $char_name ) continue;
                        ?>
                            <div class="cast-card">
                                <div class="cast-images">
                                    <?php if ( $char_img ) : ?>
                                        <img class="cast-char-img"
                                             src="<?php echo $char_img; ?>"
                                             alt="<?php echo esc_attr( $char_name ); ?>"
                                             width="60" height="85"
                                             loading="lazy" />
                                    <?php endif; ?>
                                    <?php if ( $va_img ) : ?>
                                        <img class="cast-va-img"
                                             src="<?php echo $va_img; ?>"
                                             alt="<?php echo esc_attr( $va_name ); ?>"
                                             width="60" height="85"
                                             loading="lazy" />
                                    <?php endif; ?>
                                </div>
                                <div class="cast-names">
                                    <span class="cast-char-name"><?php echo esc_html( $char_name ); ?></span>
                                    <?php if ( $va_name ) : ?>
                                        <span class="cast-va-name"><?php echo esc_html( $va_name ); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
            <?php endif; ?>

            <!-- ── Staff ─────────────────────────────────── -->
            <?php if ( ! empty( $staff_list ) ) : ?>
            <section class="anime-section anime-staff" id="staff">
                <h2 class="anime-section-title">
                    <?php esc_html_e( '製作人員', 'anime-sync-pro' ); ?>
                </h2>
                <div class="anime-staff-grid">
                    <?php foreach ( $staff_list as $member ) :
                        $name  = sanitize_text_field( $member['name']  ?? '' );
                        $role  = sanitize_text_field( $member['role']  ?? '' );
                        $image = esc_url( $member['image'] ?? '' );
                        if ( ! $name ) continue;
                    ?>
                        <div class="staff-card">
                            <?php if ( $image ) : ?>
                                <img class="staff-img"
                                     src="<?php echo $image; ?>"
                                     alt="<?php echo esc_attr( $name ); ?>"
                                     width="60" height="85"
                                     loading="lazy" />
                            <?php endif; ?>
                            <div class="staff-info">
                                <span class="staff-name"><?php echo esc_html( $name ); ?></span>
                                <?php if ( $role ) : ?>
                                    <span class="staff-role"><?php echo esc_html( $role ); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- ── Data attribution + last updated ──────── -->
            <footer class="anime-data-footer">
                <p class="anime-data-source">
                    <?php esc_html_e( '資料來源：', 'anime-sync-pro' ); ?>
                    <a href="https://anilist.co"          target="_blank" rel="noopener noreferrer">AniList</a>、
                    <a href="https://myanimelist.net"     target="_blank" rel="noopener noreferrer">MyAnimeList</a>、
                    <a href="https://bgm.tv"              target="_blank" rel="noopener noreferrer">Bangumi</a>、
                    <a href="https://animethemes.moe"     target="_blank" rel="noopener noreferrer">AnimeThemes</a>
                </p>
                <?php if ( $last_updated ) : ?>
                <p class="anime-last-updated">
                    <?php printf(
                        esc_html__( '資料更新時間：%s', 'anime-sync-pro' ),
                        esc_html( date_i18n( 'Y-m-d H:i', strtotime( $last_updated ) ) )
                    ); ?>
                </p>
                <?php endif; ?>
            </footer>

        </div><!-- /content-inner -->
    </div><!-- /main-content -->

</div><!-- /anime-single-page -->

<!-- ── Inline page JS ────────────────────────────────────────────────────── -->
<script>
( function () {
    'use strict';

    /* Toggle English synopsis */
    const btnEn = document.querySelector( '.btn-toggle-synopsis-en' );
    if ( btnEn ) {
        btnEn.addEventListener( 'click', function () {
            const enBlock = document.querySelector( '.anime-synopsis-en' );
            if ( ! enBlock ) { return; }
            const isHidden = enBlock.style.display === 'none';
            enBlock.style.display = isHidden ? 'block' : 'none';
            btnEn.textContent = isHidden
                ? '<?php echo esc_js( esc_html__( '隱藏英文原文', 'anime-sync-pro' ) ); ?>'
                : '<?php echo esc_js( esc_html__( '顯示英文原文', 'anime-sync-pro' ) ); ?>';
        } );
    }

    /* Show all cast */
    const btnCast = document.querySelector( '.btn-show-all-cast' );
    if ( btnCast ) {
        btnCast.addEventListener( 'click', function () {
            const hiddenGrid = document.querySelector( '.cast-hidden' );
            if ( ! hiddenGrid ) { return; }
            hiddenGrid.style.display = 'grid';
            btnCast.style.display    = 'none';
        } );
    }

} )();
</script>

<?php get_footer(); ?>
