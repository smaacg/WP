<?php
/**
 * Published Anime List Page
 * 
 * @package Anime_Sync_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

// 查詢已發布的動畫
$paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
$per_page = 20;

$args = array(
    'post_type' => 'anime',
    'post_status' => array('publish', 'draft'),
    'posts_per_page' => $per_page,
    'paged' => $paged,
    'orderby' => 'date',
    'order' => 'DESC'
);

$query = new WP_Query($args);
?>

<div class="wrap">
    <h1>已發布動畫</h1>
    
    <div class="anime-sync-published-list">
        
        <div class="tablenav top">
            <div class="alignleft actions">
                <a href="<?php echo admin_url('edit.php?post_type=anime'); ?>" 
                   class="button">
                    完整管理介面
                </a>
                <a href="<?php echo admin_url('post-new.php?post_type=anime'); ?>" 
                   class="button button-primary">
                    新增動畫
                </a>
            </div>
        </div>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 80px;">封面</th>
                    <th>標題</th>
                    <th style="width: 100px;">AniList ID</th>
                    <th style="width: 100px;">狀態</th>
                    <th style="width: 150px;">發布日期</th>
                    <th style="width: 200px;">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($query->have_posts()): ?>
                    <?php while ($query->have_posts()): $query->the_post(); ?>
                        <?php
                        $post_id = get_the_ID();
                        $anilist_id = get_post_meta($post_id, 'anime_id_anilist', true);
                        $cover_url = get_post_meta($post_id, 'anime_cover_url', true);
                        ?>
                        <tr>
                            <td>
                                <?php if ($cover_url): ?>
                                    <img src="<?php echo esc_url($cover_url); ?>" 
                                         style="width: 60px; height: auto; border-radius: 4px;">
                                <?php else: ?>
                                    <div style="width: 60px; height: 85px; background: #ddd; border-radius: 4px;"></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong>
                                    <a href="<?php echo get_edit_post_link($post_id); ?>">
                                        <?php the_title(); ?>
                                    </a>
                                </strong>
                            </td>
                            <td><?php echo esc_html($anilist_id); ?></td>
                            <td>
                                <?php if (get_post_status() === 'publish'): ?>
                                    <span class="status-badge status-published">已發布</span>
                                <?php else: ?>
                                    <span class="status-badge status-draft">草稿</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo get_the_date('Y-m-d H:i'); ?></td>
                            <td>
                                <a href="<?php echo get_edit_post_link($post_id); ?>" 
                                   class="button button-small">
                                    編輯
                                </a>
                                <a href="<?php echo get_permalink($post_id); ?>" 
                                   class="button button-small" 
                                   target="_blank">
                                    查看
                                </a>
                                <button type="button" 
                                        class="button button-small resync-anime" 
                                        data-post-id="<?php echo esc_attr($post_id); ?>"
                                        data-anilist-id="<?php echo esc_attr($anilist_id); ?>">
                                    重新同步
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: #999;">
                            <span class="dashicons dashicons-video-alt3" style="font-size: 48px;"></span>
                            <p style="margin-top: 10px;">尚未發布任何動畫</p>
                            <a href="<?php echo admin_url('admin.php?page=anime-sync-import'); ?>" 
                               class="button button-primary">
                                開始匯入
                            </a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <?php if ($query->max_num_pages > 1): ?>
        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $query->max_num_pages,
                    'current' => $paged
                ));
                ?>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
</div>

<?php wp_reset_postdata(); ?>
