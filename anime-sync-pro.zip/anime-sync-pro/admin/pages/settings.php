<?php
/**
 * Admin Page: Settings
 *
 * File: admin/pages/settings.php
 * Plugin-wide configuration: API keys, cron schedule, cache control,
 * log management, map download, and debug tools.
 *
 * @package Anime_Sync_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ───────────────────────────────────────────────
   Handle form save (Settings API fallback)
─────────────────────────────────────────────── */
$saved = false;
if (
    isset( $_POST['anime_sync_settings_nonce'] ) &&
    wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['anime_sync_settings_nonce'] ) ), 'anime_sync_save_settings' )
) {
    $fields = [
        'anime_sync_site_name'          => 'sanitize_text_field',
        'anime_sync_site_url'           => 'esc_url_raw',
        'anime_sync_daily_hour_taipei'  => 'intval',
        'anime_sync_weekly_day'         => 'sanitize_text_field',
        'anime_sync_weekly_hour_taipei' => 'intval',
        'anime_sync_rating_batch_size'  => 'intval',
        'anime_sync_log_retention_days' => 'intval',
        'anime_sync_debug_mode'         => 'intval',
        'anime_sync_cache_ttl_hours'    => 'intval',
    ];
    foreach ( $fields as $key => $sanitizer ) {
        $raw = isset( $_POST[ $key ] ) ? $_POST[ $key ] : '';
        update_option( $key, $sanitizer( $raw ) );
    }
    // Reschedule cron after time change
    do_action( 'anime_sync_reschedule_cron' );
    $saved = true;
}

/* ───────────────────────────────────────────────
   Read current values
─────────────────────────────────────────────── */
$site_name          = get_option( 'anime_sync_site_name',          get_bloginfo( 'name' ) );
$site_url           = get_option( 'anime_sync_site_url',           get_site_url() );
$daily_hour         = (int) get_option( 'anime_sync_daily_hour_taipei',  3 );
$weekly_day         = get_option( 'anime_sync_weekly_day',         'monday' );
$weekly_hour        = (int) get_option( 'anime_sync_weekly_hour_taipei', 4 );
$rating_batch_size  = (int) get_option( 'anime_sync_rating_batch_size',  25 );
$log_retention      = (int) get_option( 'anime_sync_log_retention_days', 30 );
$debug_mode         = (int) get_option( 'anime_sync_debug_mode',         0 );
$cache_ttl          = (int) get_option( 'anime_sync_cache_ttl_hours',    24 );

/* ───────────────────────────────────────────────
   Map status
─────────────────────────────────────────────── */
$map_status = Anime_Sync_ID_Mapper::get_map_status();

/* ───────────────────────────────────────────────
   Log file info
─────────────────────────────────────────────── */
$upload_dir  = wp_upload_dir();
$log_dir     = $upload_dir['basedir'] . '/anime-sync-pro/logs/';
$log_files   = glob( $log_dir . '*.log' ) ?: [];
$log_count   = count( $log_files );
$log_size    = 0;
foreach ( $log_files as $lf ) { $log_size += filesize( $lf ); }
$log_size_kb = round( $log_size / 1024, 1 );

/* ───────────────────────────────────────────────
   Cron next run times
─────────────────────────────────────────────── */
$next_daily  = wp_next_scheduled( 'anime_sync_daily_update' );
$next_weekly = wp_next_scheduled( 'anime_sync_weekly_update' );
$next_rating = wp_next_scheduled( 'anime_sync_rating_batch' );

$days_of_week = [
    'monday'    => __( '星期一', 'anime-sync-pro' ),
    'tuesday'   => __( '星期二', 'anime-sync-pro' ),
    'wednesday' => __( '星期三', 'anime-sync-pro' ),
    'thursday'  => __( '星期四', 'anime-sync-pro' ),
    'friday'    => __( '星期五', 'anime-sync-pro' ),
    'saturday'  => __( '星期六', 'anime-sync-pro' ),
    'sunday'    => __( '星期日', 'anime-sync-pro' ),
];
?>

<div class="wrap anime-sync-settings">

    <h1><?php esc_html_e( '設定', 'anime-sync-pro' ); ?></h1>

    <?php if ( $saved ) : ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e( '設定已儲存。', 'anime-sync-pro' ); ?></p>
        </div>
    <?php endif; ?>

    <!-- ═══════════════════════════════════════════
         SECTION 1 — Site Identity (User-Agent)
    ════════════════════════════════════════════ -->
    <form method="post" action="">
        <?php wp_nonce_field( 'anime_sync_save_settings', 'anime_sync_settings_nonce' ); ?>

        <div class="anime-sync-settings-card">
            <h2><?php esc_html_e( '網站識別 (User-Agent)', 'anime-sync-pro' ); ?></h2>
            <p class="description">
                <?php esc_html_e( '用於 API 請求的 User-Agent 標頭，部分 API（如 Bangumi）要求必填。', 'anime-sync-pro' ); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="anime_sync_site_name">
                            <?php esc_html_e( '網站名稱', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" id="anime_sync_site_name"
                               name="anime_sync_site_name"
                               value="<?php echo esc_attr( $site_name ); ?>"
                               class="regular-text" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="anime_sync_site_url">
                            <?php esc_html_e( '網站 URL', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <input type="url" id="anime_sync_site_url"
                               name="anime_sync_site_url"
                               value="<?php echo esc_attr( $site_url ); ?>"
                               class="regular-text" />
                        <p class="description">
                            <?php
                            printf(
                                /* translators: %s: example UA string */
                                esc_html__( '產生的 UA：%s', 'anime-sync-pro' ),
                                '<code>' . esc_html(
                                    sanitize_text_field( $site_name ) . '/1.0 (' .
                                    esc_url_raw( $site_url ) . ')'
                                ) . '</code>'
                            );
                            ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ═══════════════════════════════════════════
             SECTION 2 — Cron Schedule
        ════════════════════════════════════════════ -->
        <div class="anime-sync-settings-card">
            <h2><?php esc_html_e( '排程設定（台北時間）', 'anime-sync-pro' ); ?></h2>
            <p class="description">
                <?php esc_html_e( '所有時間均為台北時間（UTC+8）。儲存後將自動重新排程。', 'anime-sync-pro' ); ?>
            </p>
            <table class="form-table">
                <!-- Daily update hour -->
                <tr>
                    <th scope="row">
                        <label for="anime_sync_daily_hour_taipei">
                            <?php esc_html_e( '每日更新時間（時）', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <select id="anime_sync_daily_hour_taipei"
                                name="anime_sync_daily_hour_taipei">
                            <?php for ( $h = 0; $h < 24; $h++ ) : ?>
                                <option value="<?php echo esc_attr( $h ); ?>"
                                    <?php selected( $daily_hour, $h ); ?>>
                                    <?php echo esc_html( sprintf( '%02d:00', $h ) ); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                        <?php if ( $next_daily ) : ?>
                            <span class="description" style="margin-left:12px;">
                                <?php printf(
                                    esc_html__( '下次執行：%s', 'anime-sync-pro' ),
                                    esc_html( get_date_from_gmt(
                                        date( 'Y-m-d H:i:s', $next_daily ),
                                        'Y-m-d H:i'
                                    ) )
                                ); ?>
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <!-- Weekly update day -->
                <tr>
                    <th scope="row">
                        <label for="anime_sync_weekly_day">
                            <?php esc_html_e( '每週更新日', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <select id="anime_sync_weekly_day" name="anime_sync_weekly_day">
                            <?php foreach ( $days_of_week as $val => $label ) : ?>
                                <option value="<?php echo esc_attr( $val ); ?>"
                                    <?php selected( $weekly_day, $val ); ?>>
                                    <?php echo esc_html( $label ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <!-- Weekly update hour -->
                <tr>
                    <th scope="row">
                        <label for="anime_sync_weekly_hour_taipei">
                            <?php esc_html_e( '每週更新時間（時）', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <select id="anime_sync_weekly_hour_taipei"
                                name="anime_sync_weekly_hour_taipei">
                            <?php for ( $h = 0; $h < 24; $h++ ) : ?>
                                <option value="<?php echo esc_attr( $h ); ?>"
                                    <?php selected( $weekly_hour, $h ); ?>>
                                    <?php echo esc_html( sprintf( '%02d:00', $h ) ); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                        <?php if ( $next_weekly ) : ?>
                            <span class="description" style="margin-left:12px;">
                                <?php printf(
                                    esc_html__( '下次執行：%s', 'anime-sync-pro' ),
                                    esc_html( get_date_from_gmt(
                                        date( 'Y-m-d H:i:s', $next_weekly ),
                                        'Y-m-d H:i'
                                    ) )
                                ); ?>
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <!-- Rating batch size -->
                <tr>
                    <th scope="row">
                        <label for="anime_sync_rating_batch_size">
                            <?php esc_html_e( '評分批次大小', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" id="anime_sync_rating_batch_size"
                               name="anime_sync_rating_batch_size"
                               value="<?php echo esc_attr( $rating_batch_size ); ?>"
                               min="5" max="100" class="small-text" />
                        <p class="description">
                            <?php esc_html_e( '每批次更新的動畫數量（建議 20–30）。', 'anime-sync-pro' ); ?>
                        </p>
                        <?php if ( $next_rating ) : ?>
                            <span class="description">
                                <?php printf(
                                    esc_html__( '下次評分批次：%s', 'anime-sync-pro' ),
                                    esc_html( get_date_from_gmt(
                                        date( 'Y-m-d H:i:s', $next_rating ),
                                        'Y-m-d H:i'
                                    ) )
                                ); ?>
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ═══════════════════════════════════════════
             SECTION 3 — Cache & Performance
        ════════════════════════════════════════════ -->
        <div class="anime-sync-settings-card">
            <h2><?php esc_html_e( '快取與效能', 'anime-sync-pro' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="anime_sync_cache_ttl_hours">
                            <?php esc_html_e( 'Jikan ETag 快取有效期（小時）', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" id="anime_sync_cache_ttl_hours"
                               name="anime_sync_cache_ttl_hours"
                               value="<?php echo esc_attr( $cache_ttl ); ?>"
                               min="1" max="168" class="small-text" />
                        <p class="description">
                            <?php esc_html_e( 'Jikan（MAL）回應快取時效，預設 24 小時。', 'anime-sync-pro' ); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ═══════════════════════════════════════════
             SECTION 4 — Logging
        ════════════════════════════════════════════ -->
        <div class="anime-sync-settings-card">
            <h2><?php esc_html_e( '記錄檔設定', 'anime-sync-pro' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="anime_sync_log_retention_days">
                            <?php esc_html_e( '記錄保留天數', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" id="anime_sync_log_retention_days"
                               name="anime_sync_log_retention_days"
                               value="<?php echo esc_attr( $log_retention ); ?>"
                               min="1" max="365" class="small-text" />
                        <p class="description">
                            <?php esc_html_e( '超過此天數的 .log 檔案將於每日清理時自動刪除。', 'anime-sync-pro' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( '目前記錄狀態', 'anime-sync-pro' ); ?>
                    </th>
                    <td>
                        <p>
                            <?php printf(
                                esc_html__( '共 %d 個記錄檔，合計 %s KB', 'anime-sync-pro' ),
                                $log_count,
                                number_format( $log_size_kb, 1 )
                            ); ?>
                        </p>
                        <button type="button" id="btn-clear-logs" class="button button-secondary">
                            <?php esc_html_e( '立即清除舊記錄檔', 'anime-sync-pro' ); ?>
                        </button>
                        <span id="clear-logs-result" style="margin-left:12px;"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( '偵錯模式', 'anime-sync-pro' ); ?>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="anime_sync_debug_mode"
                                   name="anime_sync_debug_mode" value="1"
                                <?php checked( $debug_mode, 1 ); ?> />
                            <?php esc_html_e( '啟用詳細偵錯記錄（會增加 IO 負擔，正式環境請關閉）', 'anime-sync-pro' ); ?>
                        </label>
                    </td>
                </tr>
            </table>
        </div>

        <p class="submit">
            <button type="submit" class="button button-primary">
                <?php esc_html_e( '儲存設定', 'anime-sync-pro' ); ?>
            </button>
        </p>

    </form><!-- /settings form -->

    <!-- ═══════════════════════════════════════════
         SECTION 5 — ID Map Management (no form)
    ════════════════════════════════════════════ -->
    <div class="anime-sync-settings-card">
        <h2><?php esc_html_e( 'Bangumi ID 對照表 (anime_map.json)', 'anime-sync-pro' ); ?></h2>
        <p class="description">
            <?php esc_html_e( '此檔案來自 github.com/bangumi/archive，提供 MAL → Bangumi ID 映射，每 24 小時自動更新一次。', 'anime-sync-pro' ); ?>
        </p>

        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( '檔案狀態', 'anime-sync-pro' ); ?></th>
                <td>
                    <?php if ( $map_status['exists'] ) : ?>
                        <span style="color:#46b450;">&#10003;</span>
                        <?php printf(
                            esc_html__( '存在 · %s 筆映射 · 大小 %s KB · 上次更新 %s', 'anime-sync-pro' ),
                            number_format( $map_status['entry_count'] ),
                            number_format( $map_status['file_size'] / 1024, 1 ),
                            esc_html( $map_status['last_updated']
                                ? date( 'Y-m-d H:i', strtotime( $map_status['last_updated'] ) )
                                : __( '不明', 'anime-sync-pro' )
                            )
                        ); ?>
                        <?php if ( $map_status['age_hours'] > 24 ) : ?>
                            <span style="color:#dc3232;margin-left:8px;">
                                ⚠ <?php esc_html_e( '已逾期，建議立即更新', 'anime-sync-pro' ); ?>
                            </span>
                        <?php endif; ?>
                    <?php else : ?>
                        <span style="color:#dc3232;">&#10007;
                            <?php esc_html_e( '檔案不存在，請立即下載', 'anime-sync-pro' ); ?>
                        </span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( '本機路徑', 'anime-sync-pro' ); ?></th>
                <td>
                    <code><?php echo esc_html( $map_status['path'] ); ?></code>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( '手動更新', 'anime-sync-pro' ); ?></th>
                <td>
                    <button type="button" id="btn-update-map" class="button button-secondary">
                        <?php esc_html_e( '立即下載 / 更新對照表', 'anime-sync-pro' ); ?>
                    </button>
                    <span id="update-map-result" style="margin-left:12px;"></span>
                    <p class="description" style="margin-top:6px;">
                        <?php esc_html_e( '主要來源：raw.githubusercontent.com；備用來源：cdn.jsdelivr.net。下載約需 5–20 秒。', 'anime-sync-pro' ); ?>
                    </p>
                </td>
            </tr>
        </table>
    </div>

    <!-- ═══════════════════════════════════════════
         SECTION 6 — Manual Cron Triggers
    ════════════════════════════════════════════ -->
    <div class="anime-sync-settings-card">
        <h2><?php esc_html_e( '手動觸發排程任務', 'anime-sync-pro' ); ?></h2>
        <p class="description">
            <?php esc_html_e( '測試或緊急補跑時使用，正式環境建議讓 WP-Cron 自動執行。', 'anime-sync-pro' ); ?>
        </p>

        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( '每日更新（播出狀態 + 集數）', 'anime-sync-pro' ); ?></th>
                <td>
                    <button type="button" class="button btn-manual-cron"
                            data-cron="anime_sync_daily_update">
                        <?php esc_html_e( '立即執行', 'anime-sync-pro' ); ?>
                    </button>
                    <span class="manual-cron-result" style="margin-left:10px;"></span>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( '評分批次更新', 'anime-sync-pro' ); ?></th>
                <td>
                    <button type="button" id="btn-trigger-rating" class="button button-secondary">
                        <?php esc_html_e( '立即觸發評分批次', 'anime-sync-pro' ); ?>
                    </button>
                    <span id="trigger-rating-result" style="margin-left:10px;"></span>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( 'OP/ED 重新抓取', 'anime-sync-pro' ); ?></th>
                <td>
                    <button type="button" id="btn-trigger-themes" class="button button-secondary">
                        <?php esc_html_e( '立即重抓所有 OP/ED', 'anime-sync-pro' ); ?>
                    </button>
                    <span id="trigger-themes-result" style="margin-left:10px;"></span>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( 'WP 物件快取', 'anime-sync-pro' ); ?></th>
                <td>
                    <button type="button" id="btn-clear-cache" class="button button-secondary">
                        <?php esc_html_e( '清除外掛快取', 'anime-sync-pro' ); ?>
                    </button>
                    <span id="clear-cache-result" style="margin-left:10px;"></span>
                </td>
            </tr>
        </table>
    </div>

    <!-- ═══════════════════════════════════════════
         SECTION 7 — System Info
    ════════════════════════════════════════════ -->
    <div class="anime-sync-settings-card">
        <h2><?php esc_html_e( '系統資訊', 'anime-sync-pro' ); ?></h2>
        <table class="form-table">
            <?php
            $info_rows = [
                __( 'PHP 版本', 'anime-sync-pro' )          => PHP_VERSION,
                __( 'WordPress 版本', 'anime-sync-pro' )    => get_bloginfo( 'version' ),
                __( 'ACF 版本', 'anime-sync-pro' )          => defined( 'ACF_VERSION' ) ? ACF_VERSION : __( '未安裝', 'anime-sync-pro' ),
                __( 'PHP memory_limit', 'anime-sync-pro' )  => ini_get( 'memory_limit' ),
                __( 'PHP max_execution_time', 'anime-sync-pro' ) => ini_get( 'max_execution_time' ) . ' s',
                __( 'cURL 版本', 'anime-sync-pro' )         => function_exists( 'curl_version' )
                    ? ( curl_version()['version'] ?? __( '不明', 'anime-sync-pro' ) )
                    : __( '不可用', 'anime-sync-pro' ),
                __( 'mbstring', 'anime-sync-pro' )          => extension_loaded( 'mbstring' ) ? '✓ 已啟用' : '✗ 未啟用',
                __( 'WP-Cron', 'anime-sync-pro' )           => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON
                    ? '<span style="color:#dc3232;">' . __( '已停用 (DISABLE_WP_CRON)', 'anime-sync-pro' ) . '</span>'
                    : '<span style="color:#46b450;">✓ ' . __( '正常', 'anime-sync-pro' ) . '</span>',
                __( '外掛版本', 'anime-sync-pro' )          => ANIME_SYNC_PRO_VERSION,
                __( '外掛目錄', 'anime-sync-pro' )          => ANIME_SYNC_PRO_DIR,
            ];
            foreach ( $info_rows as $label => $value ) :
            ?>
                <tr>
                    <th scope="row" style="width:200px;">
                        <?php echo esc_html( $label ); ?>
                    </th>
                    <td>
                        <?php echo wp_kses( (string) $value, [ 'span' => [ 'style' => [] ] ] ); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>

</div><!-- .wrap -->

<!-- ───────────────── Inline CSS ───────────────── -->
<style>
.anime-sync-settings-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px 24px;
    margin-top: 20px;
    max-width: 900px;
}
.anime-sync-settings-card h2 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}
</style>

<!-- ───────────────── Inline JS ───────────────── -->
<script>
( function( $ ) {
    'use strict';

    /* ── Map update ── */
    $( '#btn-update-map' ).on( 'click', function () {
        const $btn = $( this );
        const $res = $( '#update-map-result' );
        $btn.prop( 'disabled', true )
            .text( '<?php esc_js( esc_html__( '下載中…', 'anime-sync-pro' ) ); ?>' );
        $res.text( '' );

        $.post( ajaxurl, {
            action : 'anime_sync_update_map',
            nonce  : animeSyncAdmin.nonce,
        }, function ( resp ) {
            $btn.prop( 'disabled', false )
                .text( '<?php esc_js( esc_html__( '立即下載 / 更新對照表', 'anime-sync-pro' ) ); ?>' );
            if ( resp.success ) {
                $res.css( 'color', '#46b450' )
                    .text( resp.data.message || '<?php esc_js( esc_html__( '更新成功', 'anime-sync-pro' ) ); ?>' );
            } else {
                $res.css( 'color', '#dc3232' )
                    .text( resp.data || '<?php esc_js( esc_html__( '更新失敗', 'anime-sync-pro' ) ); ?>' );
            }
        } );
    } );

    /* ── Clear logs ── */
    $( '#btn-clear-logs' ).on( 'click', function () {
        const $btn = $( this );
        const $res = $( '#clear-logs-result' );
        $btn.prop( 'disabled', true );

        $.post( ajaxurl, {
            action : 'anime_sync_clear_logs',
            nonce  : animeSyncAdmin.nonce,
        }, function ( resp ) {
            $btn.prop( 'disabled', false );
            if ( resp.success ) {
                $res.css( 'color', '#46b450' )
                    .text( resp.data.message || '<?php esc_js( esc_html__( '已清除', 'anime-sync-pro' ) ); ?>' );
            } else {
                $res.css( 'color', '#dc3232' )
                    .text( resp.data || '<?php esc_js( esc_html__( '清除失敗', 'anime-sync-pro' ) ); ?>' );
            }
        } );
    } );

    /* ── Clear cache ── */
    $( '#btn-clear-cache' ).on( 'click', function () {
        const $btn = $( this );
        const $res = $( '#clear-cache-result' );
        $btn.prop( 'disabled', true );

        $.post( ajaxurl, {
            action : 'anime_sync_clear_cache',
            nonce  : animeSyncAdmin.nonce,
        }, function ( resp ) {
            $btn.prop( 'disabled', false );
            const ok = resp.success;
            $res.css( 'color', ok ? '#46b450' : '#dc3232' )
                .text( ok
                    ? ( resp.data.message || '<?php esc_js( esc_html__( '快取已清除', 'anime-sync-pro' ) ); ?>' )
                    : ( resp.data        || '<?php esc_js( esc_html__( '清除失敗', 'anime-sync-pro' ) ); ?>' )
                );
        } );
    } );

    /* ── Trigger rating batch ── */
    $( '#btn-trigger-rating' ).on( 'click', function () {
        const $btn = $( this );
        const $res = $( '#trigger-rating-result' );
        $btn.prop( 'disabled', true )
            .text( '<?php esc_js( esc_html__( '觸發中…', 'anime-sync-pro' ) ); ?>' );

        $.post( ajaxurl, {
            action : 'anime_sync_trigger_rating_update',
            nonce  : animeSyncAdmin.nonce,
        }, function ( resp ) {
            $btn.prop( 'disabled', false )
                .text( '<?php esc_js( esc_html__( '立即觸發評分批次', 'anime-sync-pro' ) ); ?>' );
            const ok = resp.success;
            $res.css( 'color', ok ? '#46b450' : '#dc3232' )
                .text( ok ? ( resp.data.message || '<?php esc_js( esc_html__( '已排程', 'anime-sync-pro' ) ); ?>' )
                           : ( resp.data        || '<?php esc_js( esc_html__( '失敗', 'anime-sync-pro' ) ); ?>' ) );
        } );
    } );

    /* ── Trigger themes refetch ── */
    $( '#btn-trigger-themes' ).on( 'click', function () {
        const $btn = $( this );
        const $res = $( '#trigger-themes-result' );
        $btn.prop( 'disabled', true )
            .text( '<?php esc_js( esc_html__( '觸發中…', 'anime-sync-pro' ) ); ?>' );

        $.post( ajaxurl, {
            action : 'anime_sync_refetch_themes',
            nonce  : animeSyncAdmin.nonce,
        }, function ( resp ) {
            $btn.prop( 'disabled', false )
                .text( '<?php esc_js( esc_html__( '立即重抓所有 OP/ED', 'anime-sync-pro' ) ); ?>' );
            const ok = resp.success;
            $res.css( 'color', ok ? '#46b450' : '#dc3232' )
                .text( ok ? ( resp.data.message || '<?php esc_js( esc_html__( '已排程', 'anime-sync-pro' ) ); ?>' )
                           : ( resp.data        || '<?php esc_js( esc_html__( '失敗', 'anime-sync-pro' ) ); ?>' ) );
        } );
    } );

} )( jQuery );
</script>
