<?php
/**
 * Dashboard Page
 * 
 * @package Anime_Sync_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

// 取得統計資料
$review_queue = new Anime_Sync_Review_Queue();
$logger = new Anime_Sync_Error_Logger();

$pending_count = $review_queue->get_count('pending');
$approved_count = $review_queue->get_count('approved');

$published_count = wp_count_posts('anime');
$published_total = $published_count->publish ?? 0;

$log_stats = $logger->get_statistics(7);
?>

<div class="wrap">
    <h1>Anime Sync Pro 儀表板</h1>
    
    <div class="anime-sync-dashboard">
        
        <!-- 統計卡片 -->
        <div class="anime-sync-stats-grid">
            
            <!-- 待審核 -->
            <div class="anime-sync-stat-card">
                <div class="stat-icon">
                    <span class="dashicons dashicons-clock"></span>
                </div>
                <div class="stat-content">
                    <h3>待審核</h3>
                    <p class="stat-number"><?php echo esc_html($pending_count); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=anime-sync-queue'); ?>" class="stat-link">
                        查看佇列 →
                    </a>
                </div>
            </div>
            
            <!-- 已通過 -->
            <div class="anime-sync-stat-card">
                <div class="stat-icon">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <div class="stat-content">
                    <h3>已通過</h3>
                    <p class="stat-number"><?php echo esc_html($approved_count); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=anime-sync-queue&status=approved'); ?>" class="stat-link">
                        查看已通過 →
                    </a>
                </div>
            </div>
            
            <!-- 已發布 -->
            <div class="anime-sync-stat-card">
                <div class="stat-icon">
                    <span class="dashicons dashicons-megaphone"></span>
                </div>
                <div class="stat-content">
                    <h3>已發布</h3>
                    <p class="stat-number"><?php echo esc_html($published_total); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=anime-sync-published'); ?>" class="stat-link">
                        查看動畫 →
                    </a>
                </div>
            </div>
            
            <!-- 錯誤數 -->
            <div class="anime-sync-stat-card">
                <div class="stat-icon">
                    <span class="dashicons dashicons-warning"></span>
                </div>
                <div class="stat-content">
                    <h3>錯誤 (7天)</h3>
                    <p class="stat-number"><?php echo esc_html($log_stats['error'] + $log_stats['critical']); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=anime-sync-logs'); ?>" class="stat-link">
                        查看日誌 →
                    </a>
                </div>
            </div>
            
        </div>
        
        <!-- 快速操作 -->
        <div class="anime-sync-quick-actions">
            <h2>快速操作</h2>
            <div class="quick-actions-grid">
                <a href="<?php echo admin_url('admin.php?page=anime-sync-import'); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-download"></span>
                    匯入動畫
                </a>
                <a href="<?php echo admin_url('admin.php?page=anime-sync-queue'); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-list-view"></span>
                    審核佇列
                </a>
                <a href="<?php echo admin_url('admin.php?page=anime-sync-settings'); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-admin-settings"></span>
                    設定
                </a>
                <a href="<?php echo admin_url('edit.php?post_type=anime'); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-edit"></span>
                    管理動畫
                </a>
            </div>
        </div>
        
        <!-- 最近日誌 -->
        <div class="anime-sync-recent-logs">
            <h2>最近日誌 (7天)</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 120px;">等級</th>
                        <th>訊息</th>
                        <th style="width: 180px;">時間</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent_logs = $logger->get_recent_logs(10);
                    if (!empty($recent_logs)) {
                        foreach ($recent_logs as $log) {
                            $level_class = 'log-level-' . esc_attr($log['level']);
                            ?>
                            <tr>
                                <td>
                                    <span class="log-level-badge <?php echo $level_class; ?>">
                                        <?php echo esc_html(strtoupper($log['level'])); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html($log['message']); ?></td>
                                <td><?php echo esc_html($log['created_at']); ?></td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="3" style="text-align: center; color: #999;">
                                尚無日誌記錄
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <!-- 系統資訊 -->
        <div class="anime-sync-system-info">
            <h2>系統資訊</h2>
            <table class="wp-list-table widefat fixed">
                <tbody>
                    <tr>
                        <th style="width: 200px;">插件版本</th>
                        <td><?php echo esc_html(ANIME_SYNC_VERSION); ?></td>
                    </tr>
                    <tr>
                        <th>WordPress 版本</th>
                        <td><?php echo esc_html(get_bloginfo('version')); ?></td>
                    </tr>
                    <tr>
                        <th>PHP 版本</th>
                        <td><?php echo esc_html(PHP_VERSION); ?></td>
                    </tr>
                    <tr>
                        <th>記憶體使用</th>
                        <td>
                            <?php 
                            $memory = Anime_Sync_Performance::get_memory_usage();
                            echo esc_html($memory['current'] . ' / ' . $memory['limit']);
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>ACF 狀態</th>
                        <td>
                            <?php 
                            if (function_exists('acf')) {
                                echo '<span style="color: green;">✓ 已啟用</span>';
                            } else {
                                echo '<span style="color: red;">✗ 未安裝</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>YASR 狀態</th>
                        <td>
                            <?php 
                            if (function_exists('yasr_fs')) {
                                echo '<span style="color: green;">✓ 已啟用</span>';
                            } else {
                                echo '<span style="color: orange;">○ 未安裝 (可選)</span>';
                            }
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        
    </div>
</div>
