<?php
/**
 * Admin Page: Import Tool
 *
 * File: admin/pages/import-tool.php
 * Renders the anime import UI (single import, season batch import).
 * All heavy lifting is done via AJAX → admin/class-admin.php handlers.
 *
 * @package Anime_Sync_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$current_season_year  = (int) date( 'Y' );
$current_season_month = (int) date( 'n' );
if ( $current_season_month <= 3 )       { $current_season = 'WINTER'; }
elseif ( $current_season_month <= 6 )   { $current_season = 'SPRING'; }
elseif ( $current_season_month <= 9 )   { $current_season = 'SUMMER'; }
else                                    { $current_season = 'FALL'; }

$seasons = [ 'WINTER', 'SPRING', 'SUMMER', 'FALL' ];
$years   = range( $current_season_year + 1, 2000 );
?>

<div class="wrap anime-sync-import-tool">
    <h1><?php esc_html_e( '動畫匯入工具', 'anime-sync-pro' ); ?></h1>

    <!-- ───────────────── Tab Nav ───────────────── -->
    <nav class="nav-tab-wrapper wp-clearfix">
        <a href="#tab-single"  class="nav-tab nav-tab-active" data-tab="single">
            <?php esc_html_e( '單筆匯入', 'anime-sync-pro' ); ?>
        </a>
        <a href="#tab-season" class="nav-tab" data-tab="season">
            <?php esc_html_e( '季度批次匯入', 'anime-sync-pro' ); ?>
        </a>
        <a href="#tab-batch"  class="nav-tab" data-tab="batch">
            <?php esc_html_e( 'ID 清單批次匯入', 'anime-sync-pro' ); ?>
        </a>
    </nav>

    <!-- ═══════════════════════════════════════════
         TAB 1 — Single import
    ════════════════════════════════════════════ -->
    <div id="tab-single" class="anime-sync-tab-content" style="display:block;">
        <div class="anime-sync-card">
            <h2><?php esc_html_e( '單筆匯入', 'anime-sync-pro' ); ?></h2>
            <p class="description">
                <?php esc_html_e( '輸入 AniList ID 以取得完整資料並建立草稿文章。', 'anime-sync-pro' ); ?>
            </p>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="single-anilist-id">
                            <?php esc_html_e( 'AniList ID', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" id="single-anilist-id" class="regular-text"
                               placeholder="e.g. 21" min="1" />
                        <p class="description">
                            <?php esc_html_e( '可在 anilist.co 動畫頁面 URL 找到此 ID。', 'anime-sync-pro' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( '選項', 'anime-sync-pro' ); ?>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="single-force-update" value="1" />
                            <?php esc_html_e( '若文章已存在則強制更新（覆蓋未鎖定欄位）', 'anime-sync-pro' ); ?>
                        </label>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="button" id="btn-single-import" class="button button-primary">
                    <?php esc_html_e( '開始匯入', 'anime-sync-pro' ); ?>
                </button>
            </p>

            <!-- Progress / result -->
            <div id="single-import-result" class="anime-sync-result" style="display:none;"></div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════
         TAB 2 — Season batch
    ════════════════════════════════════════════ -->
    <div id="tab-season" class="anime-sync-tab-content" style="display:none;">
        <div class="anime-sync-card">
            <h2><?php esc_html_e( '季度批次匯入', 'anime-sync-pro' ); ?></h2>
            <p class="description">
                <?php esc_html_e( '選擇季度，系統將從 AniList 拉取該季度動畫清單，逐筆建立草稿。', 'anime-sync-pro' ); ?>
            </p>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="season-select">
                            <?php esc_html_e( '季節', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <select id="season-select">
                            <?php foreach ( $seasons as $s ) : ?>
                                <option value="<?php echo esc_attr( $s ); ?>"
                                    <?php selected( $s, $current_season ); ?>>
                                    <?php echo esc_html( $s ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="season-year-select">
                            <?php esc_html_e( '年份', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <select id="season-year-select">
                            <?php foreach ( $years as $y ) : ?>
                                <option value="<?php echo esc_attr( $y ); ?>"
                                    <?php selected( $y, $current_season_year ); ?>>
                                    <?php echo esc_html( $y ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( '格式篩選', 'anime-sync-pro' ); ?>
                    </th>
                    <td>
                        <?php
                        $formats = [ 'TV', 'TV_SHORT', 'MOVIE', 'SPECIAL', 'OVA', 'ONA', 'MUSIC' ];
                        foreach ( $formats as $f ) :
                        ?>
                            <label style="margin-right:12px;">
                                <input type="checkbox" name="season-format[]"
                                       value="<?php echo esc_attr( $f ); ?>"
                                    <?php checked( in_array( $f, [ 'TV', 'TV_SHORT', 'ONA' ] ) ); ?> />
                                <?php echo esc_html( $f ); ?>
                            </label>
                        <?php endforeach; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( '選項', 'anime-sync-pro' ); ?>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="season-skip-existing" value="1" checked />
                            <?php esc_html_e( '跳過已存在的動畫（以 AniList ID 判斷）', 'anime-sync-pro' ); ?>
                        </label><br>
                        <label>
                            <input type="checkbox" id="season-min-popularity" value="1" />
                            <?php esc_html_e( '僅匯入人氣 > 500 的動畫', 'anime-sync-pro' ); ?>
                        </label>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="button" id="btn-season-query" class="button button-secondary">
                    <?php esc_html_e( '第一步：查詢季度動畫清單', 'anime-sync-pro' ); ?>
                </button>
                <button type="button" id="btn-season-import" class="button button-primary" disabled>
                    <?php esc_html_e( '第二步：開始批次匯入', 'anime-sync-pro' ); ?>
                </button>
                <button type="button" id="btn-season-stop" class="button button-link-delete" style="display:none;">
                    <?php esc_html_e( '停止', 'anime-sync-pro' ); ?>
                </button>
            </p>

            <!-- Season anime list preview table -->
            <div id="season-preview" style="display:none;">
                <h3><?php esc_html_e( '查詢結果預覽', 'anime-sync-pro' ); ?></h3>
                <p id="season-preview-summary"></p>
                <div id="season-anime-table-wrap" style="max-height:400px;overflow-y:auto;">
                    <table class="wp-list-table widefat fixed striped" id="season-anime-table">
                        <thead>
                            <tr>
                                <th style="width:50px;">
                                    <input type="checkbox" id="season-select-all" checked />
                                </th>
                                <th><?php esc_html_e( 'AniList ID', 'anime-sync-pro' ); ?></th>
                                <th><?php esc_html_e( '英文標題', 'anime-sync-pro' ); ?></th>
                                <th><?php esc_html_e( '格式', 'anime-sync-pro' ); ?></th>
                                <th><?php esc_html_e( '集數', 'anime-sync-pro' ); ?></th>
                                <th><?php esc_html_e( '人氣', 'anime-sync-pro' ); ?></th>
                                <th><?php esc_html_e( '狀態', 'anime-sync-pro' ); ?></th>
                            </tr>
                        </thead>
                        <tbody id="season-anime-tbody"></tbody>
                    </table>
                </div>
            </div>

            <!-- Progress bar + log -->
            <div id="season-progress-wrap" style="display:none;margin-top:20px;">
                <h3><?php esc_html_e( '匯入進度', 'anime-sync-pro' ); ?></h3>
                <div class="anime-sync-progress-bar-bg">
                    <div class="anime-sync-progress-bar" id="season-progress-bar" style="width:0%;"></div>
                </div>
                <p id="season-progress-text">0 / 0</p>
                <div id="season-import-log" class="anime-sync-log" style="max-height:300px;overflow-y:auto;"></div>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════
         TAB 3 — Batch by ID list
    ════════════════════════════════════════════ -->
    <div id="tab-batch" class="anime-sync-tab-content" style="display:none;">
        <div class="anime-sync-card">
            <h2><?php esc_html_e( 'ID 清單批次匯入', 'anime-sync-pro' ); ?></h2>
            <p class="description">
                <?php esc_html_e( '每行一個 AniList ID，系統將依序匯入。', 'anime-sync-pro' ); ?>
            </p>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="batch-id-list">
                            <?php esc_html_e( 'AniList ID 清單', 'anime-sync-pro' ); ?>
                        </label>
                    </th>
                    <td>
                        <textarea id="batch-id-list" rows="12" class="large-text"
                            placeholder="21&#10;1535&#10;11061&#10;..."></textarea>
                        <p class="description" id="batch-id-count">
                            <?php esc_html_e( '0 個 ID', 'anime-sync-pro' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( '選項', 'anime-sync-pro' ); ?>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="batch-skip-existing" value="1" checked />
                            <?php esc_html_e( '跳過已存在的動畫', 'anime-sync-pro' ); ?>
                        </label><br>
                        <label>
                            <input type="checkbox" id="batch-force-update" value="1" />
                            <?php esc_html_e( '強制更新已存在的動畫（覆蓋未鎖定欄位）', 'anime-sync-pro' ); ?>
                        </label>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="button" id="btn-batch-import" class="button button-primary">
                    <?php esc_html_e( '開始批次匯入', 'anime-sync-pro' ); ?>
                </button>
                <button type="button" id="btn-batch-stop" class="button button-link-delete" style="display:none;">
                    <?php esc_html_e( '停止', 'anime-sync-pro' ); ?>
                </button>
            </p>

            <!-- Progress bar + log -->
            <div id="batch-progress-wrap" style="display:none;margin-top:20px;">
                <h3><?php esc_html_e( '匯入進度', 'anime-sync-pro' ); ?></h3>
                <div class="anime-sync-progress-bar-bg">
                    <div class="anime-sync-progress-bar" id="batch-progress-bar" style="width:0%;"></div>
                </div>
                <p id="batch-progress-text">0 / 0</p>
                <div id="batch-import-log" class="anime-sync-log" style="max-height:300px;overflow-y:auto;"></div>
            </div>
        </div>
    </div>

</div><!-- .wrap -->

<style>
.anime-sync-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px 24px;
    margin-top: 20px;
}
.anime-sync-progress-bar-bg {
    background: #e0e0e0;
    border-radius: 3px;
    height: 22px;
    width: 100%;
    max-width: 600px;
    overflow: hidden;
}
.anime-sync-progress-bar {
    background: #0073aa;
    height: 100%;
    transition: width .3s ease;
}
.anime-sync-log {
    background: #1e1e1e;
    color: #d4d4d4;
    font-family: monospace;
    font-size: 12px;
    padding: 10px;
    border-radius: 3px;
    margin-top: 8px;
}
.anime-sync-log .log-success { color: #4ec9b0; }
.anime-sync-log .log-error   { color: #f48771; }
.anime-sync-log .log-skip    { color: #9cdcfe; }
.anime-sync-log .log-info    { color: #dcdcaa; }
.anime-sync-result {
    margin-top: 16px;
    padding: 12px 16px;
    border-radius: 3px;
    border-left: 4px solid #0073aa;
    background: #f0f6fc;
}
.anime-sync-result.error {
    border-left-color: #dc3232;
    background: #fef0f0;
}
.anime-sync-result.success {
    border-left-color: #46b450;
    background: #f0fef2;
}
</style>
