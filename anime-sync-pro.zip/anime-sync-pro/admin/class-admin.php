<?php
/**
 * 檔案名稱: admin/class-admin.php
 *
 * 用途:
 *   管理後台的核心控制器。負責：
 *   - 後台選單註冊（依權限分層顯示）
 *   - AJAX 端點註冊與處理
 *   - WP-Cron 排程註冊
 *   - 管理員通知（Bangumi ID 待填入提示、記憶體警告）
 *   - 插件啟用/停用時的權限設定
 *
 * 選單權限分層：
 *   manage_options（管理員）：
 *     - 插件設定
 *     - 季度匯入工具
 *     - 季度驗證工具
 *     - anime_map.json 管理
 *     - 手動觸發更新
 *   manage_anime（Editor 以上）：
 *     - 審核佇列
 *     - 單一匯入
 *     - 批次匯入
 *     - 動畫文章編輯
 *
 * AJAX 端點清單：
 *   anime_import_single          → 單一匯入
 *   anime_import_batch           → 批次匯入
 *   anime_query_season_ids       → 查詢季度 ID 清單（第一階段）
 *   anime_import_season_batch    → 季度批次匯入（第二階段，逐筆）
 *   anime_verify_season          → 季度驗證
 *   anime_update_map             → 手動更新 anime_map.json
 *   anime_manual_update_ratings  → 手動觸發週更評分
 *   anime_manual_refetch_themes  → 手動補抓指定文章 OP/ED
 *   anime_clear_cache            → 清除插件快取
 *   anime_clear_logs             → 清除 30 天前的日誌
 *   anime_get_stats              → 取得後台統計資料
 *
 * WP-Cron 排程：
 *   anime_sync_daily_update      → 每天 03:00（台灣時間）
 *   anime_sync_weekly_update     → 每週一 04:00（台灣時間）
 *
 * 依賴：
 *   - Anime_Sync_Import_Manager
 *   - Anime_Sync_ID_Mapper
 *   - Anime_Sync_ACF_Fields
 *   - Anime_Sync_Error_Logger
 *
 * @package    AnimeSyncPro
 * @subpackage Admin
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Anime_Sync_Admin
 */
class Anime_Sync_Admin {

    // =========================================================================
    // 依賴物件
    // =========================================================================

    /** @var Anime_Sync_Import_Manager */
    private Anime_Sync_Import_Manager $import_manager;

    // =========================================================================
    // 建構函式
    // =========================================================================

    /**
     * @param Anime_Sync_Import_Manager $import_manager 匯入管理器實例。
     */
    public function __construct( Anime_Sync_Import_Manager $import_manager ) {
        $this->import_manager = $import_manager;

        // 後台選單
        add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );

        // 後台資源
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );

        // AJAX 端點（登入使用者）
        $ajax_actions = [
            'anime_import_single',
            'anime_import_batch',
            'anime_query_season_ids',
            'anime_import_season_batch',
            'anime_verify_season',
            'anime_update_map',
            'anime_manual_update_ratings',
            'anime_manual_refetch_themes',
            'anime_clear_cache',
            'anime_clear_logs',
            'anime_get_stats',
        ];
        foreach ( $ajax_actions as $action ) {
            add_action( 'wp_ajax_' . $action, [ $this, 'handle_ajax_' . str_replace( 'anime_', '', $action ) ] );
        }

        // 管理員通知
        add_action( 'admin_notices', [ $this, 'show_admin_notices' ] );

        // WP-Cron 排程
        add_action( 'init', [ $this, 'register_cron_schedules' ] );

        // save_post 勾子：人工填入 Bangumi ID 後清除 pending 旗標
        add_action( 'save_post', [ 'Anime_Sync_ID_Mapper', 'on_save_post' ], 10, 2 );
    }

    // =========================================================================
    // 後台選單
    // =========================================================================

    /**
     * 註冊後台選單，依權限分層顯示。
     *
     * @return void
     */
    public function register_admin_menu(): void {
        // 主選單：動畫同步（manage_anime 可見）
        add_menu_page(
            '動畫同步 Pro',
            '動畫同步',
            'manage_anime',
            'anime-sync-pro',
            [ $this, 'render_dashboard' ],
            'dashicons-video-alt',
            30
        );

        // 子選單：儀表板
        add_submenu_page(
            'anime-sync-pro',
            '動畫同步 Pro — 儀表板',
            '儀表板',
            'manage_anime',
            'anime-sync-pro',
            [ $this, 'render_dashboard' ]
        );

        // 子選單：匯入工具（manage_anime）
        add_submenu_page(
            'anime-sync-pro',
            '匯入工具',
            '匯入工具',
            'manage_anime',
            'anime-sync-import',
            [ $this, 'render_import_tool' ]
        );

        // 子選單：審核佇列（manage_anime）
        add_submenu_page(
            'anime-sync-pro',
            '審核佇列',
            '審核佇列',
            'manage_anime',
            'anime-sync-review',
            [ $this, 'render_review_queue' ]
        );

        // 子選單：插件設定（manage_options）
        add_submenu_page(
            'anime-sync-pro',
            '插件設定',
            '插件設定',
            'manage_options',
            'anime-sync-settings',
            [ $this, 'render_settings' ]
        );
    }

    // =========================================================================
    // 頁面渲染
    // =========================================================================

    /**
     * 渲染儀表板頁面。
     *
     * @return void
     */
    public function render_dashboard(): void {
        if ( ! current_user_can( 'manage_anime' ) ) {
            wp_die( '您沒有權限存取此頁面。' );
        }

        $pending_posts   = Anime_Sync_ID_Mapper::get_pending_posts( 10 );
        $map_status      = Anime_Sync_ID_Mapper::get_map_status();
        $daily_last_run  = get_option( 'anime_sync_daily_last_run', '從未執行' );
        $weekly_last_run = get_option( 'anime_sync_weekly_last_run', '從未執行' );

        // 統計資料
        $total_anime     = wp_count_posts( 'anime' );
        $published_count = $total_anime->publish ?? 0;
        $draft_count     = $total_anime->draft ?? 0;

        include ANIME_SYNC_PLUGIN_DIR . 'admin/pages/dashboard.php';
    }

    /**
     * 渲染匯入工具頁面。
     *
     * @return void
     */
    public function render_import_tool(): void {
        if ( ! current_user_can( 'manage_anime' ) ) {
            wp_die( '您沒有權限存取此頁面。' );
        }
        include ANIME_SYNC_PLUGIN_DIR . 'admin/pages/import-tool.php';
    }

    /**
     * 渲染審核佇列頁面。
     *
     * @return void
     */
    public function render_review_queue(): void {
        if ( ! current_user_can( 'manage_anime' ) ) {
            wp_die( '您沒有權限存取此頁面。' );
        }
        include ANIME_SYNC_PLUGIN_DIR . 'admin/pages/review-queue.php';
    }

    /**
     * 渲染插件設定頁面。
     *
     * @return void
     */
    public function render_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( '您沒有權限存取此頁面。' );
        }
        include ANIME_SYNC_PLUGIN_DIR . 'admin/pages/settings.php';
    }

    // =========================================================================
    // 後台資源載入
    // =========================================================================

    /**
     * 在後台頁面載入插件專用 CSS 與 JS。
     *
     * @param string $hook 目前頁面的 hook 名稱。
     * @return void
     */
    public function enqueue_admin_assets( string $hook ): void {
        // 只在本插件頁面載入
        $plugin_pages = [
            'toplevel_page_anime-sync-pro',
            'anime-sync_page_anime-sync-import',
            'anime-sync_page_anime-sync-review',
            'anime-sync_page_anime-sync-settings',
        ];

        if ( ! in_array( $hook, $plugin_pages, true ) ) {
            return;
        }

        // CSS
        wp_enqueue_style(
            'anime-sync-admin',
            ANIME_SYNC_PLUGIN_URL . 'admin/assets/css/admin.css',
            [],
            ANIME_SYNC_VERSION
        );

        // JS
        wp_enqueue_script(
            'anime-sync-admin',
            ANIME_SYNC_PLUGIN_URL . 'admin/assets/js/admin.js',
            [ 'jquery' ],
            ANIME_SYNC_VERSION,
            true
        );

        // 將後台資料傳遞給 JS
        wp_localize_script( 'anime-sync-admin', 'animeSyncAdmin', [
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'anime_sync_admin_nonce' ),
            'pluginUrl' => ANIME_SYNC_PLUGIN_URL,
            'strings'   => [
                'importing'      => '匯入中...',
                'success'        => '成功',
                'failed'         => '失敗',
                'skipped'        => '跳過（已存在）',
                'confirm_import' => '確定要開始匯入嗎？此操作無法撤銷。',
                'querying'       => '正在查詢季度清單...',
                'no_new_anime'   => '此季度沒有需要匯入的新作品。',
                'rate_limit'     => '已暫停（API 限速），等待中...',
                'completed'      => '全部完成！',
            ],
        ] );
    }

    // =========================================================================
    // WP-Cron 排程
    // =========================================================================

    /**
     * 註冊 WP-Cron 排程（每日更新、每週更新）。
     * 若排程已存在則跳過（冪等）。
     *
     * @return void
     */
    public function register_cron_schedules(): void {
        // 每日 03:00 台灣時間 → UTC 19:00（前一天）
        if ( ! wp_next_scheduled( 'anime_sync_daily_update' ) ) {
            $next_3am = $this->get_next_scheduled_time( 3, 0, 'Asia/Taipei' );
            wp_schedule_event( $next_3am, 'daily', 'anime_sync_daily_update' );
        }

        // 每週一 04:00 台灣時間
        if ( ! wp_next_scheduled( 'anime_sync_weekly_update' ) ) {
            $next_monday_4am = $this->get_next_monday_time( 4, 0, 'Asia/Taipei' );
            wp_schedule_event( $next_monday_4am, 'weekly', 'anime_sync_weekly_update' );
        }
    }

    /**
     * 計算下一個指定時間點的 UTC Unix timestamp。
     *
     * @param int    $hour     小時（0–23）。
     * @param int    $minute   分鐘（0–59）。
     * @param string $timezone 時區名稱（例：'Asia/Taipei'）。
     * @return int             Unix timestamp（UTC）。
     */
    private function get_next_scheduled_time( int $hour, int $minute, string $timezone ): int {
        try {
            $tz  = new DateTimeZone( $timezone );
            $now = new DateTime( 'now', $tz );
            $target = new DateTime( 'today ' . sprintf( '%02d:%02d', $hour, $minute ), $tz );

            if ( $now >= $target ) {
                $target->modify( '+1 day' );
            }

            return (int) $target->getTimestamp();
        } catch ( Exception $e ) {
            return time() + 3600;
        }
    }

    /**
     * 計算下一個週一指定時間的 UTC Unix timestamp。
     *
     * @param int    $hour     小時。
     * @param int    $minute   分鐘。
     * @param string $timezone 時區名稱。
     * @return int             Unix timestamp（UTC）。
     */
    private function get_next_monday_time( int $hour, int $minute, string $timezone ): int {
        try {
            $tz     = new DateTimeZone( $timezone );
            $now    = new DateTime( 'now', $tz );
            $target = new DateTime( 'next monday ' . sprintf( '%02d:%02d', $hour, $minute ), $tz );

            // 若今天就是週一且尚未過指定時間
            if ( '1' === $now->format( 'N' ) ) {
                $today_target = new DateTime(
                    'today ' . sprintf( '%02d:%02d', $hour, $minute ),
                    $tz
                );
                if ( $now < $today_target ) {
                    $target = $today_target;
                }
            }

            return (int) $target->getTimestamp();
        } catch ( Exception $e ) {
            return time() + 86400;
        }
    }

    // =========================================================================
    // 管理員通知
    // =========================================================================

    /**
     * 顯示後台通知：
     *   - Bangumi ID 待填入的作品數量
     *   - anime_map.json 過期警告
     *   - PHP 記憶體不足警告
     *
     * @return void
     */
    public function show_admin_notices(): void {
        if ( ! current_user_can( 'manage_anime' ) ) {
            return;
        }

        // Bangumi ID 待填入提示
        $pending_posts = Anime_Sync_ID_Mapper::get_pending_posts( 1 );
        $pending_count = count( Anime_Sync_ID_Mapper::get_pending_posts( 200 ) );
        if ( $pending_count > 0 ) {
            printf(
                '<div class="notice notice-warning is-dismissible"><p>
                    <strong>動畫同步 Pro</strong>：有 <strong>%d</strong> 部作品的 Bangumi ID 尚未找到，需要人工填入。
                    <a href="%s">前往儀表板查看</a>
                </p></div>',
                $pending_count,
                esc_url( admin_url( 'admin.php?page=anime-sync-pro' ) )
            );
        }

        // anime_map.json 過期警告（僅管理員）
        if ( current_user_can( 'manage_options' ) ) {
            $map_status = Anime_Sync_ID_Mapper::get_map_status();
            if ( $map_status['is_expired'] ) {
                printf(
                    '<div class="notice notice-warning is-dismissible"><p>
                        <strong>動畫同步 Pro</strong>：anime_map.json 已超過 24 小時未更新（上次：%s）。
                        <a href="%s">前往設定頁更新</a>
                    </p></div>',
                    esc_html( $map_status['last_updated'] ?: '從未更新' ),
                    esc_url( admin_url( 'admin.php?page=anime-sync-settings' ) )
                );
            }

            // PHP 記憶體警告（< 256MB）
            $memory_limit = (int) ini_get( 'memory_limit' );
            if ( $memory_limit > 0 && $memory_limit < 256 ) {
                printf(
                    '<div class="notice notice-error"><p>
                        <strong>動畫同步 Pro</strong>：PHP 記憶體限制為 %dMB，建議至少 256MB。
                        請在 wp-config.php 加入：<code>define(\'WP_MEMORY_LIMIT\', \'256M\');</code>
                    </p></div>',
                    $memory_limit
                );
            }
        }
    }

    // =========================================================================
    // AJAX 處理器
    // =========================================================================

    /**
     * 統一 AJAX 安全驗證（Nonce + 權限）。
     *
     * @param string $capability 所需權限（預設 manage_anime）。
     * @return void              驗證失敗時直接 wp_send_json_error 並 exit。
     */
    private function verify_ajax_request( string $capability = 'manage_anime' ): void {
        if ( ! check_ajax_referer( 'anime_sync_admin_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => '安全驗證失敗，請重新整理頁面後再試。' ], 403 );
        }
        if ( ! current_user_can( $capability ) ) {
            wp_send_json_error( [ 'message' => '您沒有執行此操作的權限。' ], 403 );
        }
    }

    /**
     * AJAX：單一匯入。
     * 權限：manage_anime
     *
     * POST 參數：
     *   nonce       : 安全 nonce
     *   anilist_id  : AniList ID（整數）
     *   bangumi_id  : Bangumi ID（整數，選填）
     *
     * @return void
     */
    public function handle_ajax_import_single(): void {
        $this->verify_ajax_request( 'manage_anime' );

        $anilist_id = (int) ( $_POST['anilist_id'] ?? 0 );
        $bangumi_id = ! empty( $_POST['bangumi_id'] ) ? (int) $_POST['bangumi_id'] : null;

        if ( $anilist_id <= 0 ) {
            wp_send_json_error( [ 'message' => '請輸入有效的 AniList ID。' ] );
        }

        $result = $this->import_manager->import_single( $anilist_id, $bangumi_id );
        wp_send_json( array_merge( [ 'status' => $result['success'] ? 'success' : 'error' ], $result ) );
    }

    /**
     * AJAX：批次匯入。
     * 權限：manage_anime
     *
     * POST 參數：
     *   nonce       : 安全 nonce
     *   anilist_ids : 逗號分隔的 AniList ID 字串，或 JSON 陣列
     *
     * @return void
     */
    public function handle_ajax_import_batch(): void {
        $this->verify_ajax_request( 'manage_anime' );

        $raw = sanitize_text_field( $_POST['anilist_ids'] ?? '' );

        // 支援逗號分隔與 JSON 陣列兩種格式
        if ( str_starts_with( trim( $raw ), '[' ) ) {
            $ids = json_decode( $raw, true );
        } else {
            $ids = array_map( 'trim', explode( ',', $raw ) );
        }

        $ids = array_filter( array_map( 'intval', (array) $ids ) );

        if ( empty( $ids ) ) {
            wp_send_json_error( [ 'message' => '請輸入至少一個有效的 AniList ID。' ] );
        }

        $result = $this->import_manager->import_batch( array_values( $ids ) );
        wp_send_json_success( $result );
    }

    /**
     * AJAX：查詢季度 ID 清單（第一階段）。
     * 權限：manage_options
     *
     * POST 參數：
     *   nonce   : 安全 nonce
     *   year    : 年份
     *   season  : 季度（WINTER/SPRING/SUMMER/FALL）
     *   formats : 作品類型陣列（選填）
     *
     * @return void
     */
    public function handle_ajax_query_season_ids(): void {
        $this->verify_ajax_request( 'manage_options' );

        $year    = (int) ( $_POST['year'] ?? date( 'Y' ) );
        $season  = strtoupper( sanitize_text_field( $_POST['season'] ?? '' ) );
        $formats = ! empty( $_POST['formats'] ) ? (array) $_POST['formats'] : [ 'TV', 'ONA', 'MOVIE', 'OVA', 'SPECIAL' ];
        $formats = array_map( 'sanitize_text_field', $formats );

        if ( ! in_array( $season, [ 'WINTER', 'SPRING', 'SUMMER', 'FALL' ], true ) ) {
            wp_send_json_error( [ 'message' => '無效的季度參數。' ] );
        }

        // 呼叫 AniList 取得季度清單
        $api_handler = new Anime_Sync_API_Handler(
            new Anime_Sync_ID_Mapper(),
            new Anime_Sync_CN_Converter()
        );
        $season_list = $api_handler->get_season_anime_ids( $year, $season, $formats );

        // 過濾已存在的
        global $wpdb;
        $existing_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE pm.meta_key = %s AND p.post_type = %s
                   AND p.post_status IN ('publish','draft','pending')",
                'anime_anilist_id',
                'anime'
            )
        );
        $existing_ids = array_map( 'intval', $existing_ids );

        $new_list      = [];
        $existing_list = [];

        foreach ( $season_list as $item ) {
            if ( in_array( $item['anilist_id'], $existing_ids, true ) ) {
                $existing_list[] = $item;
            } else {
                $new_list[] = $item;
            }
        }

        wp_send_json_success( [
            'total'         => count( $season_list ),
            'new_count'     => count( $new_list ),
            'existing_count' => count( $existing_list ),
            'new_ids'       => array_column( $new_list, 'anilist_id' ),
            'new_list'      => $new_list,
            'existing_list' => $existing_list,
        ] );
    }

    /**
     * AJAX：季度匯入（單筆，由前端 JS 逐筆呼叫）。
     * 權限：manage_options
     *
     * POST 參數：
     *   nonce      : 安全 nonce
     *   anilist_id : 單筆 AniList ID
     *
     * @return void
     */
    public function handle_ajax_import_season_batch(): void {
        $this->verify_ajax_request( 'manage_options' );

        $anilist_id = (int) ( $_POST['anilist_id'] ?? 0 );
        if ( $anilist_id <= 0 ) {
            wp_send_json_error( [ 'message' => '無效的 AniList ID。' ] );
        }

        $result = $this->import_manager->import_single( $anilist_id );
        wp_send_json_success( $result );
    }

    /**
     * AJAX：季度驗證。
     * 權限：manage_options
     *
     * POST 參數：
     *   nonce   : 安全 nonce
     *   year    : 年份
     *   season  : 季度
     *   formats : 作品類型陣列（選填）
     *
     * @return void
     */
    public function handle_ajax_verify_season(): void {
        $this->verify_ajax_request( 'manage_options' );

        $year    = (int) ( $_POST['year'] ?? date( 'Y' ) );
        $season  = strtoupper( sanitize_text_field( $_POST['season'] ?? '' ) );
        $formats = ! empty( $_POST['formats'] ) ? (array) $_POST['formats'] : [ 'TV', 'ONA', 'MOVIE', 'OVA', 'SPECIAL' ];

        if ( ! in_array( $season, [ 'WINTER', 'SPRING', 'SUMMER', 'FALL' ], true ) ) {
            wp_send_json_error( [ 'message' => '無效的季度參數。' ] );
        }

        $result = $this->import_manager->verify_season( $year, $season, $formats );
        wp_send_json_success( $result );
    }

    /**
     * AJAX：手動更新 anime_map.json。
     * 權限：manage_options
     *
     * @return void
     */
    public function handle_ajax_update_map(): void {
        $this->verify_ajax_request( 'manage_options' );

        $result = Anime_Sync_ID_Mapper::manual_update_map();
        if ( $result['success'] ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    /**
     * AJAX：手動觸發週更評分。
     * 權限：manage_options
     *
     * @return void
     */
    public function handle_ajax_manual_update_ratings(): void {
        $this->verify_ajax_request( 'manage_options' );

        $this->import_manager->update_ratings_batch();
        wp_send_json_success( [
            'message' => '評分更新任務已啟動（分批執行中），請稍後查看日誌確認進度。',
        ] );
    }

    /**
     * AJAX：手動補抓指定文章的 OP/ED。
     * 權限：manage_anime
     *
     * POST 參數：
     *   nonce   : 安全 nonce
     *   post_id : WordPress 文章 ID
     *
     * @return void
     */
    public function handle_ajax_manual_refetch_themes(): void {
        $this->verify_ajax_request( 'manage_anime' );

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( $post_id <= 0 ) {
            wp_send_json_error( [ 'message' => '無效的文章 ID。' ] );
        }

        if ( get_post_type( $post_id ) !== 'anime' ) {
            wp_send_json_error( [ 'message' => '指定文章不是動畫類型。' ] );
        }

        $success = $this->import_manager->refetch_themes( $post_id );
        if ( $success ) {
            wp_send_json_success( [ 'message' => 'OP/ED 補抓成功。' ] );
        } else {
            wp_send_json_error( [ 'message' => 'OP/ED 補抓失敗（可能該欄位已鎖定或無 MAL ID）。' ] );
        }
    }

    /**
     * AJAX：清除插件快取（Transients）。
     * 權限：manage_options
     *
     * @return void
     */
    public function handle_ajax_clear_cache(): void {
        $this->verify_ajax_request( 'manage_options' );

        global $wpdb;

        // 清除所有 anime_jikan_* Transients
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_anime_jikan_%'
                OR option_name LIKE '_transient_timeout_anime_jikan_%'"
        );

        // 清除 CN Converter 靜態快取
        Anime_Sync_CN_Converter::clear_cache();

        // 清除 ID Mapper 靜態快取
        Anime_Sync_ID_Mapper::clear_cache();

        wp_send_json_success( [ 'message' => '快取已清除。' ] );
    }

    /**
     * AJAX：清除 30 天前的錯誤日誌。
     * 權限：manage_options
     *
     * @return void
     */
    public function handle_ajax_clear_logs(): void {
        $this->verify_ajax_request( 'manage_options' );

        if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
            $deleted = Anime_Sync_Error_Logger::clear_old_logs( 30 );
            wp_send_json_success( [
                'message' => sprintf( '已清除 %d 筆 30 天前的日誌記錄。', $deleted ),
            ] );
        } else {
            wp_send_json_error( [ 'message' => '日誌系統不可用。' ] );
        }
    }

    /**
     * AJAX：取得後台統計資料（儀表板用）。
     * 權限：manage_anime
     *
     * @return void
     */
    public function handle_ajax_get_stats(): void {
        $this->verify_ajax_request( 'manage_anime' );

        $total_anime = wp_count_posts( 'anime' );

        wp_send_json_success( [
            'published'       => (int) ( $total_anime->publish ?? 0 ),
            'draft'           => (int) ( $total_anime->draft ?? 0 ),
            'pending_bangumi' => count( Anime_Sync_ID_Mapper::get_pending_posts( 200 ) ),
            'map_status'      => Anime_Sync_ID_Mapper::get_map_status(),
            'daily_last_run'  => get_option( 'anime_sync_daily_last_run', '從未執行' ),
            'weekly_last_run' => get_option( 'anime_sync_weekly_last_run', '從未執行' ),
            'memory_usage'    => round( memory_get_usage( true ) / 1048576, 1 ) . ' MB',
            'memory_limit'    => ini_get( 'memory_limit' ),
        ] );
    }

    // =========================================================================
    // 靜態方法：插件啟用 / 停用
    // =========================================================================

    /**
     * 插件啟用時執行：
     *   - 為 Editor 角色新增 manage_anime capability
     *   - 建立上傳目錄
     *   - 刷新永久連結
     *
     * @return void
     */
    public static function on_activate(): void {
        // 為 Editor 角色新增 manage_anime 權限
        $editor_role = get_role( 'editor' );
        if ( $editor_role ) {
            $editor_role->add_cap( 'manage_anime' );
        }

        // 管理員也需要有此 capability（雖然預設有 manage_options，但顯式加入更安全）
        $admin_role = get_role( 'administrator' );
        if ( $admin_role ) {
            $admin_role->add_cap( 'manage_anime' );
        }

        // 建立上傳目錄
        $upload_dir = wp_upload_dir();
        $plugin_dir = trailingslashit( $upload_dir['basedir'] ) . 'anime-sync-pro/';
        if ( ! file_exists( $plugin_dir ) ) {
            wp_mkdir_p( $plugin_dir );

            // 建立 .htaccess 防止直接訪問 JSON 檔案（非必要但增強安全性）
            file_put_contents(
                $plugin_dir . '.htaccess',
                "Options -Indexes\n<Files \"*.json\">\n  Require all granted\n</Files>\n"
            );
        }

        // 刷新永久連結（確保 anime CPT 的 URL 正常）
        flush_rewrite_rules();
    }

    /**
     * 插件停用時執行：
     *   - 移除 Editor 角色的 manage_anime capability
     *   - 清除 WP-Cron 排程
     *
     * @return void
     */
    public static function on_deactivate(): void {
        // 移除 Editor 的 manage_anime 權限
        $editor_role = get_role( 'editor' );
        if ( $editor_role ) {
            $editor_role->remove_cap( 'manage_anime' );
        }

        // 清除 Cron 排程
        $cron_hooks = [
            'anime_sync_daily_update',
            'anime_sync_weekly_update',
            'anime_sync_rating_batch',
        ];

        foreach ( $cron_hooks as $hook ) {
            $timestamp = wp_next_scheduled( $hook );
            if ( $timestamp ) {
                wp_unschedule_event( $timestamp, $hook );
            }
        }

        // 刷新永久連結
        flush_rewrite_rules();
    }
}
