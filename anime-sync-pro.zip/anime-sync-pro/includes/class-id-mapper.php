<?php
/**
 * 檔案名稱: includes/class-id-mapper.php
 *
 * 用途:
 *   負責將 AniList ID 或 MAL ID 對應到 Bangumi ID。
 *   使用三層查找策略，確保最高覆蓋率：
 *
 *   第一層：anime_map.json（BangumiExtLinker 維護的 MAL↔Bangumi 對照表）
 *           以 MAL ID 作為橋樑查詢 Bangumi ID，覆蓋率約 53–70%。
 *           本地快取 24 小時，由 WP-Cron 或手動觸發更新。
 *
 *   第二層：Bangumi 搜尋 API（/search/subject）
 *           以 AniList title.native（日文原名）搜尋，
 *           並以播出年份交叉比對，避免同名作品衝突。
 *           覆蓋率補足約 20–30%。
 *
 *   第三層：標記為「需人工填入」
 *           在文章 meta 記錄 _bangumi_id_pending = 1，
 *           後台顯示待處理提示，允許管理員手動填入 Bangumi ID。
 *
 *   預期總覆蓋率：> 90%。
 *
 * anime_map.json 格式（來源：BangumiExtLinker）:
 *   {
 *     "mal_id_1": { "bgm_id": 12345, ... },
 *     "mal_id_2": { "bgm_id": 67890, ... },
 *     ...
 *   }
 *
 * 快取策略:
 *   - anime_map.json 下載後存於 wp-content/uploads/anime-sync-pro/anime_map.json。
 *   - WP Options 記錄上次更新時間（anime_map_last_updated）。
 *   - WP-Cron 每 24 小時自動更新一次。
 *   - 後台設定頁提供手動更新按鈕。
 *   - 靜態 $map 快取：同一次 PHP 執行週期內只載入一次，
 *     批次完成後可呼叫 clear_cache() 釋放記憶體。
 *
 * 依賴:
 *   - Anime_Sync_Error_Logger（記錄查找失敗）
 *   - WordPress HTTP API（wp_remote_get / wp_remote_post）
 *   - PHP 7.4+、mbstring 擴充
 *
 * @package    AnimeSyncPro
 * @subpackage IDMapper
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Anime_Sync_ID_Mapper
 */
class Anime_Sync_ID_Mapper {

    // =========================================================================
    // 常數定義
    // =========================================================================

    /**
     * anime_map.json 遠端來源網址。
     * 由 BangumiExtLinker 專案維護，定期更新。
     *
     * @var string
     */
    const MAP_REMOTE_URL = 'https://raw.githubusercontent.com/bangumi/archive/master/aux/mal_bangumi_map.json';

    /**
     * 備用來源網址（主要來源失敗時嘗試）。
     *
     * @var string
     */
    const MAP_FALLBACK_URL = 'https://cdn.jsdelivr.net/gh/bangumi/archive@master/aux/mal_bangumi_map.json';

    /**
     * 本地快取檔案名稱。
     *
     * @var string
     */
    const MAP_FILENAME = 'anime_map.json';

    /**
     * Bangumi API 基礎網址。
     *
     * @var string
     */
    const BANGUMI_API_BASE = 'https://api.bgm.tv';

    /**
     * 快取有效期（秒）：24 小時。
     *
     * @var int
     */
    const CACHE_TTL = 86400;

    /**
     * Bangumi 搜尋 API 請求逾時（秒）。
     *
     * @var int
     */
    const REQUEST_TIMEOUT = 15;

    /**
     * Bangumi 搜尋結果年份容差（年）。
     * 允許搜尋結果與目標年份相差不超過此值。
     *
     * @var int
     */
    const YEAR_TOLERANCE = 1;

    // =========================================================================
    // 靜態快取
    // =========================================================================

    /**
     * anime_map.json 內容的靜態快取。
     * null 表示尚未載入，[] 表示已載入但為空或失敗。
     *
     * @var array|null
     */
    private static $map = null;

    /**
     * 本地快取檔案的絕對路徑。
     *
     * @var string
     */
    private static $map_file_path = '';

    // =========================================================================
    // 建構函式
    // =========================================================================

    /**
     * 建構函式：初始化本地快取路徑並掛載 WP-Cron 動作。
     */
    public function __construct() {
        self::init_map_path();
        add_action( 'anime_sync_update_anime_map', [ $this, 'download_and_cache_map' ] );
    }

    // =========================================================================
    // 主要查找方法
    // =========================================================================

    /**
     * 三層查找：根據 MAL ID 與 AniList 標題資訊取得 Bangumi ID。
     *
     * @param int|null $mal_id       MyAnimeList ID（可為 null）。
     * @param array    $anilist_data AniList 回傳的完整資料陣列，需包含：
     *                               - title.native（日文原名）
     *                               - seasonYear（播出年份）
     *                               - title.english（英文標題，備用）
     * @param int      $post_id      WordPress 文章 ID（用於記錄 pending 狀態）。
     * @return int|null              找到的 Bangumi ID，或 null（需人工填入）。
     */
    public function find_bangumi_id( ?int $mal_id, array $anilist_data, int $post_id = 0 ): ?int {

        // === 第一層：anime_map.json（MAL ID → Bangumi ID）===
        if ( ! empty( $mal_id ) ) {
            $bgm_id = $this->lookup_from_map( $mal_id );
            if ( ! empty( $bgm_id ) ) {
                $this->clear_pending_flag( $post_id );
                return (int) $bgm_id;
            }
        }

        // === 第二層：Bangumi 搜尋 API ===
        $title_native = $anilist_data['title']['native'] ?? '';
        $title_english = $anilist_data['title']['english'] ?? '';
        $season_year   = (int) ( $anilist_data['seasonYear'] ?? 0 );

        if ( ! empty( $title_native ) ) {
            $bgm_id = $this->search_bangumi_by_title( $title_native, $season_year );
            if ( ! empty( $bgm_id ) ) {
                $this->clear_pending_flag( $post_id );
                return (int) $bgm_id;
            }
        }

        // 第二層備用：以英文標題重試（部分歐美風格作品）
        if ( ! empty( $title_english ) && $title_english !== $title_native ) {
            $bgm_id = $this->search_bangumi_by_title( $title_english, $season_year );
            if ( ! empty( $bgm_id ) ) {
                $this->clear_pending_flag( $post_id );
                return (int) $bgm_id;
            }
        }

        // === 第三層：標記需人工填入 ===
        $this->set_pending_flag( $post_id, $mal_id, $title_native );

        if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
            Anime_Sync_Error_Logger::warning(
                'id_mapper',
                sprintf(
                    'Bangumi ID 查找失敗（三層均未找到）。MAL ID: %s，日文名: %s，年份: %d，文章 ID: %d',
                    $mal_id ?? 'null',
                    $title_native,
                    $season_year,
                    $post_id
                )
            );
        }

        return null;
    }

    // =========================================================================
    // 第一層：anime_map.json 查找
    // =========================================================================

    /**
     * 從本地 anime_map.json 快取查找 Bangumi ID。
     *
     * @param int $mal_id MyAnimeList ID。
     * @return int|null   找到的 Bangumi ID，或 null。
     */
    private function lookup_from_map( int $mal_id ): ?int {
        $map = $this->load_map();

        if ( empty( $map ) ) {
            return null;
        }

        $key = (string) $mal_id;

        // 格式一：{ "mal_id": { "bgm_id": 12345 } }
        if ( isset( $map[ $key ] ) ) {
            $entry = $map[ $key ];
            if ( is_array( $entry ) && ! empty( $entry['bgm_id'] ) ) {
                return (int) $entry['bgm_id'];
            }
            // 格式二：{ "mal_id": 12345 }（純數字值）
            if ( is_numeric( $entry ) && $entry > 0 ) {
                return (int) $entry;
            }
        }

        return null;
    }

    /**
     * 載入 anime_map.json 到靜態快取。
     * 若快取已存在則直接返回，否則從本地檔案讀取。
     * 若本地檔案不存在或已過期，嘗試自動下載。
     *
     * @return array 對照表陣列，失敗時返回空陣列。
     */
    private function load_map(): array {
        if ( null !== self::$map ) {
            return self::$map;
        }

        self::init_map_path();
        $file_path = self::$map_file_path;

        // 檢查本地快取是否存在且未過期
        if ( file_exists( $file_path ) ) {
            $file_age = time() - filemtime( $file_path );
            if ( $file_age < self::CACHE_TTL ) {
                $json = file_get_contents( $file_path );
                if ( false !== $json ) {
                    $decoded = json_decode( $json, true );
                    if ( is_array( $decoded ) ) {
                        self::$map = $decoded;
                        return self::$map;
                    }
                }
            }
        }

        // 本地快取不存在或已過期：嘗試下載
        $downloaded = $this->download_and_cache_map();
        if ( $downloaded && file_exists( $file_path ) ) {
            $json = file_get_contents( $file_path );
            if ( false !== $json ) {
                $decoded = json_decode( $json, true );
                if ( is_array( $decoded ) ) {
                    self::$map = $decoded;
                    return self::$map;
                }
            }
        }

        // 若下載失敗但本地有舊版本，仍使用舊版本
        if ( file_exists( $file_path ) ) {
            $json = file_get_contents( $file_path );
            if ( false !== $json ) {
                $decoded = json_decode( $json, true );
                if ( is_array( $decoded ) ) {
                    self::$map = $decoded;
                    if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                        Anime_Sync_Error_Logger::warning(
                            'id_mapper',
                            'anime_map.json 下載失敗，使用舊版本快取。'
                        );
                    }
                    return self::$map;
                }
            }
        }

        self::$map = [];
        return self::$map;
    }

    // =========================================================================
    // 第二層：Bangumi 搜尋 API
    // =========================================================================

    /**
     * 使用 Bangumi 搜尋 API 查找 Bangumi ID。
     * 以標題搜尋後，用年份交叉比對取最佳結果。
     *
     * Bangumi 搜尋 API 端點：
     *   GET /search/subject/{keywords}?type=2&responseGroup=small&max_results=5
     *   type=2 表示動畫類型。
     *
     * @param string $title       搜尋關鍵字（優先使用日文原名）。
     * @param int    $season_year 播出年份，用於比對篩選（0 表示不使用年份篩選）。
     * @return int|null           找到的 Bangumi ID，或 null。
     */
    private function search_bangumi_by_title( string $title, int $season_year ): ?int {
        if ( empty( $title ) ) {
            return null;
        }

        // 加入 1 秒延遲，避免對 Bangumi API 造成過快請求（BUG 9 修正）
        usleep( 1000000 );

        $url = sprintf(
            '%s/search/subject/%s?type=2&responseGroup=small&max_results=5',
            self::BANGUMI_API_BASE,
            rawurlencode( $title )
        );

        $response = wp_remote_get( $url, [
            'timeout'    => self::REQUEST_TIMEOUT,
            'user-agent' => $this->get_user_agent(),
            'headers'    => [
                'Accept' => 'application/json',
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                Anime_Sync_Error_Logger::warning(
                    'id_mapper',
                    'Bangumi 搜尋 API 請求失敗：' . $response->get_error_message()
                );
            }
            return null;
        }

        $http_code = wp_remote_retrieve_response_code( $response );

        // 處理 429 限速
        if ( 429 === $http_code ) {
            $retry_after = (int) wp_remote_retrieve_header( $response, 'retry-after' );
            $sleep_sec   = max( $retry_after, 3 );
            if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                Anime_Sync_Error_Logger::warning(
                    'id_mapper',
                    sprintf( 'Bangumi API 限速（429），等待 %d 秒後繼續。', $sleep_sec )
                );
            }
            sleep( $sleep_sec );
            return null; // 返回 null，讓呼叫方決定是否重試
        }

        if ( 200 !== $http_code ) {
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( empty( $data['list'] ) || ! is_array( $data['list'] ) ) {
            return null;
        }

        return $this->match_best_result( $data['list'], $season_year );
    }

    /**
     * 從 Bangumi 搜尋結果中選出最佳匹配。
     * 優先考量年份吻合度，其次為搜尋結果順序（第一筆為最相關）。
     *
     * @param array $results     Bangumi 搜尋結果陣列（list 欄位內容）。
     * @param int   $season_year 目標播出年份（0 表示不用年份篩選）。
     * @return int|null          最佳匹配的 Bangumi ID，或 null。
     */
    private function match_best_result( array $results, int $season_year ): ?int {
        if ( empty( $results ) ) {
            return null;
        }

        // 若無年份資訊，直接取第一筆結果
        if ( 0 === $season_year ) {
            $first = reset( $results );
            return isset( $first['id'] ) ? (int) $first['id'] : null;
        }

        $best_id    = null;
        $best_score = PHP_INT_MAX;

        foreach ( $results as $result ) {
            if ( empty( $result['id'] ) ) {
                continue;
            }

            // 嘗試從 air_date 欄位提取年份（格式：YYYY-MM-DD 或 YYYY）
            $result_year = 0;
            if ( ! empty( $result['air_date'] ) ) {
                if ( preg_match( '/^(\d{4})/', $result['air_date'], $m ) ) {
                    $result_year = (int) $m[1];
                }
            }

            // 年份差距
            $year_diff = ( $result_year > 0 )
                ? abs( $result_year - $season_year )
                : self::YEAR_TOLERANCE + 1; // 無年份資料，視為超出容差

            if ( $year_diff <= self::YEAR_TOLERANCE && $year_diff < $best_score ) {
                $best_score = $year_diff;
                $best_id    = (int) $result['id'];
            }
        }

        // 若年份比對均失敗，且結果只有 1 筆，作為最後嘗試取第一筆
        if ( null === $best_id && 1 === count( $results ) ) {
            $first = reset( $results );
            $best_id = isset( $first['id'] ) ? (int) $first['id'] : null;
        }

        return $best_id;
    }

    // =========================================================================
    // anime_map.json 下載與更新
    // =========================================================================

    /**
     * 下載最新的 anime_map.json 並儲存至本地快取。
     * 同時更新 WP Options 中的上次更新時間。
     * 此方法由 WP-Cron 或手動觸發呼叫。
     *
     * @return bool 下載並儲存成功返回 true，否則返回 false。
     */
    public function download_and_cache_map(): bool {
        self::init_map_path();

        // 嘗試主要來源
        $result = $this->fetch_remote_map( self::MAP_REMOTE_URL );

        // 主要來源失敗，嘗試備用來源
        if ( false === $result ) {
            $result = $this->fetch_remote_map( self::MAP_FALLBACK_URL );
        }

        if ( false === $result ) {
            if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                Anime_Sync_Error_Logger::error(
                    'id_mapper',
                    'anime_map.json 下載失敗（主要來源與備用來源均無法取得）。'
                );
            }
            return false;
        }

        // 驗證 JSON 格式
        $decoded = json_decode( $result, true );
        if ( ! is_array( $decoded ) || empty( $decoded ) ) {
            if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                Anime_Sync_Error_Logger::error(
                    'id_mapper',
                    'anime_map.json 下載成功但 JSON 解析失敗或內容為空。'
                );
            }
            return false;
        }

        // 確保目錄存在
        $dir = dirname( self::$map_file_path );
        if ( ! file_exists( $dir ) ) {
            wp_mkdir_p( $dir );
        }

        // 寫入本地快取
        $written = file_put_contents( self::$map_file_path, $result );
        if ( false === $written ) {
            if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                Anime_Sync_Error_Logger::error(
                    'id_mapper',
                    'anime_map.json 寫入本地快取失敗，請確認 uploads 目錄有寫入權限。'
                );
            }
            return false;
        }

        // 更新上次更新時間與詞條數量
        $now = current_time( 'mysql' );
        update_option( 'anime_map_last_updated', $now, false );
        update_option( 'anime_map_entry_count', count( $decoded ), false );

        // 清除靜態快取，強制下次重新讀取新版本
        self::$map = null;

        if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
            Anime_Sync_Error_Logger::info(
                'id_mapper',
                sprintf(
                    'anime_map.json 更新成功。詞條數：%d，更新時間：%s',
                    count( $decoded ),
                    $now
                )
            );
        }

        return true;
    }

    /**
     * 從指定 URL 下載 anime_map.json 原始內容。
     *
     * @param string $url 遠端下載網址。
     * @return string|false 下載成功返回 JSON 字串，失敗返回 false。
     */
    private function fetch_remote_map( string $url ): string|false {
        $response = wp_remote_get( $url, [
            'timeout'    => 60, // anime_map.json 較大，給予較長逾時
            'user-agent' => $this->get_user_agent(),
        ] );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $http_code = wp_remote_retrieve_response_code( $response );
        if ( 200 !== $http_code ) {
            return false;
        }

        $body = wp_remote_retrieve_body( $response );
        if ( empty( $body ) ) {
            return false;
        }

        return $body;
    }

    // =========================================================================
    // Pending 旗標管理（第三層輔助）
    // =========================================================================

    /**
     * 設定「Bangumi ID 待人工填入」旗標。
     * 後台審核佇列與設定頁將讀取此旗標顯示提示。
     *
     * @param int      $post_id     WordPress 文章 ID（0 表示不記錄）。
     * @param int|null $mal_id      MAL ID（供提示用）。
     * @param string   $title       日文原名（供提示用）。
     * @return void
     */
    private function set_pending_flag( int $post_id, ?int $mal_id, string $title ): void {
        if ( $post_id <= 0 ) {
            return;
        }

        update_post_meta( $post_id, '_bangumi_id_pending', 1 );
        update_post_meta( $post_id, '_bangumi_id_pending_info', wp_json_encode( [
            'mal_id'     => $mal_id,
            'title'      => $title,
            'checked_at' => current_time( 'mysql' ),
        ] ) );
    }

    /**
     * 清除「Bangumi ID 待人工填入」旗標。
     * 在成功找到 Bangumi ID 後呼叫。
     *
     * @param int $post_id WordPress 文章 ID（0 表示跳過）。
     * @return void
     */
    private function clear_pending_flag( int $post_id ): void {
        if ( $post_id <= 0 ) {
            return;
        }
        delete_post_meta( $post_id, '_bangumi_id_pending' );
        delete_post_meta( $post_id, '_bangumi_id_pending_info' );
    }

    // =========================================================================
    // 快取狀態查詢（供後台設定頁使用）
    // =========================================================================

    /**
     * 取得 anime_map.json 的快取狀態資訊。
     * 供後台設定頁顯示使用。
     *
     * @return array {
     *     @type bool   $exists        本地快取檔案是否存在。
     *     @type int    $file_size     檔案大小（bytes），-1 表示不存在。
     *     @type string $last_updated  上次更新時間（MySQL 格式），空字串表示從未更新。
     *     @type int    $entry_count   詞條數量。
     *     @type int    $age_seconds   快取距今秒數（-1 表示不存在）。
     *     @type bool   $is_expired    快取是否已過期（> 24 小時）。
     *     @type string $file_path     本地快取路徑。
     * }
     */
    public static function get_map_status(): array {
        self::init_map_path();
        $path    = self::$map_file_path;
        $exists  = file_exists( $path );
        $age     = $exists ? ( time() - filemtime( $path ) ) : -1;

        return [
            'exists'       => $exists,
            'file_size'    => $exists ? filesize( $path ) : -1,
            'last_updated' => get_option( 'anime_map_last_updated', '' ),
            'entry_count'  => (int) get_option( 'anime_map_entry_count', 0 ),
            'age_seconds'  => $age,
            'is_expired'   => ( $age < 0 || $age >= self::CACHE_TTL ),
            'file_path'    => $path,
        ];
    }

    /**
     * 取得所有「Bangumi ID 待人工填入」的文章清單。
     * 供後台設定頁或審核佇列顯示。
     *
     * @param int $limit 最多返回幾筆，預設 50。
     * @return array 文章資料陣列，每筆包含 post_id、post_title、pending_info。
     */
    public static function get_pending_posts( int $limit = 50 ): array {
        $query = new WP_Query( [
            'post_type'      => 'anime',
            'post_status'    => [ 'publish', 'draft', 'pending' ],
            'posts_per_page' => $limit,
            'meta_query'     => [
                [
                    'key'     => '_bangumi_id_pending',
                    'value'   => '1',
                    'compare' => '=',
                ],
            ],
            'fields'         => 'ids',
        ] );

        $results = [];
        foreach ( $query->posts as $post_id ) {
            $info = get_post_meta( $post_id, '_bangumi_id_pending_info', true );
            $results[] = [
                'post_id'      => $post_id,
                'post_title'   => get_the_title( $post_id ),
                'edit_url'     => get_edit_post_link( $post_id, 'raw' ),
                'pending_info' => $info ? json_decode( $info, true ) : [],
            ];
        }

        return $results;
    }

    // =========================================================================
    // 靜態輔助方法
    // =========================================================================

    /**
     * 初始化本地快取檔案路徑。
     * 路徑：wp-content/uploads/anime-sync-pro/anime_map.json
     *
     * @return void
     */
    private static function init_map_path(): void {
        if ( ! empty( self::$map_file_path ) ) {
            return;
        }

        $upload_dir        = wp_upload_dir();
        $plugin_upload_dir = trailingslashit( $upload_dir['basedir'] ) . 'anime-sync-pro/';
        self::$map_file_path = $plugin_upload_dir . self::MAP_FILENAME;
    }

    /**
     * 清除靜態 map 快取，釋放記憶體。
     * 建議在季度批次匯入結束後呼叫。
     *
     * @return void
     */
    public static function clear_cache(): void {
        self::$map = null;
    }

    /**
     * 產生標準 User-Agent 字串。
     * Bangumi API 要求請求必須帶有有效的 User-Agent（BUG 2 修正）。
     *
     * @return string User-Agent 字串。
     */
    private function get_user_agent(): string {
        $site_name = get_bloginfo( 'name' );
        $site_url  = get_site_url();
        return sprintf(
            'AnimeSyncPro/1.0 (%s; %s; contact@weixiaoacg.com)',
            $site_name,
            $site_url
        );
    }

    /**
     * 手動觸發 anime_map.json 更新（AJAX 動作的後端處理）。
     * 此靜態方法供 admin/class-admin.php 的 AJAX handler 呼叫。
     *
     * @return array {
     *     @type bool   $success 是否成功。
     *     @type string $message 結果訊息。
     *     @type array  $status  更新後的快取狀態。
     * }
     */
    public static function manual_update_map(): array {
        $instance = new self();
        $success  = $instance->download_and_cache_map();

        return [
            'success' => $success,
            'message' => $success
                ? 'anime_map.json 更新成功。'
                : 'anime_map.json 更新失敗，請查閱錯誤日誌。',
            'status'  => self::get_map_status(),
        ];
    }

    /**
     * 直接以 MAL ID 查詢 Bangumi ID（不執行第二、三層）。
     * 供已知 MAL ID 的快速查詢使用。
     *
     * @param int $mal_id MAL ID。
     * @return int|null Bangumi ID 或 null。
     */
    public function quick_lookup_by_mal( int $mal_id ): ?int {
        return $this->lookup_from_map( $mal_id );
    }

    /**
     * 在文章儲存後，若 Bangumi ID 已被人工填入，
     * 自動清除 pending 旗標並更新快取。
     * 供 save_post 勾子使用。
     *
     * @param int     $post_id WordPress 文章 ID。
     * @param WP_Post $post    文章物件。
     * @return void
     */
    public static function on_save_post( int $post_id, WP_Post $post ): void {
        if ( 'anime' !== $post->post_type ) {
            return;
        }

        $bangumi_id = get_post_meta( $post_id, 'anime_bangumi_id', true );
        if ( ! empty( $bangumi_id ) && (int) $bangumi_id > 0 ) {
            delete_post_meta( $post_id, '_bangumi_id_pending' );
            delete_post_meta( $post_id, '_bangumi_id_pending_info' );
        }
    }
}

// 掛載 save_post 勾子，監聽人工填入 Bangumi ID 的動作
add_action( 'save_post', [ 'Anime_Sync_ID_Mapper', 'on_save_post' ], 10, 2 );
