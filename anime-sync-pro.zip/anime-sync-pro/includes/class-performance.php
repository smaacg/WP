<?php
/**
 * Performance Optimizer
 * 
 * @package Anime_Sync_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class Anime_Sync_Performance {
    
    /**
     * Batch update ACF fields (disable filters for performance)
     * 
     * @param int $post_id Post ID
     * @param array $fields ACF field data
     */
    public static function batch_update_acf($post_id, $fields) {
        // 暫時停用 ACF 過濾器
        acf_disable_filters();
        
        foreach ($fields as $field_name => $value) {
            update_post_meta($post_id, $field_name, $value);
        }
        
        // 重新啟用過濾器
        acf_enable_filters();
    }
    
    /**
     * Clear memory
     */
    public static function clear_memory() {
        wp_cache_flush();
        gc_collect_cycles();
    }
    
    /**
     * Batch process with memory management
     * 
     * @param array $items Items to process
     * @param callable $callback Processing function
     * @param int $batch_size Batch size
     * @return array Results
     */
    public static function batch_process($items, $callback, $batch_size = 15) {
        $results = array();
        $total = count($items);
        $batches = array_chunk($items, $batch_size);
        
        foreach ($batches as $batch_index => $batch) {
            foreach ($batch as $item) {
                $results[] = call_user_func($callback, $item);
            }
            
            // 每個批次後清理記憶體
            self::clear_memory();
            
            // 短暫延遲避免過載
            usleep(100000); // 100ms
        }
        
        return $results;
    }
    
    /**
     * Get items from database efficiently (avoid WP_Query overhead)
     * 
     * @param int $limit Limit
     * @param string $status Status filter
     * @return array Items
     */
    public static function get_queue_items_raw($limit = 20, $status = 'pending') {
        global $wpdb;
        
        $table = $wpdb->prefix . 'anime_review_queue';
        
        $query = $wpdb->prepare(
            "SELECT id, anilist_id, api_data, status, source, created_at
            FROM {$table}
            WHERE status = %s
            ORDER BY created_at DESC
            LIMIT %d",
            $status,
            absint($limit)
        );
        
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    /**
     * Compress JSON data
     * 
     * @param array $data Data to compress
     * @return string Compressed data
     */
    public static function compress_json($data) {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        return gzcompress($json, 9);
    }
    
    /**
     * Decompress JSON data
     * 
     * @param string $compressed Compressed data
     * @return array|false Decompressed data or false
     */
    public static function decompress_json($compressed) {
        $json = gzuncompress($compressed);
        if ($json === false) {
            return false;
        }
        return json_decode($json, true);
    }
    
    /**
     * Set execution time limit
     * 
     * @param int $seconds Seconds
     */
    public static function set_time_limit($seconds = 60) {
        if (function_exists('set_time_limit') && !ini_get('safe_mode')) {
            @set_time_limit($seconds);
        }
    }
    
    /**
     * Increase memory limit
     * 
     * @param string $limit Memory limit (e.g., '512M')
     */
    public static function increase_memory_limit($limit = '512M') {
        if (function_exists('ini_set')) {
            @ini_set('memory_limit', $limit);
        }
    }
    
    /**
     * Get current memory usage
     * 
     * @return array Memory info
     */
    public static function get_memory_usage() {
        return array(
            'current' => size_format(memory_get_usage(true)),
            'peak' => size_format(memory_get_peak_usage(true)),
            'limit' => ini_get('memory_limit')
        );
    }
    
    /**
     * Cache API response
     * 
     * @param string $key Cache key
     * @param mixed $data Data to cache
     * @param int $expiration Expiration in seconds
     */
    public static function cache_set($key, $data, $expiration = 3600) {
        set_transient('anime_sync_cache_' . $key, $data, $expiration);
    }
    
    /**
     * Get cached API response
     * 
     * @param string $key Cache key
     * @return mixed|false Cached data or false
     */
    public static function cache_get($key) {
        return get_transient('anime_sync_cache_' . $key);
    }
    
    /**
     * Clear all caches
     */
    public static function clear_all_caches() {
        global $wpdb;
        
        // 刪除所有 anime_sync_cache_ 開頭的 transient
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
            WHERE option_name LIKE '_transient_anime_sync_cache_%'
            OR option_name LIKE '_transient_timeout_anime_sync_cache_%'"
        );
        
        wp_cache_flush();
    }
}
