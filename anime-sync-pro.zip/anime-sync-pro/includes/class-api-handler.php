<?php
/**
 * 檔案名稱: includes/class-api-handler.php
 *
 * 用途:
 *   集中管理所有外部 API 請求，提供統一的資料取得介面。
 *   整合四個資料來源：AniList、Bangumi、AnimeThemes、Jikan（MAL）。
 *
 * 重要修正（依對話確認的 BUG 清單）:
 *   BUG 2  - Bangumi 所有請求強制帶 User-Agent header。
 *   BUG 3  - AniList 動態讀取 X-RateLimit-Remaining 與 Retry-After，
 *             Remaining < 5 時主動暫停，429 時依 Retry-After 等待。
 *   BUG 8  - 集數（episodes）只取自 AniList，不混用離線資料庫數值。
 *   BUG 9  - Bangumi 三個子請求（subject / characters / persons）
 *             各加 1.2 秒間隔，避免觸發每秒限制。
 *   BUG 10 - 已併入 BUG 3（動態 Retry-After）。
 *
 * API 速率限制（2026-04 確認值）:
 *   AniList      : 30 req/min（降速後），讀取 X-RateLimit-Remaining
 *   Bangumi      : ~1–2 req/s（非官方），每次請求間隔 1.2 秒
 *   AnimeThemes  : 90 req/min
 *   Jikan (MAL)  : 60 req/min、3 req/s（24 小時快取）
 *
 * 請求架構:
 *   舊版 parallel_requests()（cURL multi 並發）已改為序列請求，
 *   每個 API 依序呼叫，並在各 API 之間插入適當延遲，
 *   避免同時觸發多個 API 的速率限制（對話確認修正）。
 *
 * 資料回傳格式（get_all_data() 統一結構）:
 *   請參閱 merge_api_data() 方法的 @return 說明。
 *
 * 依賴:
 *   - Anime_Sync_ID_Mapper
 *   - Anime_Sync_CN_Converter
 *   - Anime_Sync_Error_Logger
 *   - WordPress HTTP API（wp_remote_get / wp_remote_post）
 *   - PHP 7.4+、mbstring
 *
 * @package    AnimeSyncPro
 * @subpackage APIHandler
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Anime_Sync_API_Handler
 */
class Anime_Sync_API_Handler {

    // =========================================================================
    // 常數定義
    // =========================================================================

    /** AniList GraphQL 端點 */
    const ANILIST_ENDPOINT = 'https://graphql.anilist.co';

    /** Bangumi API v0 基礎網址 */
    const BANGUMI_ENDPOINT = 'https://api.bgm.tv';

    /** AnimeThemes REST API 基礎網址 */
    const ANIMETHEMES_ENDPOINT = 'https://api.animethemes.moe';

    /** Jikan API v4 基礎網址 */
    const JIKAN_ENDPOINT = 'https://api.jikan.moe/v4';

    /** 一般請求逾時（秒） */
    const REQUEST_TIMEOUT = 20;

    /** AniList 安全閾值：當 Remaining <= 此值時主動暫停 */
    const ANILIST_SAFE_REMAINING = 5;

    /** AniList 主動暫停秒數（當 Remaining 低於安全閾值時） */
    const ANILIST_PAUSE_SECONDS = 10;

    /** Bangumi 子請求間隔（微秒）：1.2 秒 */
    const BANGUMI_INTERVAL_US = 1200000;

    /** AnimeThemes 請求間隔（微秒）：0.7 秒 */
    const ANIMETHEMES_INTERVAL_US = 700000;

    /** Jikan 請求間隔（微秒）：1 秒（遵守 3 req/s 限制） */
    const JIKAN_INTERVAL_US = 1000000;

    /**
     * Bangumi STAFF 允許顯示的職位清單（中文）。
     * 依優先顯示順序排列。
     *
     * @var array
     */
    const BANGUMI_ALLOWED_ROLES = [
        '原作',
        '導演',
        '系列構成',
        '腳本',
        '人物設計',
        '總作畫監督',
        '作畫監督',
        '音樂',
        '音響監督',
        '美術監督',
        '色彩設計',
        '攝影監督',
        '3D導演',
        '機械設計',
        '道具設計',
        '製片人',
        '製作人',
        '執行製作',
    ];

    // =========================================================================
    // 依賴物件
    // =========================================================================

    /** @var Anime_Sync_ID_Mapper */
    private Anime_Sync_ID_Mapper $id_mapper;

    /** @var Anime_Sync_CN_Converter */
    private Anime_Sync_CN_Converter $cn_converter;

    // =========================================================================
    // 建構函式
    // =========================================================================

    /**
     * 建構函式：注入依賴物件。
     *
     * @param Anime_Sync_ID_Mapper    $id_mapper    ID 映射器實例。
     * @param Anime_Sync_CN_Converter $cn_converter 簡繁轉換器實例。
     */
    public function __construct(
        Anime_Sync_ID_Mapper $id_mapper,
        Anime_Sync_CN_Converter $cn_converter
    ) {
        $this->id_mapper    = $id_mapper;
        $this->cn_converter = $cn_converter;
    }

    // =========================================================================
    // 主要聚合方法
    // =========================================================================

    /**
     * 取得單一動畫的完整資料（主入口）。
     *
     * 執行順序（序列，非並發）：
     *   1. AniList GraphQL → 取得基本資料與 MAL ID
     *   2. ID Mapper       → 解析 Bangumi ID（三層查找）
     *   3. Bangumi Subject → 取得中文標題、簡介、評分
     *   4. Bangumi Characters → 取得 CAST 資料
     *   5. Bangumi Persons    → 取得 STAFF 資料
     *   6. Jikan (MAL)     → 取得 MAL 評分（若有 MAL ID）
     *   7. AnimeThemes     → 取得 OP/ED 資料（若有 MAL ID）
     *
     * @param int      $anilist_id  AniList 作品 ID（必填）。
     * @param int|null $bangumi_id  已知的 Bangumi ID（選填，跳過 ID 查找）。
     * @param int      $post_id     WordPress 文章 ID（供 ID Mapper 記錄 pending）。
     * @return array                統一格式的完整資料陣列，含 'errors' 子陣列。
     */
    public function get_all_data( int $anilist_id, ?int $bangumi_id = null, int $post_id = 0 ): array {
        $errors = [];

        // ── 步驟 1：AniList ──────────────────────────────────────────────────
        $anilist_data = $this->get_anilist_data( $anilist_id );
        if ( is_wp_error( $anilist_data ) ) {
            $errors['anilist'] = $anilist_data->get_error_message();
            return $this->empty_result( $errors );
        }

        $mal_id = ! empty( $anilist_data['idMal'] ) ? (int) $anilist_data['idMal'] : null;

        // ── 步驟 2：Bangumi ID 解析 ──────────────────────────────────────────
        if ( null === $bangumi_id ) {
            $bangumi_id = $this->id_mapper->find_bangumi_id( $mal_id, $anilist_data, $post_id );
        }

        // ── 步驟 3–5：Bangumi 資料（三個序列請求，各間隔 1.2 秒）───────────
        $bangumi_subject    = null;
        $bangumi_characters = [];
        $bangumi_staff      = [];

        if ( ! empty( $bangumi_id ) ) {
            $bangumi_subject = $this->get_bangumi_subject( $bangumi_id );
            if ( is_wp_error( $bangumi_subject ) ) {
                $errors['bangumi_subject'] = $bangumi_subject->get_error_message();
                $bangumi_subject = null;
            }

            usleep( self::BANGUMI_INTERVAL_US );

            $bgm_chars = $this->get_bangumi_characters( $bangumi_id );
            if ( is_wp_error( $bgm_chars ) ) {
                $errors['bangumi_characters'] = $bgm_chars->get_error_message();
            } else {
                $bangumi_characters = $bgm_chars;
            }

            usleep( self::BANGUMI_INTERVAL_US );

            $bgm_staff = $this->get_bangumi_staff( $bangumi_id );
            if ( is_wp_error( $bgm_staff ) ) {
                $errors['bangumi_staff'] = $bgm_staff->get_error_message();
            } else {
                $bangumi_staff = $bgm_staff;
            }
        }

        // ── 步驟 6：Jikan（MAL 評分）────────────────────────────────────────
        $jikan_data = null;
        if ( ! empty( $mal_id ) ) {
            usleep( self::JIKAN_INTERVAL_US );
            $jikan_result = $this->get_jikan_data( $mal_id );
            if ( ! is_wp_error( $jikan_result ) ) {
                $jikan_data = $jikan_result;
            } else {
                $errors['jikan'] = $jikan_result->get_error_message();
            }
        }

        // ── 步驟 7：AnimeThemes（OP/ED）─────────────────────────────────────
        $themes_data = [];
        if ( ! empty( $mal_id ) ) {
            usleep( self::ANIMETHEMES_INTERVAL_US );
            $themes_result = $this->get_animethemes_data( $mal_id );
            if ( ! is_wp_error( $themes_result ) ) {
                $themes_data = $themes_result;
            } else {
                $errors['animethemes'] = $themes_result->get_error_message();
            }
        }

        // ── 合併所有資料 ─────────────────────────────────────────────────────
        return $this->merge_api_data(
            $anilist_data,
            $bangumi_subject,
            $bangumi_characters,
            $bangumi_staff,
            $jikan_data,
            $themes_data,
            $bangumi_id,
            $errors
        );
    }

    // =========================================================================
    // AniList API
    // =========================================================================

    /**
     * 取得單一動畫的 AniList 完整資料。
     *
     * @param int $anilist_id AniList 作品 ID。
     * @return array|WP_Error 成功返回資料陣列，失敗返回 WP_Error。
     */
    public function get_anilist_data( int $anilist_id ): array|WP_Error {
        $query = '
        query ($id: Int) {
            Media(id: $id, type: ANIME) {
                id
                idMal
                title {
                    romaji
                    english
                    native
                }
                format
                status
                description(asHtml: false)
                startDate { year month day }
                endDate { year month day }
                season
                seasonYear
                episodes
                duration
                source
                coverImage {
                    extraLarge
                    large
                    color
                }
                bannerImage
                genres
                popularity
                rankings {
                    rank
                    type
                    context
                    allTime
                }
                averageScore
                meanScore
                studios(isMain: true) {
                    nodes { name }
                }
                nextAiringEpisode {
                    airingAt
                    episode
                }
                externalLinks {
                    url
                    site
                    type
                }
                trailer {
                    id
                    site
                }
            }
        }';

        $result = $this->anilist_request( $query, [ 'id' => $anilist_id ] );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        if ( empty( $result['data']['Media'] ) ) {
            return new WP_Error(
                'anilist_empty',
                sprintf( 'AniList ID %d 無對應資料。', $anilist_id )
            );
        }

        return $result['data']['Media'];
    }

    /**
     * 取得指定季度的所有動畫 AniList ID 清單（分頁，每頁 50 筆）。
     *
     * @param int    $year    年份（例：2026）。
     * @param string $season  季度（WINTER / SPRING / SUMMER / FALL）。
     * @param array  $formats 作品類型篩選，預設 TV + ONA + MOVIE + OVA + SPECIAL。
     * @return array          動畫資料陣列，每筆含 anilist_id、mal_id、format、title。
     */
    public function get_season_anime_ids(
        int $year,
        string $season,
        array $formats = [ 'TV', 'ONA', 'MOVIE', 'OVA', 'SPECIAL' ]
    ): array {
        $query = '
        query ($year: Int, $season: MediaSeason, $formats: [MediaFormat], $page: Int) {
            Page(page: $page, perPage: 50) {
                pageInfo { hasNextPage currentPage }
                media(seasonYear: $year, season: $season, format_in: $formats, type: ANIME, sort: POPULARITY_DESC) {
                    id
                    idMal
                    format
                    title { romaji native english }
                    status
                    episodes
                }
            }
        }';

        $results  = [];
        $page     = 1;
        $has_next = true;

        while ( $has_next ) {
            $response = $this->anilist_request( $query, [
                'year'    => $year,
                'season'  => $season,
                'formats' => $formats,
                'page'    => $page,
            ] );

            if ( is_wp_error( $response ) ) {
                break;
            }

            $media_list = $response['data']['Page']['media'] ?? [];
            $has_next   = $response['data']['Page']['pageInfo']['hasNextPage'] ?? false;

            foreach ( $media_list as $item ) {
                $results[] = [
                    'anilist_id' => (int) $item['id'],
                    'mal_id'     => ! empty( $item['idMal'] ) ? (int) $item['idMal'] : null,
                    'format'     => $item['format'] ?? 'TV',
                    'title'      => $item['title'] ?? [],
                    'status'     => $item['status'] ?? '',
                    'episodes'   => $item['episodes'] ?? null,
                ];
            }

            $page++;

            // 分頁間加入延遲，避免連續打 AniList 過快
            if ( $has_next ) {
                usleep( 500000 ); // 0.5 秒
            }
        }

        return $results;
    }

    /**
     * 發送 AniList GraphQL 請求，含動態速率限制處理（BUG 3 修正）。
     *
     * 處理邏輯：
     *   1. 發送請求前檢查靜態 $anilist_remaining，若 <= ANILIST_SAFE_REMAINING，主動暫停。
     *   2. 收到回應後更新 $anilist_remaining。
     *   3. 若收到 429，讀取 Retry-After header，等待後重試一次（最多重試 3 次）。
     *
     * @param string $query     GraphQL 查詢字串。
     * @param array  $variables GraphQL 變數陣列。
     * @param int    $retry     目前重試次數（內部遞迴使用）。
     * @return array|WP_Error   成功返回解碼後的回應陣列，失敗返回 WP_Error。
     */
    public function anilist_request( string $query, array $variables = [], int $retry = 0 ): array|WP_Error {
        // 主動限速：Remaining 過低時先暫停
        if ( self::get_anilist_remaining() <= self::ANILIST_SAFE_REMAINING ) {
            sleep( self::ANILIST_PAUSE_SECONDS );
        }

        $response = wp_remote_post( self::ANILIST_ENDPOINT, [
            'timeout'     => self::REQUEST_TIMEOUT,
            'headers'     => [
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ],
            'body'        => wp_json_encode( [
                'query'     => $query,
                'variables' => $variables,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $http_code = wp_remote_retrieve_response_code( $response );
        $headers   = wp_remote_retrieve_headers( $response );

        // 更新 Remaining 快取
        $remaining = (int) ( $headers['x-ratelimit-remaining'] ?? 90 );
        self::set_anilist_remaining( $remaining );

        // 處理 429 Too Many Requests
        if ( 429 === $http_code ) {
            if ( $retry >= 3 ) {
                return new WP_Error(
                    'anilist_rate_limit',
                    'AniList API 速率限制：已達最大重試次數（3 次）。'
                );
            }

            $retry_after = (int) ( $headers['retry-after'] ?? 30 );
            $sleep_sec   = max( $retry_after, 5 );

            if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                Anime_Sync_Error_Logger::warning(
                    'api_handler',
                    sprintf( 'AniList 429：等待 %d 秒後重試（第 %d 次）。', $sleep_sec, $retry + 1 )
                );
            }

            sleep( $sleep_sec );
            return $this->anilist_request( $query, $variables, $retry + 1 );
        }

        if ( $http_code < 200 || $http_code >= 300 ) {
            return new WP_Error(
                'anilist_http_error',
                sprintf( 'AniList API HTTP 錯誤：%d', $http_code )
            );
        }

        $body    = wp_remote_retrieve_body( $response );
        $decoded = json_decode( $body, true );

        if ( ! is_array( $decoded ) ) {
            return new WP_Error( 'anilist_json_error', 'AniList API 回應 JSON 解析失敗。' );
        }

        if ( ! empty( $decoded['errors'] ) ) {
            $msg = $decoded['errors'][0]['message'] ?? '未知錯誤';
            return new WP_Error( 'anilist_graphql_error', 'AniList GraphQL 錯誤：' . $msg );
        }

        return $decoded;
    }

    // =========================================================================
    // AniList Remaining 靜態計數器
    // =========================================================================

    /** @var int AniList 剩餘請求數靜態快取 */
    private static int $anilist_remaining = 90;

    /**
     * 取得目前 AniList 剩餘請求數。
     *
     * @return int
     */
    private static function get_anilist_remaining(): int {
        return self::$anilist_remaining;
    }

    /**
     * 更新 AniList 剩餘請求數。
     *
     * @param int $remaining 最新的剩餘請求數。
     * @return void
     */
    private static function set_anilist_remaining( int $remaining ): void {
        self::$anilist_remaining = $remaining;
    }

    // =========================================================================
    // Bangumi API
    // =========================================================================

    /**
     * 取得 Bangumi 作品基本資訊（Subject）。
     *
     * @param int $bangumi_id Bangumi 作品 ID。
     * @return array|WP_Error 成功返回資料陣列，失敗返回 WP_Error。
     */
    public function get_bangumi_subject( int $bangumi_id ): array|WP_Error {
        $url      = sprintf( '%s/v0/subjects/%d', self::BANGUMI_ENDPOINT, $bangumi_id );
        $response = $this->bangumi_request( $url );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        return $response;
    }

    /**
     * 取得 Bangumi 作品角色列表（CAST）。
     *
     * 回傳格式（每筆）：
     *   char_name_zh  : 角色中文名（優先 name_cn，空則用 name）
     *   char_name_ja  : 角色日文名（name 欄位）
     *   char_image    : 角色圖片 URL
     *   role          : 角色關係（主角 / 配角 / 闲角 / 旁白）
     *   va_name       : 聲優日文姓名
     *   va_image      : 聲優圖片 URL
     *
     * @param int $bangumi_id Bangumi 作品 ID。
     * @return array|WP_Error 角色資料陣列，失敗返回 WP_Error。
     */
    public function get_bangumi_characters( int $bangumi_id ): array|WP_Error {
        $url      = sprintf( '%s/v0/subjects/%d/characters', self::BANGUMI_ENDPOINT, $bangumi_id );
        $response = $this->bangumi_request( $url );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( ! is_array( $response ) ) {
            return [];
        }

        // 角色關係優先順序
        $role_priority = [ '主角' => 0, '配角' => 1, '闲角' => 2, '旁白' => 3 ];

        $characters = [];
        foreach ( $response as $item ) {
            if ( empty( $item['id'] ) ) {
                continue;
            }

            // 取第一個聲優
            $va_name  = '';
            $va_image = '';
            if ( ! empty( $item['actors'] ) && is_array( $item['actors'] ) ) {
                $first_actor = reset( $item['actors'] );
                $va_name     = $first_actor['name'] ?? '';
                $va_image    = $this->bangumi_image( $first_actor['images'] ?? [] );
            }

            // 角色名稱：優先 name_cn，空則用 name（日文）
            $name_cn = trim( $item['name_cn'] ?? '' );
            $name_ja = trim( $item['name'] ?? '' );

            // 若 name_cn 為簡體中文，自動轉換
            if ( ! empty( $name_cn ) && Anime_Sync_CN_Converter::is_simplified( $name_cn ) ) {
                $name_cn = Anime_Sync_CN_Converter::convert( $name_cn );
            }

            $relation = $item['relation'] ?? '配角';

            $characters[] = [
                'char_name_zh' => ! empty( $name_cn ) ? $name_cn : $name_ja,
                'char_name_ja' => $name_ja,
                'char_image'   => $this->bangumi_image( $item['images'] ?? [] ),
                'role'         => $relation,
                'role_order'   => $role_priority[ $relation ] ?? 99,
                'va_name'      => $va_name,
                'va_image'     => $va_image,
            ];
        }

        // 依角色重要性排序
        usort( $characters, fn( $a, $b ) => $a['role_order'] <=> $b['role_order'] );

        // 移除排序用的臨時欄位
        foreach ( $characters as &$char ) {
            unset( $char['role_order'] );
        }
        unset( $char );

        // 只取前 20 名（避免資料過大）
        return array_slice( $characters, 0, 20 );
    }

    /**
     * 取得 Bangumi 作品 STAFF 列表。
     *
     * 只返回 BANGUMI_ALLOWED_ROLES 中定義的職位。
     * 同一人多個職位時合併為一筆，職位以「、」分隔。
     * 原作排第一，其餘依 BANGUMI_ALLOWED_ROLES 順序排列。
     *
     * 回傳格式（每筆）：
     *   role     : 職位（繁體中文）
     *   name_zh  : 人員中文名（若有）
     *   name_ja  : 人員日文名
     *   image    : 人員圖片 URL
     *
     * @param int $bangumi_id Bangumi 作品 ID。
     * @return array|WP_Error STAFF 資料陣列，失敗返回 WP_Error。
     */
    public function get_bangumi_staff( int $bangumi_id ): array|WP_Error {
        $url      = sprintf( '%s/v0/subjects/%d/persons', self::BANGUMI_ENDPOINT, $bangumi_id );
        $response = $this->bangumi_request( $url );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( ! is_array( $response ) ) {
            return [];
        }

        $allowed_roles = self::BANGUMI_ALLOWED_ROLES;
        $role_index    = array_flip( $allowed_roles );

        // 以人員 ID 為鍵，合併同一人的多個職位
        $staff_map = [];

        foreach ( $response as $item ) {
            if ( empty( $item['id'] ) ) {
                continue;
            }

            $relations = $item['relation'] ?? [];
            if ( is_string( $relations ) ) {
                $relations = [ $relations ];
            }

            foreach ( $relations as $relation ) {
                // 只處理允許的職位
                if ( ! in_array( $relation, $allowed_roles, true ) ) {
                    continue;
                }

                $person_id = (int) $item['id'];
                $name_ja   = trim( $item['name'] ?? '' );
                $name_cn   = trim( $item['name_cn'] ?? '' );

                // 簡繁轉換
                if ( ! empty( $name_cn ) && Anime_Sync_CN_Converter::is_simplified( $name_cn ) ) {
                    $name_cn = Anime_Sync_CN_Converter::convert( $name_cn );
                }

                if ( isset( $staff_map[ $person_id ] ) ) {
                    // 合併職位
                    $staff_map[ $person_id ]['roles'][] = $relation;
                } else {
                    $staff_map[ $person_id ] = [
                        'person_id' => $person_id,
                        'roles'     => [ $relation ],
                        'name_ja'   => $name_ja,
                        'name_zh'   => $name_cn,
                        'image'     => $this->bangumi_image( $item['images'] ?? [] ),
                    ];
                }
            }
        }

        // 整理輸出格式並排序
        $staff_list = [];
        foreach ( $staff_map as $person ) {
            // 依允許順序取最小 index 作為排序依據
            $min_order = PHP_INT_MAX;
            foreach ( $person['roles'] as $role ) {
                $idx = $role_index[ $role ] ?? PHP_INT_MAX;
                if ( $idx < $min_order ) {
                    $min_order = $idx;
                }
            }

            $staff_list[] = [
                'role'      => implode( '、', $person['roles'] ),
                'name_zh'   => $person['name_zh'],
                'name_ja'   => $person['name_ja'],
                'image'     => $person['image'],
                '_order'    => $min_order,
            ];
        }

        // 依職位優先順序排序
        usort( $staff_list, fn( $a, $b ) => $a['_order'] <=> $b['_order'] );

        // 移除排序用欄位
        foreach ( $staff_list as &$staff ) {
            unset( $staff['_order'] );
        }
        unset( $staff );

        return $staff_list;
    }

    /**
     * 發送 Bangumi API GET 請求（BUG 2 修正：強制帶 User-Agent）。
     * 自動處理 429 限速（等待後重試一次）。
     *
     * @param string $url     完整 API URL。
     * @param int    $retry   目前重試次數。
     * @return array|WP_Error 成功返回解碼後的陣列，失敗返回 WP_Error。
     */
    private function bangumi_request( string $url, int $retry = 0 ): array|WP_Error {
        $response = wp_remote_get( $url, [
            'timeout'    => self::REQUEST_TIMEOUT,
            'user-agent' => $this->get_user_agent(), // BUG 2 修正
            'headers'    => [
                'Accept' => 'application/json',
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $http_code = wp_remote_retrieve_response_code( $response );

        if ( 429 === $http_code ) {
            if ( $retry >= 2 ) {
                return new WP_Error( 'bangumi_rate_limit', 'Bangumi API 速率限制，已達最大重試次數。' );
            }
            $retry_after = (int) wp_remote_retrieve_header( $response, 'retry-after' );
            $sleep_sec   = max( $retry_after, 3 );
            sleep( $sleep_sec );
            return $this->bangumi_request( $url, $retry + 1 );
        }

        if ( 404 === $http_code ) {
            return new WP_Error( 'bangumi_not_found', sprintf( 'Bangumi 資源不存在：%s', $url ) );
        }

        if ( $http_code < 200 || $http_code >= 300 ) {
            return new WP_Error( 'bangumi_http_error', sprintf( 'Bangumi API HTTP 錯誤：%d，URL：%s', $http_code, $url ) );
        }

        $body    = wp_remote_retrieve_body( $response );
        $decoded = json_decode( $body, true );

        if ( ! is_array( $decoded ) ) {
            return new WP_Error( 'bangumi_json_error', 'Bangumi API 回應 JSON 解析失敗。' );
        }

        return $decoded;
    }

    /**
     * 從 Bangumi images 陣列中選出最佳品質的圖片 URL。
     * 優先順序：medium → large → grid → small。
     *
     * @param array $images Bangumi images 欄位陣列。
     * @return string       圖片 URL，若無則返回空字串。
     */
    private function bangumi_image( array $images ): string {
        foreach ( [ 'medium', 'large', 'grid', 'small' ] as $size ) {
            if ( ! empty( $images[ $size ] ) ) {
                return (string) $images[ $size ];
            }
        }
        return '';
    }

    // =========================================================================
    // Jikan（MAL）API
    // =========================================================================

    /**
     * 透過 Jikan API 取得 MAL 評分與相關資料。
     * Jikan 回應有 24 小時快取，使用 ETag 進行條件式請求。
     *
     * @param int $mal_id MyAnimeList ID。
     * @return array|WP_Error 成功返回資料陣列，失敗返回 WP_Error。
     */
    public function get_jikan_data( int $mal_id ): array|WP_Error {
        $url       = sprintf( '%s/anime/%d', self::JIKAN_ENDPOINT, $mal_id );
        $cache_key = 'anime_jikan_etag_' . $mal_id;
        $etag      = get_transient( $cache_key );

        $request_args = [
            'timeout'    => self::REQUEST_TIMEOUT,
            'user-agent' => $this->get_user_agent(),
            'headers'    => [ 'Accept' => 'application/json' ],
        ];

        if ( ! empty( $etag ) ) {
            $request_args['headers']['If-None-Match'] = $etag;
        }

        $response  = wp_remote_get( $url, $request_args );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $http_code = wp_remote_retrieve_response_code( $response );

        // 304 Not Modified：使用快取資料
        if ( 304 === $http_code ) {
            $cached = get_transient( 'anime_jikan_data_' . $mal_id );
            return is_array( $cached ) ? $cached : new WP_Error( 'jikan_cache_miss', 'Jikan 快取遺失。' );
        }

        if ( 429 === $http_code ) {
            return new WP_Error( 'jikan_rate_limit', 'Jikan API 速率限制（429）。' );
        }

        if ( $http_code < 200 || $http_code >= 300 ) {
            return new WP_Error( 'jikan_http_error', sprintf( 'Jikan API HTTP 錯誤：%d', $http_code ) );
        }

        $body    = wp_remote_retrieve_body( $response );
        $decoded = json_decode( $body, true );

        if ( empty( $decoded['data'] ) ) {
            return new WP_Error( 'jikan_empty', 'Jikan API 回應資料為空。' );
        }

        $data = $decoded['data'];

        // 儲存 ETag 與資料快取（24 小時）
        $new_etag = wp_remote_retrieve_header( $response, 'etag' );
        if ( ! empty( $new_etag ) ) {
            set_transient( $cache_key, $new_etag, DAY_IN_SECONDS );
            set_transient( 'anime_jikan_data_' . $mal_id, $data, DAY_IN_SECONDS );
        }

        return $data;
    }

    // =========================================================================
    // AnimeThemes API
    // =========================================================================

    /**
     * 透過 AnimeThemes API 取得 OP/ED 主題曲資料。
     * 以 MAL ID 作為查詢條件（BUG 修正：使用 MAL ID 而非 AniList ID）。
     *
     * AnimeThemes 資源查詢端點：
     *   GET /anime?filter[site]=MyAnimeList&filter[external_id]={mal_id}
     *       &include=animethemes.song.artists,animethemes.animethemeentries.videos
     *
     * 回傳格式（每筆）：
     *   type       : 'OP' 或 'ED'
     *   sequence   : 序號（1, 2, 3...）
     *   label      : 顯示標籤（'OP1', 'OP2', 'ED1'...）
     *   song_title : 歌曲名稱
     *   artists    : 演唱者陣列（字串）
     *   video_url  : 最高畫質 WebM 影片連結
     *   notes      : 附加說明（NC版、特定集數範圍等）
     *
     * @param int $mal_id MyAnimeList ID。
     * @return array|WP_Error OP/ED 資料陣列（依 OP→ED、序號排序），失敗返回 WP_Error。
     */
    public function get_animethemes_data( int $mal_id ): array|WP_Error {
        $url = sprintf(
            '%s/anime?filter[site]=MyAnimeList&filter[external_id]=%d&include=%s',
            self::ANIMETHEMES_ENDPOINT,
            $mal_id,
            rawurlencode( 'animethemes.song.artists,animethemes.animethemeentries.videos' )
        );

        $response = wp_remote_get( $url, [
            'timeout'    => self::REQUEST_TIMEOUT,
            'user-agent' => $this->get_user_agent(),
            'headers'    => [ 'Accept' => 'application/json' ],
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $http_code = wp_remote_retrieve_response_code( $response );

        if ( 429 === $http_code ) {
            $retry_after = (int) wp_remote_retrieve_header( $response, 'retry-after' );
            sleep( max( $retry_after, 5 ) );
            return new WP_Error( 'animethemes_rate_limit', 'AnimeThemes API 速率限制（429）。' );
        }

        if ( $http_code < 200 || $http_code >= 300 ) {
            return new WP_Error( 'animethemes_http_error', sprintf( 'AnimeThemes API HTTP 錯誤：%d', $http_code ) );
        }

        $body    = wp_remote_retrieve_body( $response );
        $decoded = json_decode( $body, true );

        if ( empty( $decoded['anime'] ) || ! is_array( $decoded['anime'] ) ) {
            return []; // 無資料視為空陣列，不視為錯誤
        }

        $themes = [];

        foreach ( $decoded['anime'] as $anime_item ) {
            if ( empty( $anime_item['animethemes'] ) ) {
                continue;
            }

            foreach ( $anime_item['animethemes'] as $theme ) {
                $type     = strtoupper( $theme['type'] ?? 'OP' );     // OP 或 ED
                $sequence = (int) ( $theme['sequence'] ?? 1 );
                $label    = ( $sequence > 1 )
                    ? $type . $sequence
                    : $type . '1'; // 預設顯示 OP1 而非 OP

                // 歌曲資訊
                $song_title = $theme['song']['title'] ?? '';
                $artists    = [];
                if ( ! empty( $theme['song']['artists'] ) ) {
                    foreach ( $theme['song']['artists'] as $artist ) {
                        if ( ! empty( $artist['name'] ) ) {
                            $artists[] = $artist['name'];
                        }
                    }
                }

                // 選最高畫質影片
                $video_url = '';
                $max_res   = 0;
                if ( ! empty( $theme['animethemeentries'] ) ) {
                    foreach ( $theme['animethemeentries'] as $entry ) {
                        if ( empty( $entry['videos'] ) ) {
                            continue;
                        }
                        foreach ( $entry['videos'] as $video ) {
                            $res = (int) ( $video['resolution'] ?? 0 );
                            if ( $res >= $max_res && ! empty( $video['link'] ) ) {
                                $max_res   = $res;
                                $video_url = $video['link'];
                            }
                        }
                    }
                }

                // 附加說明（NC版標記等）
                $notes = $theme['notes'] ?? '';

                $themes[] = [
                    'type'       => $type,
                    'sequence'   => $sequence,
                    'label'      => $label,
                    'song_title' => $song_title,
                    'artists'    => $artists,
                    'video_url'  => $video_url,
                    'notes'      => $notes,
                ];
            }
        }

        // 排序：OP 優先，ED 其次；同類型依序號排序
        usort( $themes, function ( $a, $b ) {
            $type_order = [ 'OP' => 0, 'ED' => 1 ];
            $ta         = $type_order[ $a['type'] ] ?? 2;
            $tb         = $type_order[ $b['type'] ] ?? 2;
            if ( $ta !== $tb ) {
                return $ta <=> $tb;
            }
            return $a['sequence'] <=> $b['sequence'];
        } );

        return $themes;
    }

    // =========================================================================
    // 資料合併
    // =========================================================================

    /**
     * 將四個 API 的資料合併為統一格式的輸出陣列。
     *
     * @param array      $anilist      AniList Media 物件資料。
     * @param array|null $bgm_subject  Bangumi Subject 資料（null 表示無資料）。
     * @param array      $bgm_chars    Bangumi Characters 資料。
     * @param array      $bgm_staff    Bangumi Staff 資料。
     * @param array|null $jikan        Jikan 資料（null 表示無資料）。
     * @param array      $themes       AnimeThemes OP/ED 資料。
     * @param int|null   $bangumi_id   Bangumi ID（null 表示未找到）。
     * @param array      $errors       各 API 錯誤訊息陣列。
     * @return array                   統一格式資料陣列。
     */
    private function merge_api_data(
        array $anilist,
        ?array $bgm_subject,
        array $bgm_chars,
        array $bgm_staff,
        ?array $jikan,
        array $themes,
        ?int $bangumi_id,
        array $errors
    ): array {

        // ── 標題處理 ─────────────────────────────────────────────────────────
        $title_chinese = '';

        // Bangumi name_cn（繁體中文優先）
        if ( ! empty( $bgm_subject['name_cn'] ) ) {
            $title_chinese = Anime_Sync_CN_Converter::smart_convert( $bgm_subject['name_cn'] );
        }
        // Fallback 1：AniList english
        if ( empty( $title_chinese ) && ! empty( $anilist['title']['english'] ) ) {
            $title_chinese = $anilist['title']['english'];
        }
        // Fallback 2：AniList romaji
        if ( empty( $title_chinese ) && ! empty( $anilist['title']['romaji'] ) ) {
            $title_chinese = $anilist['title']['romaji'];
        }

        // ── 簡介處理 ─────────────────────────────────────────────────────────
        $synopsis_chinese = '';
        if ( ! empty( $bgm_subject['summary'] ) ) {
            $synopsis_chinese = Anime_Sync_CN_Converter::smart_convert( $bgm_subject['summary'] );
        }

        // AniList description 去除 HTML 標籤
        $synopsis_english = '';
        if ( ! empty( $anilist['description'] ) ) {
            $synopsis_english = wp_strip_all_tags( $anilist['description'] );
        }

        // ── 評分處理 ─────────────────────────────────────────────────────────
        $score_anilist  = ! empty( $anilist['averageScore'] ) ? (float) $anilist['averageScore'] : 0;
        $score_mal      = ! empty( $jikan['score'] ) ? (float) $jikan['score'] : 0;
        $score_bangumi  = ! empty( $bgm_subject['rating']['score'] ) ? (float) $bgm_subject['rating']['score'] : 0;

        // ── 播出日期 ─────────────────────────────────────────────────────────
        $start_date = $this->format_anilist_date( $anilist['startDate'] ?? [] );
        $end_date   = $this->format_anilist_date( $anilist['endDate'] ?? [] );

        // ── 下一集播出時間 ────────────────────────────────────────────────────
        $next_airing = '';
        if ( ! empty( $anilist['nextAiringEpisode']['airingAt'] ) ) {
            // 轉換 Unix timestamp 為台灣時間字串
            $ts          = (int) $anilist['nextAiringEpisode']['airingAt'];
            $next_airing = wp_date( 'Y-m-d H:i', $ts, new DateTimeZone( 'Asia/Taipei' ) );
        }

        // ── 集數（只取 AniList，BUG 8 修正）─────────────────────────────────
        $episodes       = ! empty( $anilist['episodes'] ) ? (int) $anilist['episodes'] : 0;
        $episodes_aired = ! empty( $anilist['nextAiringEpisode']['episode'] )
            ? (int) $anilist['nextAiringEpisode']['episode'] - 1
            : $episodes;

        // ── 製作公司 ──────────────────────────────────────────────────────────
        $studios = [];
        if ( ! empty( $anilist['studios']['nodes'] ) ) {
            foreach ( $anilist['studios']['nodes'] as $studio ) {
                if ( ! empty( $studio['name'] ) ) {
                    $studios[] = $studio['name'];
                }
            }
        }

        // ── 排名 ──────────────────────────────────────────────────────────────
        $ranking = 0;
        if ( ! empty( $anilist['rankings'] ) ) {
            foreach ( $anilist['rankings'] as $rank ) {
                if ( ! empty( $rank['allTime'] ) && 'RATED' === ( $rank['type'] ?? '' ) ) {
                    $ranking = (int) $rank['rank'];
                    break;
                }
            }
        }

        // ── 外部連結 ──────────────────────────────────────────────────────────
        $official_site = '';
        $twitter_url   = '';
        $streaming     = [];

        if ( ! empty( $anilist['externalLinks'] ) ) {
            foreach ( $anilist['externalLinks'] as $link ) {
                $site = $link['site'] ?? '';
                $type = $link['type'] ?? '';
                $url  = $link['url'] ?? '';

                if ( empty( $url ) ) {
                    continue;
                }

                if ( 'Official Site' === $site || ( 'INFO' === $type && empty( $official_site ) ) ) {
                    $official_site = $url;
                } elseif ( 'Twitter' === $site || 'X' === $site ) {
                    $twitter_url = $url;
                } elseif ( 'STREAMING' === $type ) {
                    $streaming[] = [
                        'platform' => $site,
                        'url'      => $url,
                        'region'   => 'TW', // 預設台灣，可人工修改
                    ];
                }
            }
        }

        // ── YouTube Trailer ───────────────────────────────────────────────────
        $trailer_url = '';
        if ( ! empty( $anilist['trailer'] ) && 'youtube' === ( $anilist['trailer']['site'] ?? '' ) ) {
            $trailer_url = 'https://www.youtube.com/watch?v=' . $anilist['trailer']['id'];
        }

        // ── 封面圖片 ──────────────────────────────────────────────────────────
        $cover_image = $anilist['coverImage']['extraLarge']
            ?? $anilist['coverImage']['large']
            ?? '';

        // ── 組裝最終結果 ──────────────────────────────────────────────────────
        return [
            // 識別 ID
            'anime_anilist_id'       => (int) $anilist['id'],
            'anime_mal_id'           => ! empty( $anilist['idMal'] ) ? (int) $anilist['idMal'] : null,
            'anime_bangumi_id'       => $bangumi_id,

            // 標題
            'anime_title_chinese'    => $title_chinese,
            'anime_title_native'     => $anilist['title']['native'] ?? '',
            'anime_title_romaji'     => $anilist['title']['romaji'] ?? '',
            'anime_title_english'    => $anilist['title']['english'] ?? '',

            // 格式 / 狀態 / 來源
            'anime_format'           => $anilist['format'] ?? 'TV',
            'anime_status'           => $anilist['status'] ?? 'FINISHED',
            'anime_source'           => $anilist['source'] ?? 'ORIGINAL',

            // 季度
            'anime_season'           => $anilist['season'] ?? '',
            'anime_season_year'      => (int) ( $anilist['seasonYear'] ?? 0 ),

            // 集數 / 時長（BUG 8：只取 AniList）
            'anime_episodes'         => $episodes,
            'anime_episodes_aired'   => $episodes_aired,
            'anime_duration'         => (int) ( $anilist['duration'] ?? 0 ),

            // 日期
            'anime_start_date'       => $start_date,
            'anime_end_date'         => $end_date,
            'anime_next_airing'      => $next_airing,

            // 評分
            'anime_score_anilist'    => $score_anilist,
            'anime_score_mal'        => $score_mal,
            'anime_score_bangumi'    => $score_bangumi,
            'anime_popularity'       => (int) ( $anilist['popularity'] ?? 0 ),
            'anime_ranking'          => $ranking,

            // 簡介
            'anime_synopsis_chinese' => $synopsis_chinese,
            'anime_synopsis_english' => $synopsis_english,

            // 媒體
            'anime_cover_image'      => $cover_image,
            'anime_banner_image'     => $anilist['bannerImage'] ?? '',
            'anime_trailer_url'      => $trailer_url,

            // 製作
            'anime_studio'           => implode( '、', $studios ),
            'anime_staff_json'       => wp_json_encode( $bgm_staff, JSON_UNESCAPED_UNICODE ),
            'anime_cast_json'        => wp_json_encode( $bgm_chars, JSON_UNESCAPED_UNICODE ),

            // OP/ED
            'anime_themes_json'      => wp_json_encode( $themes, JSON_UNESCAPED_UNICODE ),

            // 串流平台
            'anime_streaming_json'   => wp_json_encode( $streaming, JSON_UNESCAPED_UNICODE ),

            // 外部連結
            'anime_official_site'    => $official_site,
            'anime_twitter_url'      => $twitter_url,
            'anime_wikipedia_url'    => '',  // 需人工填入
            'anime_tiktok_url'       => '',  // 需人工填入

            // 台灣資訊（需人工填入）
            'anime_tw_distributor'   => '',
            'anime_tw_broadcast'     => '',

            // 系統欄位
            'anime_last_sync'        => current_time( 'mysql' ),
            'anime_last_updated'     => current_time( 'mysql' ),

            // 流派（用於 Taxonomy）
            '_genres'                => $anilist['genres'] ?? [],

            // 錯誤記錄
            'errors'                 => $errors,
        ];
    }

    // =========================================================================
    // 輔助方法
    // =========================================================================

    /**
     * 將 AniList 日期物件（{ year, month, day }）格式化為 YYYY-MM-DD 字串。
     *
     * @param array $date AniList 日期物件。
     * @return string     格式化後的日期字串，若不完整則返回空字串。
     */
    private function format_anilist_date( array $date ): string {
        if ( empty( $date['year'] ) ) {
            return '';
        }
        $year  = (int) $date['year'];
        $month = ! empty( $date['month'] ) ? (int) $date['month'] : 1;
        $day   = ! empty( $date['day'] ) ? (int) $date['day'] : 1;
        return sprintf( '%04d-%02d-%02d', $year, $month, $day );
    }

    /**
     * 產生標準 User-Agent 字串。
     * 所有 API 請求均使用此 User-Agent（BUG 2 修正）。
     *
     * @return string User-Agent 字串。
     */
    private function get_user_agent(): string {
        $site_name = get_bloginfo( 'name' );
        $site_url  = get_site_url();
        return sprintf(
            'AnimeSyncPro/1.0 (%s; %s; contact@weixiaoacg.com)',
            $site_name,
            $site_url
        );
    }

    /**
     * 回傳空結果結構（當 AniList 請求完全失敗時使用）。
     *
     * @param array $errors 錯誤訊息陣列。
     * @return array        空資料結構。
     */
    private function empty_result( array $errors ): array {
        return [
            'anime_anilist_id'       => 0,
            'anime_mal_id'           => null,
            'anime_bangumi_id'       => null,
            'anime_title_chinese'    => '',
            'anime_title_native'     => '',
            'anime_title_romaji'     => '',
            'anime_title_english'    => '',
            'anime_format'           => 'TV',
            'anime_status'           => 'FINISHED',
            'anime_source'           => 'ORIGINAL',
            'anime_season'           => '',
            'anime_season_year'      => 0,
            'anime_episodes'         => 0,
            'anime_episodes_aired'   => 0,
            'anime_duration'         => 0,
            'anime_start_date'       => '',
            'anime_end_date'         => '',
            'anime_next_airing'      => '',
            'anime_score_anilist'    => 0,
            'anime_score_mal'        => 0,
            'anime_score_bangumi'    => 0,
            'anime_popularity'       => 0,
            'anime_ranking'          => 0,
            'anime_synopsis_chinese' => '',
            'anime_synopsis_english' => '',
            'anime_cover_image'      => '',
            'anime_banner_image'     => '',
            'anime_trailer_url'      => '',
            'anime_studio'           => '',
            'anime_staff_json'       => '[]',
            'anime_cast_json'        => '[]',
            'anime_themes_json'      => '[]',
            'anime_streaming_json'   => '[]',
            'anime_official_site'    => '',
            'anime_twitter_url'      => '',
            'anime_wikipedia_url'    => '',
            'anime_tiktok_url'       => '',
            'anime_tw_distributor'   => '',
            'anime_tw_broadcast'     => '',
            'anime_last_sync'        => current_time( 'mysql' ),
            'anime_last_updated'     => current_time( 'mysql' ),
            '_genres'                => [],
            'errors'                 => $errors,
        ];
    }
}
