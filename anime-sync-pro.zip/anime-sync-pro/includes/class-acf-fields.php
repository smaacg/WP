<?php
/**
 * 檔案名稱: includes/class-acf-fields.php
 *
 * 用途:
 *   使用 Advanced Custom Fields (ACF) 的 PHP API 註冊所有動畫文章（anime CPT）
 *   所需的自訂欄位群組。
 *
 * 設計原則:
 *   - 所有 meta_key 統一使用 anime_ 前綴（方案 B 清理後的新命名規則）。
 *   - CAST、STAFF、OP/ED、串流平台等大型資料統一存為單一 JSON 字串欄位，
 *     避免 wp_postmeta 行數膨脹（對話確認的 BUG 13 修正）。
 *   - 人工鎖定欄位使用 anime_locked_fields（checkbox 陣列），
 *     自動更新邏輯讀取此欄位決定是否跳過覆寫。
 *   - ACF 欄位群組分為 7 個，依功能分類，後台顯示清晰。
 *   - 所有欄位在 ACF 未啟用時靜默跳過，不產生 Fatal Error。
 *
 * 欄位命名對照表（完整 meta_key 清單）:
 *   基本資訊: anime_anilist_id, anime_mal_id, anime_bangumi_id,
 *             anime_title_chinese, anime_title_native, anime_title_romaji,
 *             anime_title_english, anime_format, anime_status,
 *             anime_season, anime_season_year, anime_source,
 *             anime_episodes, anime_episodes_aired, anime_duration,
 *             anime_start_date, anime_end_date, anime_next_airing
 *   評分:     anime_score_anilist, anime_score_mal, anime_score_bangumi,
 *             anime_popularity, anime_ranking
 *   簡介:     anime_synopsis_chinese, anime_synopsis_english
 *   媒體:     anime_cover_image, anime_banner_image, anime_trailer_url
 *   製作:     anime_studio, anime_staff_json, anime_cast_json
 *   OP/ED:    anime_themes_json
 *   串流:     anime_streaming_json
 *   外部連結: anime_official_site, anime_twitter_url,
 *             anime_wikipedia_url, anime_tiktok_url
 *   台灣資訊: anime_tw_distributor, anime_tw_broadcast
 *   同步控制: anime_last_sync, anime_last_updated, anime_locked_fields
 *
 * 依賴:
 *   - Advanced Custom Fields Pro 或 ACF Free（5.0+）
 *   - WordPress 5.8+、PHP 7.4+
 *
 * @package    AnimeSyncPro
 * @subpackage ACF
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Anime_Sync_ACF_Fields
 */
class Anime_Sync_ACF_Fields {

    /**
     * 建構函式：掛載 ACF 欄位群組註冊動作。
     */
    public function __construct() {
        add_action( 'acf/init', [ $this, 'register_all_field_groups' ] );
    }

    /**
     * 統一入口：依序註冊所有欄位群組。
     *
     * @return void
     */
    public function register_all_field_groups(): void {
        if ( ! function_exists( 'acf_add_local_field_group' ) ) {
            return;
        }

        $this->register_basic_info();
        $this->register_ratings();
        $this->register_synopsis();
        $this->register_media();
        $this->register_production();
        $this->register_themes_and_streaming();
        $this->register_external_links();
        $this->register_taiwan_info();
        $this->register_sync_control();
    }

    // =========================================================================
    // 群組 1：基本資訊
    // =========================================================================

    /**
     * 註冊「基本資訊」欄位群組。
     * 包含所有 ID、標題、格式、狀態、季度、集數等核心欄位。
     *
     * @return void
     */
    private function register_basic_info(): void {
        acf_add_local_field_group( [
            'key'                   => 'group_anime_basic_info',
            'title'                 => '📋 基本資訊',
            'fields'                => [

                // --- API ID 區塊 ---
                [
                    'key'           => 'field_anime_anilist_id',
                    'label'         => 'AniList ID',
                    'name'          => 'anime_anilist_id',
                    'type'          => 'number',
                    'instructions'  => '請填入 AniList 作品 ID（數字），例如：21）。',
                    'required'      => 1,
                    'min'           => 1,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '33' ],
                ],
                [
                    'key'           => 'field_anime_mal_id',
                    'label'         => 'MyAnimeList ID',
                    'name'          => 'anime_mal_id',
                    'type'          => 'number',
                    'instructions'  => '由 AniList API 自動填入（idMal 欄位）。若為空表示 MAL 無對應條目。',
                    'required'      => 0,
                    'min'           => 1,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '33' ],
                ],
                [
                    'key'           => 'field_anime_bangumi_id',
                    'label'         => 'Bangumi ID',
                    'name'          => 'anime_bangumi_id',
                    'type'          => 'number',
                    'instructions'  => '由三層查找自動填入。若自動查找失敗，請手動填入 Bangumi 條目 ID。',
                    'required'      => 0,
                    'min'           => 1,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '34' ],
                ],

                // --- 標題區塊 ---
                [
                    'key'           => 'field_anime_title_chinese',
                    'label'         => '中文標題（台灣繁體）',
                    'name'          => 'anime_title_chinese',
                    'type'          => 'text',
                    'instructions'  => '優先使用 Bangumi name_cn，若為空則 fallback 至 AniList english → AniList romaji。可人工修改，修改後請在「同步控制」中勾選「鎖定中文標題」。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_title_native',
                    'label'         => '日文原名',
                    'name'          => 'anime_title_native',
                    'type'          => 'text',
                    'instructions'  => '由 AniList title.native 自動填入（日文原始標題）。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_title_romaji',
                    'label'         => 'Romaji 標題',
                    'name'          => 'anime_title_romaji',
                    'type'          => 'text',
                    'instructions'  => '由 AniList title.romaji 自動填入。同時作為文章 slug 的產生來源。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_title_english',
                    'label'         => '英文標題',
                    'name'          => 'anime_title_english',
                    'type'          => 'text',
                    'instructions'  => '由 AniList title.english 自動填入。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],

                // --- 格式 / 狀態 / 來源 ---
                [
                    'key'           => 'field_anime_format',
                    'label'         => '作品類型',
                    'name'          => 'anime_format',
                    'type'          => 'select',
                    'instructions'  => '由 AniList format 欄位自動填入。',
                    'required'      => 0,
                    'choices'       => [
                        'TV'      => '電視動畫 (TV)',
                        'TV_SHORT' => '短篇電視動畫 (TV_SHORT)',
                        'MOVIE'   => '劇場版 (MOVIE)',
                        'SPECIAL' => '特別篇 (SPECIAL)',
                        'OVA'     => 'OVA',
                        'ONA'     => '網路動畫 (ONA)',
                        'MUSIC'   => '音樂 (MUSIC)',
                    ],
                    'default_value' => 'TV',
                    'wrapper'       => [ 'width' => '33' ],
                ],
                [
                    'key'           => 'field_anime_status',
                    'label'         => '播出狀態',
                    'name'          => 'anime_status',
                    'type'          => 'select',
                    'instructions'  => '由每日 cron 自動更新。',
                    'required'      => 0,
                    'choices'       => [
                        'FINISHED'          => '已完結',
                        'RELEASING'         => '連載中',
                        'NOT_YET_RELEASED'  => '尚未播出',
                        'CANCELLED'         => '已取消',
                        'HIATUS'            => '休播中',
                    ],
                    'default_value' => 'FINISHED',
                    'wrapper'       => [ 'width' => '33' ],
                ],
                [
                    'key'           => 'field_anime_source',
                    'label'         => '原作來源',
                    'name'          => 'anime_source',
                    'type'          => 'select',
                    'instructions'  => '由 AniList source 欄位自動填入。',
                    'required'      => 0,
                    'choices'       => [
                        'ORIGINAL'       => '原創',
                        'MANGA'          => '漫畫',
                        'LIGHT_NOVEL'    => '輕小說',
                        'VISUAL_NOVEL'   => '視覺小說',
                        'VIDEO_GAME'     => '遊戲',
                        'OTHER'          => '其他',
                        'NOVEL'          => '小說',
                        'DOUJINSHI'      => '同人誌',
                        'ANIME'          => '動畫',
                        'WEB_NOVEL'      => '網路小說',
                        'LIVE_ACTION'    => '真人影視',
                        'GAME'           => '遊戲',
                        'COMIC'          => '漫畫',
                        'MULTIMEDIA_PROJECT' => '多媒體企劃',
                        'PICTURE_BOOK'   => '繪本',
                    ],
                    'default_value' => 'ORIGINAL',
                    'wrapper'       => [ 'width' => '34' ],
                ],

                // --- 季度 / 年份 ---
                [
                    'key'           => 'field_anime_season',
                    'label'         => '播出季度',
                    'name'          => 'anime_season',
                    'type'          => 'select',
                    'instructions'  => '由 AniList season 欄位自動填入。',
                    'required'      => 0,
                    'choices'       => [
                        'WINTER' => '冬季（1月）',
                        'SPRING' => '春季（4月）',
                        'SUMMER' => '夏季（7月）',
                        'FALL'   => '秋季（10月）',
                    ],
                    'wrapper'       => [ 'width' => '33' ],
                ],
                [
                    'key'           => 'field_anime_season_year',
                    'label'         => '播出年份',
                    'name'          => 'anime_season_year',
                    'type'          => 'number',
                    'instructions'  => '由 AniList seasonYear 欄位自動填入。',
                    'required'      => 0,
                    'min'           => 1900,
                    'max'           => 2100,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '33' ],
                ],

                // --- 集數 / 時長 ---
                [
                    'key'           => 'field_anime_episodes',
                    'label'         => '總集數',
                    'name'          => 'anime_episodes',
                    'type'          => 'number',
                    'instructions'  => '由 AniList episodes 欄位自動填入（完結後為最終集數）。',
                    'required'      => 0,
                    'min'           => 0,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '25' ],
                ],
                [
                    'key'           => 'field_anime_episodes_aired',
                    'label'         => '已播集數',
                    'name'          => 'anime_episodes_aired',
                    'type'          => 'number',
                    'instructions'  => '播出中時由每日 cron 自動更新。',
                    'required'      => 0,
                    'min'           => 0,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '25' ],
                ],
                [
                    'key'           => 'field_anime_duration',
                    'label'         => '每集時長（分鐘）',
                    'name'          => 'anime_duration',
                    'type'          => 'number',
                    'instructions'  => '由 AniList duration 欄位自動填入。',
                    'required'      => 0,
                    'min'           => 0,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '25' ],
                ],

                // --- 播出日期 ---
                [
                    'key'           => 'field_anime_start_date',
                    'label'         => '開播日期',
                    'name'          => 'anime_start_date',
                    'type'          => 'date_picker',
                    'instructions'  => '由 AniList startDate 欄位自動填入。格式：YYYY-MM-DD。',
                    'required'      => 0,
                    'display_format' => 'Y-m-d',
                    'return_format'  => 'Y-m-d',
                    'first_day'      => 1,
                    'wrapper'        => [ 'width' => '33' ],
                ],
                [
                    'key'           => 'field_anime_end_date',
                    'label'         => '完結日期',
                    'name'          => 'anime_end_date',
                    'type'          => 'date_picker',
                    'instructions'  => '完結後由 cron 自動填入。播出中時留空。',
                    'required'      => 0,
                    'display_format' => 'Y-m-d',
                    'return_format'  => 'Y-m-d',
                    'first_day'      => 1,
                    'wrapper'        => [ 'width' => '33' ],
                ],
                [
                    'key'           => 'field_anime_next_airing',
                    'label'         => '下一集播出時間',
                    'name'          => 'anime_next_airing',
                    'type'          => 'text',
                    'instructions'  => '格式：YYYY-MM-DD HH:MM（台灣時間）。由每日 cron 自動更新；完結後清空。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '34' ],
                ],
            ],
            'location'              => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'            => 10,
            'position'              => 'normal',
            'style'                 => 'default',
            'label_placement'       => 'top',
            'instruction_placement' => 'label',
            'active'                => true,
        ] );
    }

    // =========================================================================
    // 群組 2：評分資訊
    // =========================================================================

    /**
     * 註冊「評分資訊」欄位群組。
     *
     * @return void
     */
    private function register_ratings(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_ratings',
            'title'  => '⭐ 評分資訊',
            'fields' => [
                [
                    'key'           => 'field_anime_score_anilist',
                    'label'         => 'AniList 評分',
                    'name'          => 'anime_score_anilist',
                    'type'          => 'number',
                    'instructions'  => '範圍 0–100。由每週 cron 自動更新。',
                    'required'      => 0,
                    'min'           => 0,
                    'max'           => 100,
                    'step'          => 0.01,
                    'wrapper'       => [ 'width' => '25' ],
                ],
                [
                    'key'           => 'field_anime_score_mal',
                    'label'         => 'MyAnimeList 評分',
                    'name'          => 'anime_score_mal',
                    'type'          => 'number',
                    'instructions'  => '範圍 0–10。由每週 cron 透過 Jikan API 自動更新。',
                    'required'      => 0,
                    'min'           => 0,
                    'max'           => 10,
                    'step'          => 0.01,
                    'wrapper'       => [ 'width' => '25' ],
                ],
                [
                    'key'           => 'field_anime_score_bangumi',
                    'label'         => 'Bangumi 評分',
                    'name'          => 'anime_score_bangumi',
                    'type'          => 'number',
                    'instructions'  => '範圍 0–10。由每週 cron 自動更新。',
                    'required'      => 0,
                    'min'           => 0,
                    'max'           => 10,
                    'step'          => 0.01,
                    'wrapper'       => [ 'width' => '25' ],
                ],
                [
                    'key'           => 'field_anime_popularity',
                    'label'         => 'AniList 人氣數',
                    'name'          => 'anime_popularity',
                    'type'          => 'number',
                    'instructions'  => '由 AniList popularity 欄位自動填入（收藏人數）。每週更新。',
                    'required'      => 0,
                    'min'           => 0,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '25' ],
                ],
                [
                    'key'           => 'field_anime_ranking',
                    'label'         => 'AniList 排名',
                    'name'          => 'anime_ranking',
                    'type'          => 'number',
                    'instructions'  => '由 AniList rankings 欄位自動填入（全時期評分排名）。每週更新。',
                    'required'      => 0,
                    'min'           => 0,
                    'step'          => 1,
                    'wrapper'       => [ 'width' => '25' ],
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 20,
            'position'    => 'normal',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 群組 3：簡介
    // =========================================================================

    /**
     * 註冊「簡介」欄位群組。
     *
     * @return void
     */
    private function register_synopsis(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_synopsis',
            'title'  => '📝 簡介',
            'fields' => [
                [
                    'key'           => 'field_anime_synopsis_chinese',
                    'label'         => '中文簡介（台灣繁體）',
                    'name'          => 'anime_synopsis_chinese',
                    'type'          => 'textarea',
                    'instructions'  => '優先使用 Bangumi summary（自動簡繁轉換）。若 Bangumi 無資料，留空並請人工填入。修改後請在「同步控制」勾選「鎖定中文簡介」。',
                    'required'      => 0,
                    'rows'          => 6,
                    'new_lines'     => 'br',
                    'wrapper'       => [ 'width' => '100' ],
                ],
                [
                    'key'           => 'field_anime_synopsis_english',
                    'label'         => '英文簡介',
                    'name'          => 'anime_synopsis_english',
                    'type'          => 'textarea',
                    'instructions'  => '由 AniList description 欄位自動填入（已去除 HTML 標籤）。',
                    'required'      => 0,
                    'rows'          => 6,
                    'new_lines'     => 'br',
                    'wrapper'       => [ 'width' => '100' ],
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 30,
            'position'    => 'normal',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 群組 4：媒體素材
    // =========================================================================

    /**
     * 註冊「媒體素材」欄位群組。
     * 包含封面、橫幅、預告片等媒體欄位。
     *
     * @return void
     */
    private function register_media(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_media',
            'title'  => '🖼️ 媒體素材',
            'fields' => [
                [
                    'key'           => 'field_anime_cover_image',
                    'label'         => '封面圖片網址',
                    'name'          => 'anime_cover_image',
                    'type'          => 'url',
                    'instructions'  => '由 AniList coverImage.extraLarge 自動填入。若需替換，請直接修改此網址，並在「同步控制」勾選「鎖定封面圖片」。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '100' ],
                ],
                [
                    'key'           => 'field_anime_banner_image',
                    'label'         => '橫幅圖片網址',
                    'name'          => 'anime_banner_image',
                    'type'          => 'url',
                    'instructions'  => '由 AniList bannerImage 自動填入。可留空（不影響 SEO）。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '100' ],
                ],
                [
                    'key'           => 'field_anime_trailer_url',
                    'label'         => 'YouTube 預告片網址',
                    'name'          => 'anime_trailer_url',
                    'type'          => 'url',
                    'instructions'  => '請填入 YouTube 完整網址（例：https://www.youtube.com/watch?v=XXXXX）。建議優先填入台灣官方預告或中文字幕版。此欄位需人工填入，不自動更新。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '100' ],
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 40,
            'position'    => 'normal',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 群組 5：製作資訊（STAFF / CAST）
    // =========================================================================

    /**
     * 註冊「製作資訊」欄位群組。
     * STAFF 與 CAST 均以單一 JSON 欄位儲存，避免 repeater 造成 postmeta 膨脹。
     *
     * @return void
     */
    private function register_production(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_production',
            'title'  => '🎬 製作資訊',
            'fields' => [
                [
                    'key'           => 'field_anime_studio',
                    'label'         => '製作公司',
                    'name'          => 'anime_studio',
                    'type'          => 'text',
                    'instructions'  => '由 AniList studios（isMain: true）自動填入主要製作公司名稱。多間時以逗號分隔。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '100' ],
                ],
                [
                    'key'           => 'field_anime_staff_json',
                    'label'         => 'STAFF 資料（JSON）',
                    'name'          => 'anime_staff_json',
                    'type'          => 'textarea',
                    'instructions'  => '由 Bangumi STAFF API 自動填入，格式為 JSON 陣列。請勿手動編輯此欄位。範例：[{"role":"導演","name_zh":"山田太郎","name_ja":"山田太郎","image":"https://..."}]',
                    'required'      => 0,
                    'rows'          => 4,
                    'new_lines'     => '',
                    'wrapper'       => [ 'width' => '100' ],
                    'readonly'      => 1,
                ],
                [
                    'key'           => 'field_anime_cast_json',
                    'label'         => 'CAST 角色資料（JSON）',
                    'name'          => 'anime_cast_json',
                    'type'          => 'textarea',
                    'instructions'  => '由 Bangumi CAST API 自動填入，格式為 JSON 陣列。請勿手動編輯此欄位。範例：[{"char_name_zh":"夜神月","char_name_ja":"夜神月","char_image":"https://...","role":"主角","va_name":"宮野真守","va_image":"https://..."}]',
                    'required'      => 0,
                    'rows'          => 4,
                    'new_lines'     => '',
                    'wrapper'       => [ 'width' => '100' ],
                    'readonly'      => 1,
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 50,
            'position'    => 'normal',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 群組 6：OP/ED 主題曲與串流平台
    // =========================================================================

    /**
     * 註冊「主題曲與串流平台」欄位群組。
     *
     * @return void
     */
    private function register_themes_and_streaming(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_themes_streaming',
            'title'  => '🎵 主題曲與串流平台',
            'fields' => [
                [
                    'key'           => 'field_anime_themes_json',
                    'label'         => 'OP/ED 主題曲資料（JSON）',
                    'name'          => 'anime_themes_json',
                    'type'          => 'textarea',
                    'instructions'  => '由 AnimeThemes API 透過 MAL ID 自動抓取，完結後 21 天觸發補抓。格式為 JSON 陣列。請勿手動編輯。範例：[{"type":"OP","sequence":1,"label":"OP1","song_title":"Courage","artists":["Yui"],"video_url":"https://v.animethemes.moe/XXX.webm"}]',
                    'required'      => 0,
                    'rows'          => 4,
                    'new_lines'     => '',
                    'wrapper'       => [ 'width' => '100' ],
                    'readonly'      => 1,
                ],
                [
                    'key'           => 'field_anime_streaming_json',
                    'label'         => '串流平台資料（JSON）',
                    'name'          => 'anime_streaming_json',
                    'type'          => 'textarea',
                    'instructions'  => '由 AniList externalLinks（type: STREAMING）自動填入。格式為 JSON 陣列。請勿手動編輯。範例：[{"platform":"Netflix","url":"https://www.netflix.com/...","region":"TW"}]',
                    'required'      => 0,
                    'rows'          => 4,
                    'new_lines'     => '',
                    'wrapper'       => [ 'width' => '100' ],
                    'readonly'      => 1,
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 60,
            'position'    => 'normal',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 群組 7：外部連結
    // =========================================================================

    /**
     * 註冊「外部連結」欄位群組。
     * 所有連結欄位均需人工填入，不自動更新。
     *
     * @return void
     */
    private function register_external_links(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_external_links',
            'title'  => '🔗 外部連結',
            'fields' => [
                [
                    'key'           => 'field_anime_official_site',
                    'label'         => '官方網站',
                    'name'          => 'anime_official_site',
                    'type'          => 'url',
                    'instructions'  => '由 AniList externalLinks（type: INFO, site: Official Site）自動填入。可人工覆寫。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_twitter_url',
                    'label'         => 'Twitter / X 官方帳號',
                    'name'          => 'anime_twitter_url',
                    'type'          => 'url',
                    'instructions'  => '由 AniList externalLinks（site: Twitter）自動填入。可人工覆寫。格式：https://twitter.com/帳號名',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_wikipedia_url',
                    'label'         => 'Wikipedia 頁面',
                    'name'          => 'anime_wikipedia_url',
                    'type'          => 'url',
                    'instructions'  => '請人工填入中文或日文維基百科連結。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_tiktok_url',
                    'label'         => 'TikTok 官方帳號',
                    'name'          => 'anime_tiktok_url',
                    'type'          => 'url',
                    'instructions'  => '請人工填入 TikTok 官方帳號連結（選填）。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 70,
            'position'    => 'normal',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 群組 8：台灣在地資訊
    // =========================================================================

    /**
     * 註冊「台灣在地資訊」欄位群組。
     * 所有欄位均需人工填入。
     *
     * @return void
     */
    private function register_taiwan_info(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_taiwan_info',
            'title'  => '🇹🇼 台灣在地資訊',
            'fields' => [
                [
                    'key'           => 'field_anime_tw_distributor',
                    'label'         => '台灣代理商／發行商',
                    'name'          => 'anime_tw_distributor',
                    'type'          => 'text',
                    'instructions'  => '請人工填入台灣代理商名稱（例：木棉花、普威爾、Animax）。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_tw_broadcast',
                    'label'         => '台灣播出時間',
                    'name'          => 'anime_tw_broadcast',
                    'type'          => 'text',
                    'instructions'  => '請人工填入台灣播出時間（例：每週六 23:00 Netflix）。',
                    'required'      => 0,
                    'wrapper'       => [ 'width' => '50' ],
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 80,
            'position'    => 'normal',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 群組 9：同步控制
    // =========================================================================

    /**
     * 註冊「同步控制」欄位群組。
     * 包含最後同步時間、最後更新時間、欄位鎖定設定。
     *
     * @return void
     */
    private function register_sync_control(): void {
        acf_add_local_field_group( [
            'key'    => 'group_anime_sync_control',
            'title'  => '⚙️ 同步控制',
            'fields' => [
                [
                    'key'           => 'field_anime_last_sync',
                    'label'         => '上次 API 同步時間',
                    'name'          => 'anime_last_sync',
                    'type'          => 'text',
                    'instructions'  => '由系統自動記錄（格式：YYYY-MM-DD HH:MM:SS）。請勿手動修改。',
                    'required'      => 0,
                    'readonly'      => 1,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_last_updated',
                    'label'         => '資料最後更新時間',
                    'name'          => 'anime_last_updated',
                    'type'          => 'text',
                    'instructions'  => '每次任何欄位更新時由系統自動記錄。顯示於文章頁面「最後更新」時間戳記。',
                    'required'      => 0,
                    'readonly'      => 1,
                    'wrapper'       => [ 'width' => '50' ],
                ],
                [
                    'key'           => 'field_anime_locked_fields',
                    'label'         => '鎖定欄位（防止自動覆寫）',
                    'name'          => 'anime_locked_fields',
                    'type'          => 'checkbox',
                    'instructions'  => '勾選後，自動更新 cron 將跳過該欄位，保留您的人工修改。',
                    'required'      => 0,
                    'choices'       => [
                        'anime_title_chinese'    => '中文標題',
                        'anime_synopsis_chinese' => '中文簡介',
                        'anime_cover_image'      => '封面圖片',
                        'anime_banner_image'     => '橫幅圖片',
                        'anime_trailer_url'      => 'YouTube 預告片',
                        'anime_official_site'    => '官方網站',
                        'anime_twitter_url'      => 'Twitter 連結',
                        'anime_wikipedia_url'    => 'Wikipedia 連結',
                        'anime_tiktok_url'       => 'TikTok 連結',
                        'anime_tw_distributor'   => '台灣代理商',
                        'anime_tw_broadcast'     => '台灣播出時間',
                        'anime_cast_json'        => 'CAST 角色資料',
                        'anime_staff_json'       => 'STAFF 製作資料',
                        'anime_themes_json'      => 'OP/ED 主題曲',
                        'anime_streaming_json'   => '串流平台資料',
                    ],
                    'layout'        => 'horizontal',
                    'toggle'        => 0,
                    'return_format' => 'value',
                    'wrapper'       => [ 'width' => '100' ],
                ],
            ],
            'location'    => [
                [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'anime' ] ],
            ],
            'menu_order'  => 90,
            'position'    => 'side',
            'style'       => 'default',
            'active'      => true,
        ] );
    }

    // =========================================================================
    // 靜態輔助方法
    // =========================================================================

    /**
     * 取得所有自動更新欄位清單。
     * 供 class-import-manager.php 中的 cron 更新方法使用，
     * 用於檢查該欄位是否被 anime_locked_fields 鎖定。
     *
     * @return array 欄位 meta_key 陣列，鍵為 meta_key，值為中文說明。
     */
    public static function get_auto_update_fields(): array {
        return [
            // 每日更新（播出中才更新）
            'anime_episodes_aired' => '已播集數',
            'anime_status'         => '播出狀態',
            'anime_next_airing'    => '下一集播出時間',
            'anime_end_date'       => '完結日期',
            'anime_episodes'       => '總集數（完結確認）',

            // 每週更新（所有作品）
            'anime_score_anilist'  => 'AniList 評分',
            'anime_score_mal'      => 'MAL 評分',
            'anime_score_bangumi'  => 'Bangumi 評分',
            'anime_popularity'     => 'AniList 人氣數',
            'anime_ranking'        => 'AniList 排名',

            // 完結後 21 天觸發一次
            'anime_themes_json'    => 'OP/ED 主題曲',
        ];
    }

    /**
     * 取得所有僅首次匯入、之後不自動更新的欄位清單。
     * 供 import manager 參考，避免重複呼叫 API。
     *
     * @return array 欄位 meta_key 陣列，鍵為 meta_key，值為中文說明。
     */
    public static function get_one_time_fields(): array {
        return [
            'anime_anilist_id'      => 'AniList ID',
            'anime_mal_id'          => 'MAL ID',
            'anime_bangumi_id'      => 'Bangumi ID',
            'anime_title_native'    => '日文原名',
            'anime_title_romaji'    => 'Romaji 標題',
            'anime_title_english'   => '英文標題',
            'anime_format'          => '作品類型',
            'anime_source'          => '原作來源',
            'anime_season'          => '播出季度',
            'anime_season_year'     => '播出年份',
            'anime_duration'        => '每集時長',
            'anime_start_date'      => '開播日期',
            'anime_synopsis_english' => '英文簡介',
            'anime_cover_image'     => '封面圖片',
            'anime_banner_image'    => '橫幅圖片',
            'anime_studio'          => '製作公司',
            'anime_staff_json'      => 'STAFF 資料',
            'anime_cast_json'       => 'CAST 資料',
            'anime_streaming_json'  => '串流平台資料',
            'anime_official_site'   => '官方網站',
            'anime_twitter_url'     => 'Twitter 連結',
        ];
    }

    /**
     * 檢查指定欄位是否被鎖定（由文章的 anime_locked_fields 值判斷）。
     *
     * @param int    $post_id   WordPress 文章 ID。
     * @param string $meta_key  欄位 meta_key（例：'anime_title_chinese'）。
     * @return bool             true 表示已鎖定，自動更新應跳過此欄位。
     */
    public static function is_field_locked( int $post_id, string $meta_key ): bool {
        if ( ! function_exists( 'get_field' ) ) {
            // ACF 未啟用，回退到 get_post_meta
            $locked = get_post_meta( $post_id, 'anime_locked_fields', true );
        } else {
            $locked = get_field( 'anime_locked_fields', $post_id );
        }

        if ( empty( $locked ) || ! is_array( $locked ) ) {
            return false;
        }

        return in_array( $meta_key, $locked, true );
    }
}
