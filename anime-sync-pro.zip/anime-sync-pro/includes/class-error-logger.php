<?php
/**
 * Error Logger
 * 
 * @package Anime_Sync_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class Anime_Sync_Error_Logger {
    
    /**
     * Database object
     */
    private $wpdb;
    
    /**
     * Table name
     */
    private $table_name;
    
    /**
     * Log levels
     */
    const LEVEL_INFO = 'info';
    const LEVEL_WARNING = 'warning';
    const LEVEL_ERROR = 'error';
    const LEVEL_CRITICAL = 'critical';
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_name = $wpdb->prefix . 'anime_sync_logs';
    }
    
    /**
     * Log a message
     * 
     * @param string $level Log level
     * @param string $message Log message
     * @param array $context Additional context
     * @return bool Success
     */
    public function log($level, $message, $context = array()) {
        // 驗證 level
        $valid_levels = array(
            self::LEVEL_INFO,
            self::LEVEL_WARNING,
            self::LEVEL_ERROR,
            self::LEVEL_CRITICAL
        );
        
        if (!in_array($level, $valid_levels)) {
            $level = self::LEVEL_INFO;
        }
        
        // 插入日誌
        $result = $this->wpdb->insert(
            $this->table_name,
            array(
                'level' => $level,
                'message' => sanitize_text_field($message),
                'context' => wp_json_encode($context, JSON_UNESCAPED_UNICODE),
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s')
        );
        
        // Critical 等級發送 Email
        if ($level === self::LEVEL_CRITICAL) {
            $this->send_critical_email($message, $context);
        }
        
        return $result !== false;
    }
    
    /**
     * Get recent logs
     * 
     * @param int $limit Number of logs
     * @param string $level Optional level filter
     * @return array Logs
     */
    public function get_recent_logs($limit = 100, $level = null) {
        $where = '';
        if (!empty($level)) {
            $where = $this->wpdb->prepare('WHERE level = %s', $level);
        }
        
        $query = $this->wpdb->prepare(
            "SELECT * FROM {$this->table_name}
            {$where}
            ORDER BY created_at DESC
            LIMIT %d",
            absint($limit)
        );
        
        $logs = $this->wpdb->get_results($query, ARRAY_A);
        
        // 解析 context JSON
        foreach ($logs as &$log) {
            if (!empty($log['context'])) {
                $log['context'] = json_decode($log['context'], true);
            }
        }
        
        return $logs;
    }
    
    /**
     * Delete old logs
     * 
     * @param int $days Keep logs from last X days
     * @return int Number of deleted logs
     */
    public function delete_old_logs($days = 30) {
        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        $result = $this->wpdb->query(
            $this->wpdb->prepare(
                "DELETE FROM {$this->table_name} WHERE created_at < %s",
                $date
            )
        );
        
        return (int) $result;
    }
    
    /**
     * Send critical error email
     * 
     * @param string $message Error message
     * @param array $context Error context
     */
    private function send_critical_email($message, $context) {
        // 檢查是否啟用 Email 通知
        if (!get_option('anime_sync_log_email_notify', true)) {
            return;
        }
        
        $admin_email = get_option('admin_email');
        $site_name = get_bloginfo('name');
        
        $subject = sprintf(
            '[%s] Anime Sync Pro - Critical Error',
            $site_name
        );
        
        $body = sprintf(
            "A critical error occurred in Anime Sync Pro:\n\n" .
            "Message: %s\n\n" .
            "Context: %s\n\n" .
            "Time: %s\n\n" .
            "Please check the error logs in WordPress admin.",
            $message,
            print_r($context, true),
            current_time('mysql')
        );
        
        wp_mail($admin_email, $subject, $body);
    }
    
    /**
     * Get log statistics
     * 
     * @param int $days Last X days
     * @return array Statistics
     */
    public function get_statistics($days = 7) {
        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        $query = $this->wpdb->prepare(
            "SELECT 
                level,
                COUNT(*) as count
            FROM {$this->table_name}
            WHERE created_at >= %s
            GROUP BY level",
            $date
        );
        
        $results = $this->wpdb->get_results($query, ARRAY_A);
        
        $stats = array(
            'info' => 0,
            'warning' => 0,
            'error' => 0,
            'critical' => 0,
            'total' => 0
        );
        
        foreach ($results as $row) {
            $stats[$row['level']] = (int) $row['count'];
            $stats['total'] += (int) $row['count'];
        }
        
        return $stats;
    }
}
