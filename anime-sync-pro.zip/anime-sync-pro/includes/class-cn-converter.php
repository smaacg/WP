<?php
/**
 * 檔案名稱: includes/class-cn-converter.php
 *
 * 用途:
 *   將簡體中文字串轉換為台灣繁體中文。
 *   使用 data/cn-tw-dict.json 作為詞典來源（約 40,000 詞條）。
 *
 * 演算法:
 *   正向最大匹配（Forward Maximum Matching, FMM）。
 *   從字串左端開始，優先嘗試最長詞組匹配，匹配失敗則縮短長度，
 *   最短為單字匹配；若單字也無對應則保留原字元。
 *   最大匹配長度預設為 10 個字元（涵蓋絕大多數詞組）。
 *
 * 效能設計:
 *   - static $dict: 詞典只載入一次，後續呼叫直接使用記憶體快取。
 *   - static $max_word_len: 詞典最長詞條長度，初始化時計算一次。
 *   - 轉換完成後可在外部呼叫 clear_cache() 釋放記憶體（批次處理後建議執行）。
 *
 * 依賴:
 *   - data/cn-tw-dict.json（與本檔案同屬 anime-sync-pro 插件目錄）
 *   - 需要 PHP mbstring 擴充（mb_strlen / mb_substr）
 *
 * 授權聲明:
 *   詞典資料來源 OpenCC (https://github.com/BYVoid/OpenCC)，Apache-2.0 授權。
 *   本 PHP 轉換邏輯為 anime-sync-pro 插件原創實作。
 *
 * @package    AnimeSyncPro
 * @subpackage Converter
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Anime_Sync_CN_Converter
 *
 * 簡體→台灣繁體轉換器，使用靜態快取避免重複 I/O。
 */
class Anime_Sync_CN_Converter {

    /**
     * 詞典靜態快取。
     * 格式: [ '简体词' => '繁體詞', ... ]
     *
     * @var array|null
     */
    private static $dict = null;

    /**
     * 詞典最長詞條的字元數（mb_strlen）。
     * 初始化後固定，用於限制 FMM 最大視窗寬度。
     *
     * @var int
     */
    private static $max_word_len = 10;

    /**
     * 詞典 JSON 檔案的絕對路徑。
     *
     * @var string
     */
    private static $dict_path = '';

    /**
     * 載入詞典到靜態快取。
     * 若已載入則直接返回，不重複讀取檔案。
     *
     * @return bool 載入成功返回 true，失敗返回 false。
     */
    private static function load_dict(): bool {
        if ( null !== self::$dict ) {
            return true;
        }

        // 決定詞典路徑（允許外部透過常數覆寫，方便測試）
        if ( empty( self::$dict_path ) ) {
            self::$dict_path = defined( 'ANIME_SYNC_PLUGIN_DIR' )
                ? ANIME_SYNC_PLUGIN_DIR . 'data/cn-tw-dict.json'
                : plugin_dir_path( dirname( __FILE__ ) ) . 'data/cn-tw-dict.json';
        }

        if ( ! file_exists( self::$dict_path ) ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( '[AnimeSyncPro] cn-tw-dict.json 不存在：' . self::$dict_path );
            }
            self::$dict = [];
            return false;
        }

        $json = file_get_contents( self::$dict_path );
        if ( false === $json ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( '[AnimeSyncPro] 無法讀取 cn-tw-dict.json' );
            }
            self::$dict = [];
            return false;
        }

        $decoded = json_decode( $json, true );
        if ( ! is_array( $decoded ) ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( '[AnimeSyncPro] cn-tw-dict.json JSON 解析失敗' );
            }
            self::$dict = [];
            return false;
        }

        // 移除 _comment 鍵（不參與轉換）
        unset( $decoded['_comment'] );

        self::$dict = $decoded;

        // 計算最長詞條長度，限制 FMM 視窗上限
        $max = 1;
        foreach ( self::$dict as $key => $value ) {
            $len = mb_strlen( (string) $key, 'UTF-8' );
            if ( $len > $max ) {
                $max = $len;
            }
        }
        self::$max_word_len = min( $max, 20 ); // 安全上限 20 字元

        return true;
    }

    /**
     * 主要轉換方法。
     * 將輸入的簡體中文字串轉換為台灣繁體中文。
     *
     * @param  string $text 待轉換的簡體中文字串（可包含非中文字元）。
     * @return string       轉換後的台灣繁體中文字串。
     */
    public static function convert( string $text ): string {
        if ( empty( $text ) ) {
            return $text;
        }

        // 確保詞典已載入
        if ( ! self::load_dict() || empty( self::$dict ) ) {
            return $text;
        }

        $result     = '';
        $text_len   = mb_strlen( $text, 'UTF-8' );
        $pos        = 0;
        $max_len    = self::$max_word_len;

        while ( $pos < $text_len ) {
            $matched     = false;
            $window_size = min( $max_len, $text_len - $pos );

            // 從最長視窗開始，逐步縮短，嘗試匹配詞典
            for ( $len = $window_size; $len >= 1; $len-- ) {
                $segment = mb_substr( $text, $pos, $len, 'UTF-8' );

                if ( isset( self::$dict[ $segment ] ) ) {
                    $result  .= self::$dict[ $segment ];
                    $pos     += $len;
                    $matched  = true;
                    break;
                }
            }

            // 若無任何匹配，保留原字元並前進一格
            if ( ! $matched ) {
                $result .= mb_substr( $text, $pos, 1, 'UTF-8' );
                $pos++;
            }
        }

        return $result;
    }

    /**
     * 批次轉換陣列中的所有字串值。
     * 遞迴處理多維陣列；非字串值（整數、布林等）保持不變。
     *
     * @param  array $data 待轉換的陣列。
     * @return array       轉換後的陣列，結構與原陣列相同。
     */
    public static function convert_array( array $data ): array {
        foreach ( $data as $key => $value ) {
            if ( is_string( $value ) ) {
                $data[ $key ] = self::convert( $value );
            } elseif ( is_array( $value ) ) {
                $data[ $key ] = self::convert_array( $value );
            }
            // 其他型別（int, bool, null）直接保留
        }
        return $data;
    }

    /**
     * 轉換字串，但跳過 HTML 標籤內的屬性與標籤本身，
     * 只轉換 HTML 標籤之間的文字節點。
     *
     * 適用於 Bangumi 或 AniList 回傳含有少量 HTML 格式的簡介。
     *
     * @param  string $html 可能含有 HTML 標籤的簡體中文字串。
     * @return string       轉換後的台灣繁體中文（標籤結構保留）。
     */
    public static function convert_html( string $html ): string {
        if ( empty( $html ) ) {
            return $html;
        }

        // 使用 preg_split 以 HTML 標籤為分隔，只轉換文字節點
        $parts  = preg_split( '/(<[^>]+>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
        $output = '';

        foreach ( $parts as $part ) {
            if ( '' === $part ) {
                continue;
            }
            // 判斷是否為 HTML 標籤（以 < 開頭、> 結尾）
            if ( '<' === $part[0] && '>' === $part[ strlen( $part ) - 1 ] ) {
                $output .= $part; // 標籤原樣保留
            } else {
                $output .= self::convert( $part ); // 文字節點轉換
            }
        }

        return $output;
    }

    /**
     * 判斷字串是否主要為簡體中文。
     *
     * 使用抽樣策略：取前 200 字元，統計簡體特徵字的比例。
     * 主要用於在匯入前快速判斷 Bangumi 回傳內容是否需要轉換。
     *
     * 簡體特徵字集合（常見高頻差異字）：
     *   这 来 时 国 会 发 说 问 没 样 后 动 电 过 对 从 给 还 进 为 产 关 个 们 长 实 ...
     *
     * @param  string $text 待判斷的字串。
     * @return bool         true 表示疑似簡體中文，建議執行轉換。
     */
    public static function is_simplified( string $text ): bool {
        if ( empty( $text ) ) {
            return false;
        }

        // 簡體特徵字（在繁體中不存在或極少使用的常見簡體字）
        $simplified_chars = [
            '这', '来', '时', '国', '会', '发', '说', '问', '没', '样',
            '后', '动', '电', '过', '对', '从', '给', '还', '进', '为',
            '产', '关', '个', '们', '长', '实', '场', '东', '万', '义',
            '习', '乡', '书', '买', '乱', '争', '亲', '亿', '仅', '传',
            '伤', '体', '优', '党', '兰', '养', '兽', '册', '写', '军',
            '农', '净', '减', '风', '飞', '饮', '鱼', '鲁', '鸟', '鸡',
        ];

        // 取前 200 字元作為樣本
        $sample      = mb_substr( $text, 0, 200, 'UTF-8' );
        $sample_len  = mb_strlen( $sample, 'UTF-8' );

        if ( $sample_len < 5 ) {
            return false;
        }

        $simplified_count = 0;
        foreach ( $simplified_chars as $char ) {
            $simplified_count += mb_substr_count( $sample, $char );
        }

        // 若簡體特徵字密度 > 2%（每 100 字有 2 個以上），判定為簡體
        $density = $simplified_count / $sample_len;
        return $density > 0.02;
    }

    /**
     * 智慧轉換：先判斷是否為簡體，再決定是否執行轉換。
     * 避免對已是繁體中文的字串進行無謂處理。
     *
     * @param  string $text 待轉換的字串。
     * @return string       若判定為簡體則返回轉換結果，否則返回原字串。
     */
    public static function smart_convert( string $text ): string {
        if ( empty( $text ) ) {
            return $text;
        }

        if ( self::is_simplified( $text ) ) {
            return self::convert( $text );
        }

        return $text;
    }

    /**
     * 釋放靜態詞典快取，回收記憶體。
     *
     * 建議在批次匯入結束後呼叫（例如季度匯入完成後），
     * 避免長時間執行的 PHP 行程佔用過多記憶體。
     *
     * 下次呼叫 convert() 時會自動重新載入詞典。
     *
     * @return void
     */
    public static function clear_cache(): void {
        self::$dict = null;
        self::$max_word_len = 10;
    }

    /**
     * 取得詞典目前的載入狀態與統計資訊。
     * 主要供後台除錯頁面或單元測試使用。
     *
     * @return array {
     *     @type bool   $loaded       詞典是否已載入。
     *     @type int    $entry_count  詞條數量。
     *     @type int    $max_word_len 最長詞條字元數。
     *     @type string $dict_path    詞典檔案路徑。
     *     @type int    $file_size    詞典檔案大小（bytes），-1 表示檔案不存在。
     * }
     */
    public static function get_stats(): array {
        $path = empty( self::$dict_path )
            ? ( defined( 'ANIME_SYNC_PLUGIN_DIR' )
                ? ANIME_SYNC_PLUGIN_DIR . 'data/cn-tw-dict.json'
                : plugin_dir_path( dirname( __FILE__ ) ) . 'data/cn-tw-dict.json' )
            : self::$dict_path;

        return [
            'loaded'       => null !== self::$dict,
            'entry_count'  => null !== self::$dict ? count( self::$dict ) : 0,
            'max_word_len' => self::$max_word_len,
            'dict_path'    => $path,
            'file_size'    => file_exists( $path ) ? filesize( $path ) : -1,
        ];
    }

    /**
     * 允許外部指定詞典路徑（主要用於單元測試）。
     *
     * @param string $path 詞典 JSON 檔案的絕對路徑。
     * @return void
     */
    public static function set_dict_path( string $path ): void {
        self::$dict_path = $path;
        // 重置快取，強制下次重新載入
        self::$dict = null;
    }
}
