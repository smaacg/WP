<?php
/**
 * Custom Post Type
 * 
 * @package Anime_Sync_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class Anime_Sync_Custom_Post_Type {

    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'register_post_type'));
        add_action('init', array($this, 'register_taxonomies'));
        add_filter('post_updated_messages', array($this, 'custom_messages'));
        add_filter('manage_anime_posts_columns', array($this, 'add_admin_columns'));
        add_action('manage_anime_posts_custom_column', array($this, 'render_admin_columns'), 10, 2);
    }

    /**
     * 註冊自訂文章類型
     */
    public function register_post_type() {
        $labels = array(
            'name' => '動畫',
            'singular_name' => '動畫',
            'add_new' => '新增動畫',
            'add_new_item' => '新增動畫',
            'edit_item' => '編輯動畫',
            'new_item' => '新動畫',
            'view_item' => '查看動畫',
            'view_items' => '查看所有動畫',
            'search_items' => '搜尋動畫',
            'not_found' => '找不到動畫',
            'not_found_in_trash' => '垃圾桶中找不到動畫',
            'all_items' => '所有動畫',
            'menu_name' => '動畫',
            'name_admin_bar' => '動畫',
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'anime',
                'with_front' => false
            ),
            'capability_type' => 'post',
            'has_archive' => 'anime',
            'hierarchical' => false,
            'menu_position' => 5,
            'menu_icon' => 'dashicons-video-alt3',
            'supports' => array(
                'title',
                'editor',
                'thumbnail',
                'excerpt',
                'custom-fields',
                'revisions',
            ),
            'show_in_rest' => true,
            'rest_base' => 'anime',
        );

        register_post_type('anime', $args);
    }

    /**
     * 註冊分類法
     */
    public function register_taxonomies() {
        // 季度分類
        register_taxonomy('anime_season', 'anime', array(
            'labels' => array(
                'name' => '季度',
                'singular_name' => '季度',
                'search_items' => '搜尋季度',
                'all_items' => '所有季度',
                'edit_item' => '編輯季度',
                'add_new_item' => '新增季度',
                'menu_name' => '季度',
            ),
            'hierarchical' => false,
            'public' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'season'),
            'show_in_rest' => true,
        ));

        // 類型分類
        register_taxonomy('anime_genre', 'anime', array(
            'labels' => array(
                'name' => '類型',
                'singular_name' => '類型',
                'search_items' => '搜尋類型',
                'all_items' => '所有類型',
                'edit_item' => '編輯類型',
                'add_new_item' => '新增類型',
                'menu_name' => '類型',
            ),
            'hierarchical' => false,
            'public' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'genre'),
            'show_in_rest' => true,
        ));

        // 製作公司分類
        register_taxonomy('anime_studio', 'anime', array(
            'labels' => array(
                'name' => '製作公司',
                'singular_name' => '製作公司',
                'search_items' => '搜尋製作公司',
                'all_items' => '所有製作公司',
                'edit_item' => '編輯製作公司',
                'add_new_item' => '新增製作公司',
                'menu_name' => '製作公司',
            ),
            'hierarchical' => false,
            'public' => true,
            'show_ui' => true,
            'show_admin_column' => false,
            'query_var' => true,
            'rewrite' => array('slug' => 'studio'),
            'show_in_rest' => true,
        ));
    }

    /**
     * 自訂後台列表欄位
     */
    public function add_admin_columns($columns) {
        $new_columns = array();

        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;

            if ($key === 'title') {
                $new_columns['anime_cover'] = '封面';
                $new_columns['anime_anilist_id'] = 'AniList ID';
                $new_columns['anime_score'] = '評分';
                $new_columns['anime_season'] = '季度';
                $new_columns['anime_sync'] = '最後同步';
            }
        }

        return $new_columns;
    }

    /**
     * 渲染後台列表欄位內容
     */
    public function render_admin_columns($column, $post_id) {
        switch ($column) {
            case 'anime_cover':
                $cover_url = get_post_meta($post_id, 'anime_cover_url', true);
                if ($cover_url) {
                    echo '<img src="' . esc_url($cover_url) . '" ';
                    echo 'style="width:40px;height:57px;object-fit:cover;border-radius:4px;">';
                } else {
                    echo '—';
                }
                break;

            case 'anime_anilist_id':
                $id = get_post_meta($post_id, 'anime_id_anilist', true);
                if ($id) {
                    echo '<a href="https://anilist.co/anime/' . esc_attr($id) . '" ';
                    echo 'target="_blank">' . esc_html($id) . '</a>';
                } else {
                    echo '—';
                }
                break;

            case 'anime_score':
                $score = get_post_meta($post_id, 'anime_score_anilist', true);
                echo $score ? '<strong>' . esc_html($score) . '</strong>/100' : '—';
                break;

            case 'anime_season':
                $season = get_post_meta($post_id, 'anime_season', true);
                $year = get_post_meta($post_id, 'anime_year', true);
                $season_map = array(
                    'WINTER' => '冬', 'SPRING' => '春',
                    'SUMMER' => '夏', 'FALL' => '秋'
                );
                if ($year && $season) {
                    echo esc_html($year . ' ' . ($season_map[$season] ?? $season));
                } else {
                    echo '—';
                }
                break;

            case 'anime_sync':
                $sync = get_post_meta($post_id, 'anime_last_sync', true);
                echo $sync ? esc_html(date('Y-m-d', strtotime($sync))) : '—';
                break;
        }
    }

    /**
     * 自訂後台更新訊息
     */
    public function custom_messages($messages) {
        $post = get_post();

        $messages['anime'] = array(
            0 => '',
            1 => '動畫已更新。<a href="' . esc_url(get_permalink($post->ID)) . '">查看動畫</a>',
            2 => '自訂欄位已更新。',
            3 => '自訂欄位已刪除。',
            4 => '動畫已更新。',
            5 => isset($_GET['revision']) ? '動畫已還原到修訂版本。' : false,
            6 => '動畫已發布。<a href="' . esc_url(get_permalink($post->ID)) . '">查看動畫</a>',
            7 => '動畫已儲存。',
            8 => '動畫已提交審核。',
            9 => '動畫已排程發布。',
            10 => '動畫草稿已更新。',
        );

        return $messages;
    }
}
