<?php
/**
 * Review Queue Manager
 * 
 * @package Anime_Sync_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class Anime_Sync_Review_Queue {
    
    /**
     * Database object
     */
    private $wpdb;
    
    /**
     * Table name
     */
    private $table_name;
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_name = $wpdb->prefix . 'anime_review_queue';
    }
    
    /**
     * Add item to review queue
     * 
     * @param int $anilist_id AniList ID
     * @param array $api_data Complete API data
     * @param string $source Import source (manual/auto/season)
     * @return int|false Queue ID or false on failure
     */
    public function add($anilist_id, $api_data, $source = 'manual') {
        // 檢查是否已存在
        $exists = $this->get_item_by_anilist_id($anilist_id);
        if ($exists) {
            return false;
        }
        
        // 壓縮 JSON 資料
        $json_data = json_encode($api_data, JSON_UNESCAPED_UNICODE);
        $compressed_data = gzcompress($json_data, 9);
        
        // 提取標題（優先繁中）
        $title = '';
        if (!empty($api_data['title']['chinese_traditional'])) {
            $title = $api_data['title']['chinese_traditional'];
        } elseif (!empty($api_data['title']['native'])) {
            $title = $api_data['title']['native'];
        } elseif (!empty($api_data['title']['romaji'])) {
            $title = $api_data['title']['romaji'];
        }
        
        // 插入資料庫
        $result = $this->wpdb->insert(
            $this->table_name,
            array(
                'anilist_id' => absint($anilist_id),
                'api_data' => $compressed_data,
                'status' => 'pending',
                'source' => sanitize_text_field($source),
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            return false;
        }
        
        return $this->wpdb->insert_id;
    }
    
    /**
     * Get queue items with pagination
     * 
     * @param int $page Page number
     * @param int $per_page Items per page
     * @param string $status Filter by status
     * @return array Queue items
     */
    public function get_items($page = 1, $per_page = 20, $status = 'pending') {
        $offset = ($page - 1) * $per_page;
        
        $where = '';
        if (!empty($status)) {
            $where = $this->wpdb->prepare('WHERE status = %s', $status);
        }
        
        $query = "SELECT id, anilist_id, status, source, created_at, 
                  JSON_EXTRACT(api_data, '$.title.chinese_traditional') as title_tw
                  FROM {$this->table_name}
                  {$where}
                  ORDER BY created_at DESC
                  LIMIT %d OFFSET %d";
        
        $results = $this->wpdb->get_results(
            $this->wpdb->prepare($query, $per_page, $offset),
            ARRAY_A
        );
        
        // 解壓縮並解析資料
        foreach ($results as &$item) {
            if (!empty($item['title_tw'])) {
                $item['title_tw'] = trim($item['title_tw'], '"');
            }
        }
        
        return $results;
    }
    
    /**
     * Get single queue item
     * 
     * @param int $queue_id Queue ID
     * @return array|null Item data or null
     */
    public function get_item($queue_id) {
        $query = $this->wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            absint($queue_id)
        );
        
        $item = $this->wpdb->get_row($query, ARRAY_A);
        
        if (!$item) {
            return null;
        }
        
        // 解壓縮 JSON
        if (!empty($item['api_data'])) {
            $decompressed = gzuncompress($item['api_data']);
            $item['api_data'] = json_decode($decompressed, true);
        }
        
        return $item;
    }
    
    /**
     * Get item by AniList ID
     * 
     * @param int $anilist_id AniList ID
     * @return array|null Item data or null
     */
    public function get_item_by_anilist_id($anilist_id) {
        $query = $this->wpdb->prepare(
            "SELECT id FROM {$this->table_name} WHERE anilist_id = %d",
            absint($anilist_id)
        );
        
        $item_id = $this->wpdb->get_var($query);
        
        if (!$item_id) {
            return null;
        }
        
        return $this->get_item($item_id);
    }
    
    /**
     * Update item status
     * 
     * @param int $queue_id Queue ID
     * @param string $new_status New status
     * @param int $wp_post_id Optional WordPress post ID
     * @return bool Success
     */
    public function update_status($queue_id, $new_status, $wp_post_id = null) {
        $data = array(
            'status' => sanitize_text_field($new_status)
        );
        
        if ($wp_post_id) {
            $data['wp_post_id'] = absint($wp_post_id);
        }
        
        $result = $this->wpdb->update(
            $this->table_name,
            $data,
            array('id' => absint($queue_id)),
            array('%s', '%d'),
            array('%d')
        );
        
        return $result !== false;
    }
    
    /**
     * Delete queue item
     * 
     * @param int $queue_id Queue ID
     * @return bool Success
     */
    public function delete($queue_id) {
        $result = $this->wpdb->delete(
            $this->table_name,
            array('id' => absint($queue_id)),
            array('%d')
        );
        
        return $result !== false;
    }
    
    /**
     * Get queue count
     * 
     * @param string $status Optional status filter
     * @return int Count
     */
    public function get_count($status = null) {
        $where = '';
        if (!empty($status)) {
            $where = $this->wpdb->prepare('WHERE status = %s', $status);
        }
        
        $query = "SELECT COUNT(*) FROM {$this->table_name} {$where}";
        
        return (int) $this->wpdb->get_var($query);
    }
    
    /**
     * Batch delete items
     * 
     * @param array $queue_ids Array of queue IDs
     * @return int Number of deleted items
     */
    public function batch_delete($queue_ids) {
        if (empty($queue_ids) || !is_array($queue_ids)) {
            return 0;
        }
        
        $count = 0;
        foreach ($queue_ids as $id) {
            if ($this->delete($id)) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Batch approve items
     * 
     * @param array $queue_ids Array of queue IDs
     * @return int Number of approved items
     */
    public function batch_approve($queue_ids) {
        if (empty($queue_ids) || !is_array($queue_ids)) {
            return 0;
        }
        
        $count = 0;
        foreach ($queue_ids as $id) {
            if ($this->update_status($id, 'approved')) {
                $count++;
            }
        }
        
        return $count;
    }
}
