<?php
/**
 * 檔案名稱: includes/class-import-manager.php
 *
 * 用途:
 *   管理所有動畫匯入流程，包含：
 *   - 單一匯入（輸入 AniList ID → 直接建立草稿）
 *   - 批次匯入（多個 AniList ID → 逐一建立草稿）
 *   - 季度匯入（指定年份＋季度 → 查詢所有 ID → 批次建立草稿）
 *   - 季度驗證（比對已發布/草稿與季度完整清單，找出缺漏）
 *   - 自動更新排程（每日集數/狀態、每週評分、完結後21天OP/ED）
 *
 * 設計原則:
 *   - 匯入結果統一建立「草稿（draft）」，不直接發布。
 *   - 所有欄位寫入使用統一 anime_ 前綴（方案 B）。
 *   - 自動更新只修改系統欄位，跳過 anime_locked_fields 中標記的欄位。
 *   - 每週評分更新使用分批 Cron 機制，避免單次執行超過 PHP 時間限制。
 *   - post_tag 自動產生：中文標題、日文原名、Romaji、前5位聲優、類型標籤。
 *   - Taxonomy 自動綁定：anime_genre（類型）、anime_season（季度）、
 *     anime_studio（製作公司）。
 *   - Slug 使用 Romaji 標題，經過完整的特殊字元清理。
 *
 * 權限控制:
 *   - 單一匯入、批次匯入：manage_anime（Editor 角色以上）
 *   - 季度匯入、季度驗證：manage_options（管理員）
 *   - 自動更新 Cron：無需人工操作
 *
 * Cron 排程（在 anime-sync-pro.php 主檔中註冊）:
 *   anime_sync_daily_update   → 每天 03:00 → update_airing_episodes()
 *   anime_sync_weekly_update  → 每週一 04:00 → update_ratings_batch()
 *   anime_sync_rating_batch   → 單次事件（分批） → process_rating_batch()
 *   anime_sync_refetch_themes → 單次事件（完結後21天） → refetch_themes()
 *
 * 依賴:
 *   - Anime_Sync_API_Handler
 *   - Anime_Sync_ID_Mapper
 *   - Anime_Sync_ACF_Fields
 *   - Anime_Sync_CN_Converter
 *   - Anime_Sync_Error_Logger
 *
 * @package    AnimeSyncPro
 * @subpackage ImportManager
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Anime_Sync_Import_Manager
 */
class Anime_Sync_Import_Manager {

    // =========================================================================
    // 常數
    // =========================================================================

    /** 每批次最多匯入數量 */
    const BATCH_LIMIT = 100;

    /** 每筆匯入間的延遲（微秒）：3 秒（AniList 30 req/min 限制） */
    const IMPORT_INTERVAL_US = 3000000;

    /** 每批次記憶體清理間隔（每 N 筆清理一次） */
    const MEMORY_CLEANUP_INTERVAL = 15;

    /** 每週評分更新每批處理數量 */
    const RATING_BATCH_SIZE = 25;

    /** 評分批次間隔（秒）：避免連續執行超出時限 */
    const RATING_BATCH_INTERVAL = 60;

    /** Slug 最大長度（字元） */
    const SLUG_MAX_LENGTH = 80;

    // =========================================================================
    // 依賴物件
    // =========================================================================

    /** @var Anime_Sync_API_Handler */
    private Anime_Sync_API_Handler $api_handler;

    // =========================================================================
    // 建構函式
    // =========================================================================

    /**
     * @param Anime_Sync_API_Handler $api_handler API 處理器實例。
     */
    public function __construct( Anime_Sync_API_Handler $api_handler ) {
        $this->api_handler = $api_handler;

        // 掛載 Cron 動作
        add_action( 'anime_sync_daily_update',   [ $this, 'update_airing_episodes' ] );
        add_action( 'anime_sync_weekly_update',  [ $this, 'update_ratings_batch' ] );
        add_action( 'anime_sync_rating_batch',   [ $this, 'process_rating_batch' ] );
        add_action( 'anime_sync_refetch_themes', [ $this, 'refetch_themes' ] );
    }

    // =========================================================================
    // 單一匯入
    // =========================================================================

    /**
     * 匯入單一動畫（輸入 AniList ID，直接建立草稿）。
     *
     * 流程：
     *   1. 驗證 AniList ID（必須為正整數）
     *   2. 檢查是否已存在（避免重複匯入）
     *   3. 呼叫 API Handler 取得完整資料
     *   4. 建立 WP 草稿文章
     *   5. 寫入所有 ACF / post meta 欄位
     *   6. 綁定 Taxonomy
     *   7. 設定 post_tag
     *   8. 記錄 last_sync 時間
     *
     * @param int      $anilist_id  AniList 作品 ID。
     * @param int|null $bangumi_id  已知 Bangumi ID（選填，跳過三層查找）。
     * @return array {
     *     @type bool   $success   是否成功。
     *     @type string $message   結果訊息。
     *     @type int    $post_id   建立的文章 ID（失敗時為 0）。
     *     @type string $edit_url  後台編輯連結（失敗時為空）。
     * }
     */
    public function import_single( int $anilist_id, ?int $bangumi_id = null ): array {
        // ── 驗證 ─────────────────────────────────────────────────────────────
        if ( $anilist_id <= 0 ) {
            return $this->result( false, 'AniList ID 必須為正整數。' );
        }

        // ── 重複檢查 ──────────────────────────────────────────────────────────
        $existing = $this->find_post_by_anilist_id( $anilist_id );
        if ( $existing ) {
            return $this->result(
                false,
                sprintf( '此作品已存在（文章 ID：%d）。', $existing ),
                $existing,
                get_edit_post_link( $existing, 'raw' )
            );
        }

        // ── 取得 API 資料 ─────────────────────────────────────────────────────
        $data = $this->api_handler->get_all_data( $anilist_id, $bangumi_id );

        if ( ! empty( $data['errors']['anilist'] ) ) {
            return $this->result( false, 'AniList 資料取得失敗：' . $data['errors']['anilist'] );
        }

        // ── 建立草稿 ──────────────────────────────────────────────────────────
        $post_id = $this->create_draft_post( $data );

        if ( is_wp_error( $post_id ) ) {
            return $this->result( false, '文章建立失敗：' . $post_id->get_error_message() );
        }

        // ── 寫入欄位 ──────────────────────────────────────────────────────────
        $this->save_post_meta( $post_id, $data );

        // ── 綁定 Taxonomy ─────────────────────────────────────────────────────
        $this->assign_taxonomies( $post_id, $data );

        // ── 設定 post_tag ─────────────────────────────────────────────────────
        $this->assign_post_tags( $post_id, $data );

        // ── 設定特色圖片（封面）──────────────────────────────────────────────
        if ( ! empty( $data['anime_cover_image'] ) ) {
            update_post_meta( $post_id, '_anime_cover_image_url', $data['anime_cover_image'] );
        }

        // ── 記錄日誌 ──────────────────────────────────────────────────────────
        if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
            Anime_Sync_Error_Logger::info(
                'import_manager',
                sprintf(
                    '單一匯入成功。AniList ID: %d，文章 ID: %d，標題: %s',
                    $anilist_id,
                    $post_id,
                    $data['anime_title_chinese'] ?: $data['anime_title_romaji']
                )
            );
        }

        return $this->result(
            true,
            sprintf( '「%s」匯入成功，已建立草稿。', $data['anime_title_chinese'] ?: $data['anime_title_romaji'] ),
            $post_id,
            get_edit_post_link( $post_id, 'raw' )
        );
    }

    // =========================================================================
    // 批次匯入
    // =========================================================================

    /**
     * 批次匯入多個動畫。
     * 每筆匯入間隔 3 秒（遵守 AniList 30 req/min 限制）。
     * 每 15 筆清理一次記憶體。
     *
     * @param array $anilist_ids  AniList ID 陣列（最多 BATCH_LIMIT 筆）。
     * @param callable|null $progress_callback 進度回呼函式（供 AJAX 串流使用）。
     *                                          接收參數：( int $current, int $total, array $result )
     * @return array {
     *     @type int   $total    總數。
     *     @type int   $imported 成功匯入數。
     *     @type int   $skipped  已存在跳過數。
     *     @type int   $failed   失敗數。
     *     @type array $details  每筆詳細結果。
     * }
     */
    public function import_batch( array $anilist_ids, ?callable $progress_callback = null ): array {
        $anilist_ids = array_values( array_unique( array_map( 'intval', $anilist_ids ) ) );
        $anilist_ids = array_slice( $anilist_ids, 0, self::BATCH_LIMIT );

        $total    = count( $anilist_ids );
        $imported = 0;
        $skipped  = 0;
        $failed   = 0;
        $details  = [];

        foreach ( $anilist_ids as $index => $anilist_id ) {
            $result = $this->import_single( $anilist_id );

            if ( $result['success'] ) {
                $imported++;
            } elseif ( str_contains( $result['message'], '已存在' ) ) {
                $skipped++;
            } else {
                $failed++;
            }

            $details[] = array_merge( [ 'anilist_id' => $anilist_id ], $result );

            // 進度回呼
            if ( null !== $progress_callback ) {
                call_user_func( $progress_callback, $index + 1, $total, $result );
            }

            // 最後一筆不需等待
            if ( $index < $total - 1 ) {
                usleep( self::IMPORT_INTERVAL_US );
            }

            // 定期清理記憶體
            if ( 0 === ( ( $index + 1 ) % self::MEMORY_CLEANUP_INTERVAL ) ) {
                $this->cleanup_memory();
            }
        }

        return compact( 'total', 'imported', 'skipped', 'failed', 'details' );
    }

    // =========================================================================
    // 季度匯入
    // =========================================================================

    /**
     * 季度匯入：查詢指定年份＋季度的所有 AniList 作品，過濾已存在的，
     * 再批次匯入缺漏的作品。
     *
     * @param int    $year    年份（例：2026）。
     * @param string $season  季度（WINTER / SPRING / SUMMER / FALL）。
     * @param array  $formats 作品類型篩選。
     * @param callable|null $progress_callback 進度回呼。
     * @return array {
     *     @type int   $total_in_season  該季度 AniList 上的作品總數。
     *     @type int   $already_exists   已存在的作品數。
     *     @type int   $to_import        需要匯入的作品數。
     *     @type int   $imported         成功匯入數。
     *     @type int   $failed           失敗數。
     *     @type array $season_list      該季度完整清單（含每筆 anilist_id、title）。
     *     @type array $import_result    批次匯入結果。
     * }
     */
    public function import_season(
        int $year,
        string $season,
        array $formats = [ 'TV', 'ONA', 'MOVIE', 'OVA', 'SPECIAL' ],
        ?callable $progress_callback = null
    ): array {

        // ── 步驟一：查詢季度清單 ─────────────────────────────────────────────
        $season_list = $this->api_handler->get_season_anime_ids( $year, $season, $formats );
        $total       = count( $season_list );

        if ( 0 === $total ) {
            return [
                'total_in_season' => 0,
                'already_exists'  => 0,
                'to_import'       => 0,
                'imported'        => 0,
                'failed'          => 0,
                'season_list'     => [],
                'import_result'   => [],
            ];
        }

        // ── 步驟二：過濾已存在的 ─────────────────────────────────────────────
        $existing_ids   = $this->get_existing_anilist_ids();
        $new_ids        = [];
        $already_exists = 0;

        foreach ( $season_list as $item ) {
            if ( in_array( $item['anilist_id'], $existing_ids, true ) ) {
                $already_exists++;
            } else {
                $new_ids[] = $item['anilist_id'];
            }
        }

        // ── 步驟三：批次匯入新作品 ───────────────────────────────────────────
        $import_result = [];
        if ( ! empty( $new_ids ) ) {
            $import_result = $this->import_batch( $new_ids, $progress_callback );
        }

        return [
            'total_in_season' => $total,
            'already_exists'  => $already_exists,
            'to_import'       => count( $new_ids ),
            'imported'        => $import_result['imported'] ?? 0,
            'failed'          => $import_result['failed'] ?? 0,
            'season_list'     => $season_list,
            'import_result'   => $import_result,
        ];
    }

    // =========================================================================
    // 季度驗證
    // =========================================================================

    /**
     * 驗證指定季度的收錄完整性。
     * 比對 AniList 上的完整清單與本站已發布/草稿的文章，
     * 回傳「已發布」「草稿待審」「缺漏（未匯入）」三個清單。
     *
     * @param int    $year    年份。
     * @param string $season  季度。
     * @param array  $formats 作品類型篩選。
     * @return array {
     *     @type array $published  已發布的作品清單。
     *     @type array $drafts     草稿/待審的作品清單。
     *     @type array $missing    缺漏（未匯入）的作品清單。
     *     @type int   $total      AniList 上的總數。
     * }
     */
    public function verify_season(
        int $year,
        string $season,
        array $formats = [ 'TV', 'ONA', 'MOVIE', 'OVA', 'SPECIAL' ]
    ): array {
        $season_list = $this->api_handler->get_season_anime_ids( $year, $season, $formats );

        $published = [];
        $drafts    = [];
        $missing   = [];

        foreach ( $season_list as $item ) {
            $post_id = $this->find_post_by_anilist_id( $item['anilist_id'] );

            if ( ! $post_id ) {
                $missing[] = $item;
                continue;
            }

            $status = get_post_status( $post_id );
            $entry  = array_merge( $item, [
                'post_id'  => $post_id,
                'edit_url' => get_edit_post_link( $post_id, 'raw' ),
            ] );

            if ( 'publish' === $status ) {
                $published[] = $entry;
            } else {
                $drafts[] = $entry;
            }
        }

        return [
            'published' => $published,
            'drafts'    => $drafts,
            'missing'   => $missing,
            'total'     => count( $season_list ),
        ];
    }

    // =========================================================================
    // 自動更新：每日集數 / 狀態更新
    // =========================================================================

    /**
     * 每日 Cron：更新所有「播出中（RELEASING）」動畫的集數與狀態。
     *
     * 更新欄位：
     *   - anime_episodes_aired（已播集數）
     *   - anime_status（播出狀態）
     *   - anime_next_airing（下一集播出時間）
     *   - anime_episodes（完結時最終集數）
     *   - anime_end_date（完結日期）
     *
     * 若狀態由 RELEASING → FINISHED，額外排程 21 天後的 OP/ED 補抓。
     *
     * @return array 更新結果統計。
     */
    public function update_airing_episodes(): array {
        $releasing_posts = $this->get_posts_by_status( 'RELEASING' );
        $updated = 0;
        $errors  = 0;

        foreach ( $releasing_posts as $post_id ) {
            $anilist_id = (int) get_post_meta( $post_id, 'anime_anilist_id', true );
            if ( $anilist_id <= 0 ) {
                continue;
            }

            // 只呼叫 AniList，取得最新狀態（不需要 Bangumi / AnimeThemes）
            $anilist_data = $this->api_handler->get_anilist_data( $anilist_id );
            if ( is_wp_error( $anilist_data ) ) {
                $errors++;
                continue;
            }

            $old_status = get_post_meta( $post_id, 'anime_status', true );
            $new_status = $anilist_data['status'] ?? 'RELEASING';

            // 更新欄位（若未被鎖定）
            $this->update_meta_if_unlocked( $post_id, 'anime_status', $new_status );
            $this->update_meta_if_unlocked( $post_id, 'anime_episodes', $anilist_data['episodes'] ?? 0 );

            // 已播集數
            $aired = 0;
            if ( ! empty( $anilist_data['nextAiringEpisode']['episode'] ) ) {
                $aired = (int) $anilist_data['nextAiringEpisode']['episode'] - 1;
            } elseif ( 'FINISHED' === $new_status ) {
                $aired = (int) ( $anilist_data['episodes'] ?? 0 );
            }
            $this->update_meta_if_unlocked( $post_id, 'anime_episodes_aired', $aired );

            // 下一集時間
            $next_airing = '';
            if ( ! empty( $anilist_data['nextAiringEpisode']['airingAt'] ) ) {
                $ts          = (int) $anilist_data['nextAiringEpisode']['airingAt'];
                $next_airing = wp_date( 'Y-m-d H:i', $ts, new DateTimeZone( 'Asia/Taipei' ) );
            }
            $this->update_meta_if_unlocked( $post_id, 'anime_next_airing', $next_airing );

            // 完結日期
            if ( 'FINISHED' === $new_status ) {
                $end_date = '';
                if ( ! empty( $anilist_data['endDate'] ) ) {
                    $end_date = $this->format_anilist_date( $anilist_data['endDate'] );
                }
                $this->update_meta_if_unlocked( $post_id, 'anime_end_date', $end_date );
            }

            // 更新最後更新時間
            update_post_meta( $post_id, 'anime_last_updated', current_time( 'mysql' ) );

            // 狀態從 RELEASING 變為 FINISHED：排程 OP/ED 補抓
            if ( 'RELEASING' === $old_status && 'FINISHED' === $new_status ) {
                $refetch_time = time() + ( 21 * DAY_IN_SECONDS );
                wp_schedule_single_event(
                    $refetch_time,
                    'anime_sync_refetch_themes',
                    [ $post_id ]
                );

                if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                    Anime_Sync_Error_Logger::info(
                        'import_manager',
                        sprintf(
                            '文章 ID %d（AniList ID: %d）已完結，已排程 21 天後補抓 OP/ED（%s）。',
                            $post_id,
                            $anilist_id,
                            wp_date( 'Y-m-d H:i', $refetch_time )
                        )
                    );
                }
            }

            $updated++;

            // AniList 請求間隔 3 秒
            usleep( self::IMPORT_INTERVAL_US );
        }

        // 記錄最後執行時間
        update_option( 'anime_sync_daily_last_run', current_time( 'mysql' ), false );

        return [
            'total'   => count( $releasing_posts ),
            'updated' => $updated,
            'errors'  => $errors,
        ];
    }

    // =========================================================================
    // 自動更新：每週評分更新（分批 Cron）
    // =========================================================================

    /**
     * 每週 Cron 觸發點：初始化評分更新分批任務。
     * 將所有已發布文章 ID 存入 WP Options，
     * 然後排程第一批處理（process_rating_batch）。
     *
     * @return void
     */
    public function update_ratings_batch(): void {
        $post_ids = $this->get_all_published_post_ids();

        if ( empty( $post_ids ) ) {
            return;
        }

        // 儲存待處理佇列
        update_option( 'anime_sync_rating_queue', $post_ids, false );
        update_option( 'anime_sync_rating_queue_offset', 0, false );
        update_option( 'anime_sync_rating_batch_started', current_time( 'mysql' ), false );

        // 立即排程第一批
        wp_schedule_single_event( time() + 5, 'anime_sync_rating_batch' );

        if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
            Anime_Sync_Error_Logger::info(
                'import_manager',
                sprintf( '週更評分任務啟動。共 %d 部作品待更新。', count( $post_ids ) )
            );
        }
    }

    /**
     * 處理一批評分更新（每次 RATING_BATCH_SIZE 筆）。
     * 完成後若仍有剩餘，排程下一批（間隔 RATING_BATCH_INTERVAL 秒）。
     *
     * @return array 本批次處理結果。
     */
    public function process_rating_batch(): array {
        $queue  = get_option( 'anime_sync_rating_queue', [] );
        $offset = (int) get_option( 'anime_sync_rating_queue_offset', 0 );

        if ( empty( $queue ) ) {
            return [ 'status' => 'queue_empty' ];
        }

        $batch    = array_slice( $queue, $offset, self::RATING_BATCH_SIZE );
        $updated  = 0;
        $errors   = 0;

        foreach ( $batch as $post_id ) {
            $anilist_id  = (int) get_post_meta( $post_id, 'anime_anilist_id', true );
            $bangumi_id  = (int) get_post_meta( $post_id, 'anime_bangumi_id', true );
            $mal_id      = (int) get_post_meta( $post_id, 'anime_mal_id', true );

            // AniList 評分
            if ( $anilist_id > 0 ) {
                $anilist_data = $this->api_handler->get_anilist_data( $anilist_id );
                if ( ! is_wp_error( $anilist_data ) ) {
                    $this->update_meta_if_unlocked( $post_id, 'anime_score_anilist', $anilist_data['averageScore'] ?? 0 );
                    $this->update_meta_if_unlocked( $post_id, 'anime_popularity', $anilist_data['popularity'] ?? 0 );
                    $updated++;
                } else {
                    $errors++;
                }
                usleep( self::IMPORT_INTERVAL_US );
            }

            // Bangumi 評分
            if ( $bangumi_id > 0 ) {
                usleep( 1200000 ); // 1.2 秒
                $bgm_data = $this->api_handler->get_bangumi_subject( $bangumi_id );
                if ( ! is_wp_error( $bgm_data ) ) {
                    $bgm_score = $bgm_data['rating']['score'] ?? 0;
                    $this->update_meta_if_unlocked( $post_id, 'anime_score_bangumi', $bgm_score );
                }
            }

            // MAL 評分（Jikan）
            if ( $mal_id > 0 ) {
                usleep( 1000000 ); // 1 秒
                $jikan_data = $this->api_handler->get_jikan_data( $mal_id );
                if ( ! is_wp_error( $jikan_data ) ) {
                    $this->update_meta_if_unlocked( $post_id, 'anime_score_mal', $jikan_data['score'] ?? 0 );
                }
            }

            update_post_meta( $post_id, 'anime_last_updated', current_time( 'mysql' ) );
        }

        // 更新 offset
        $new_offset = $offset + count( $batch );
        update_option( 'anime_sync_rating_queue_offset', $new_offset, false );

        // 是否還有下一批
        $has_more = $new_offset < count( $queue );
        if ( $has_more ) {
            wp_schedule_single_event(
                time() + self::RATING_BATCH_INTERVAL,
                'anime_sync_rating_batch'
            );
        } else {
            // 全部完成，清理佇列
            delete_option( 'anime_sync_rating_queue' );
            delete_option( 'anime_sync_rating_queue_offset' );
            update_option( 'anime_sync_weekly_last_run', current_time( 'mysql' ), false );

            if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
                Anime_Sync_Error_Logger::info(
                    'import_manager',
                    '週更評分任務全部完成。'
                );
            }
        }

        return [
            'status'    => $has_more ? 'in_progress' : 'completed',
            'offset'    => $new_offset,
            'total'     => count( $queue ),
            'updated'   => $updated,
            'errors'    => $errors,
        ];
    }

    // =========================================================================
    // 自動更新：OP/ED 補抓（完結後21天）
    // =========================================================================

    /**
     * 補抓指定文章的 OP/ED 資料（完結後 21 天觸發）。
     *
     * @param int $post_id WordPress 文章 ID。
     * @return bool 成功返回 true。
     */
    public function refetch_themes( int $post_id ): bool {
        if ( Anime_Sync_ACF_Fields::is_field_locked( $post_id, 'anime_themes_json' ) ) {
            return false; // 已鎖定，跳過
        }

        $mal_id = (int) get_post_meta( $post_id, 'anime_mal_id', true );
        if ( $mal_id <= 0 ) {
            return false;
        }

        $themes = $this->api_handler->get_animethemes_data( $mal_id );
        if ( is_wp_error( $themes ) || empty( $themes ) ) {
            return false;
        }

        update_post_meta(
            $post_id,
            'anime_themes_json',
            wp_json_encode( $themes, JSON_UNESCAPED_UNICODE )
        );
        update_post_meta( $post_id, 'anime_last_updated', current_time( 'mysql' ) );

        if ( class_exists( 'Anime_Sync_Error_Logger' ) ) {
            Anime_Sync_Error_Logger::info(
                'import_manager',
                sprintf( 'OP/ED 補抓完成。文章 ID: %d，共 %d 首。', $post_id, count( $themes ) )
            );
        }

        return true;
    }

    // =========================================================================
    // 文章建立與欄位寫入
    // =========================================================================

    /**
     * 建立 anime 草稿文章。
     *
     * @param array $data 合併後的 API 資料陣列。
     * @return int|WP_Error 成功返回文章 ID，失敗返回 WP_Error。
     */
    private function create_draft_post( array $data ): int|WP_Error {
        $title = $data['anime_title_chinese'] ?: $data['anime_title_romaji'] ?: $data['anime_title_native'];
        $slug  = $this->generate_slug( $data['anime_title_romaji'] ?: $data['anime_title_native'] );

        $post_args = [
            'post_title'   => sanitize_text_field( $title ),
            'post_name'    => $slug,
            'post_status'  => 'draft',
            'post_type'    => 'anime',
            'post_content' => '',
            'post_author'  => get_current_user_id() ?: 1,
        ];

        $post_id = wp_insert_post( $post_args, true );
        return $post_id;
    }

    /**
     * 將 API 資料陣列中所有 anime_ 欄位儲存為 post meta。
     * 使用 update_post_meta（冪等：存在則更新，不存在則新增）。
     *
     * @param int   $post_id WordPress 文章 ID。
     * @param array $data    合併後的 API 資料陣列。
     * @return void
     */
    private function save_post_meta( int $post_id, array $data ): void {
        // 所有以 anime_ 開頭的欄位
        $meta_keys = [
            'anime_anilist_id', 'anime_mal_id', 'anime_bangumi_id',
            'anime_title_chinese', 'anime_title_native', 'anime_title_romaji', 'anime_title_english',
            'anime_format', 'anime_status', 'anime_source',
            'anime_season', 'anime_season_year',
            'anime_episodes', 'anime_episodes_aired', 'anime_duration',
            'anime_start_date', 'anime_end_date', 'anime_next_airing',
            'anime_score_anilist', 'anime_score_mal', 'anime_score_bangumi',
            'anime_popularity', 'anime_ranking',
            'anime_synopsis_chinese', 'anime_synopsis_english',
            'anime_cover_image', 'anime_banner_image', 'anime_trailer_url',
            'anime_studio',
            'anime_staff_json', 'anime_cast_json',
            'anime_themes_json', 'anime_streaming_json',
            'anime_official_site', 'anime_twitter_url', 'anime_wikipedia_url', 'anime_tiktok_url',
            'anime_tw_distributor', 'anime_tw_broadcast',
            'anime_last_sync', 'anime_last_updated',
        ];

        foreach ( $meta_keys as $key ) {
            if ( array_key_exists( $key, $data ) ) {
                update_post_meta( $post_id, $key, $data[ $key ] );
            }
        }
    }

    /**
     * 綁定 Taxonomy 分類：anime_genre、anime_season（季度）、anime_studio。
     *
     * @param int   $post_id WordPress 文章 ID。
     * @param array $data    合併後的 API 資料陣列。
     * @return void
     */
    private function assign_taxonomies( int $post_id, array $data ): void {
        // 類型（anime_genre）
        if ( ! empty( $data['_genres'] ) ) {
            $genres_zh = $this->translate_genres( $data['_genres'] );
            wp_set_object_terms( $post_id, $genres_zh, 'anime_genre', false );
        }

        // 季度（anime_season）：格式「2026 春季」
        if ( ! empty( $data['anime_season_year'] ) && ! empty( $data['anime_season'] ) ) {
            $season_label = $this->translate_season(
                $data['anime_season'],
                (int) $data['anime_season_year']
            );
            wp_set_object_terms( $post_id, [ $season_label ], 'anime_season', false );
        }

        // 製作公司（anime_studio）
        if ( ! empty( $data['anime_studio'] ) ) {
            $studios = array_map( 'trim', explode( '、', $data['anime_studio'] ) );
            $studios = array_filter( $studios );
            wp_set_object_terms( $post_id, $studios, 'anime_studio', false );
        }
    }

    /**
     * 設定 post_tag（WordPress 標準標籤）。
     *
     * 包含：
     *   - 中文標題
     *   - 日文原名
     *   - Romaji 標題
     *   - 前 5 位聲優日文姓名
     *   - 類型繁體中文標籤
     *   - 作品類型標籤（電視動畫 / 劇場版等）
     *
     * @param int   $post_id WordPress 文章 ID。
     * @param array $data    合併後的 API 資料陣列。
     * @return void
     */
    private function assign_post_tags( int $post_id, array $data ): void {
        $tags = [];

        // 標題標籤
        if ( ! empty( $data['anime_title_chinese'] ) ) {
            $tags[] = $data['anime_title_chinese'];
        }
        if ( ! empty( $data['anime_title_native'] ) ) {
            $tags[] = $data['anime_title_native'];
        }
        if ( ! empty( $data['anime_title_romaji'] ) ) {
            $tags[] = $data['anime_title_romaji'];
        }

        // 前 5 位聲優
        if ( ! empty( $data['anime_cast_json'] ) ) {
            $cast = json_decode( $data['anime_cast_json'], true );
            if ( is_array( $cast ) ) {
                $va_count = 0;
                foreach ( $cast as $char ) {
                    if ( ! empty( $char['va_name'] ) && $va_count < 5 ) {
                        $tags[] = $char['va_name'];
                        $va_count++;
                    }
                }
            }
        }

        // 類型標籤（繁體中文）
        if ( ! empty( $data['_genres'] ) ) {
            $genres_zh = $this->translate_genres( $data['_genres'] );
            $tags      = array_merge( $tags, $genres_zh );
        }

        // 作品類型標籤
        $format_label = $this->translate_format( $data['anime_format'] ?? 'TV' );
        if ( ! empty( $format_label ) ) {
            $tags[] = $format_label;
        }

        // 清理：去重、去空、限制長度
        $tags = array_unique( array_filter( array_map( 'trim', $tags ) ) );
        $tags = array_values( $tags );

        if ( ! empty( $tags ) ) {
            wp_set_post_tags( $post_id, $tags, false );
        }
    }

    // =========================================================================
    // 輔助：Slug 產生
    // =========================================================================

    /**
     * 從 Romaji 標題產生 WordPress slug。
     *
     * 清理規則：
     *   1. 轉小寫
     *   2. 移除非 ASCII 字元（日文假名、漢字等）
     *   3. 將空白、底線、特殊符號替換為連字號
     *   4. 移除連續連字號
     *   5. 去除首尾連字號
     *   6. 限制最大長度
     *
     * @param string $romaji Romaji 標題字串。
     * @return string        清理後的 slug。
     */
    private function generate_slug( string $romaji ): string {
        if ( empty( $romaji ) ) {
            return 'anime-' . time();
        }

        $slug = mb_strtolower( $romaji, 'UTF-8' );

        // 移除非 ASCII 字元（保留英數、空白、連字號）
        $slug = preg_replace( '/[^\x00-\x7F]+/u', '', $slug );

        // 常見標點替換為連字號
        $slug = preg_replace( '/[\s\.\!\?\:\;\,\'\"\_\(\)\[\]\{\}\/\\\\]+/', '-', $slug );

        // 移除非英數與連字號的字元
        $slug = preg_replace( '/[^a-z0-9\-]/', '', $slug );

        // 合併多個連字號
        $slug = preg_replace( '/-{2,}/', '-', $slug );

        // 去除首尾連字號
        $slug = trim( $slug, '-' );

        // 長度限制
        if ( mb_strlen( $slug ) > self::SLUG_MAX_LENGTH ) {
            $slug = mb_substr( $slug, 0, self::SLUG_MAX_LENGTH, 'UTF-8' );
            $slug = rtrim( $slug, '-' );
        }

        // 若清理後為空，使用時間戳記
        if ( empty( $slug ) ) {
            $slug = 'anime-' . time();
        }

        // 確保唯一性
        return wp_unique_post_slug( $slug, 0, 'draft', 'anime', 0 );
    }

    // =========================================================================
    // 輔助：翻譯標籤
    // =========================================================================

    /**
     * 將 AniList 英文類型陣列翻譯為繁體中文。
     *
     * @param array $genres AniList genres 陣列（英文）。
     * @return array        繁體中文類型陣列。
     */
    private function translate_genres( array $genres ): array {
        $map = [
            'Action'           => '動作',
            'Adventure'        => '冒險',
            'Comedy'           => '喜劇',
            'Drama'            => '劇情',
            'Fantasy'          => '奇幻',
            'Horror'           => '恐怖',
            'Mahou Shoujo'     => '魔法少女',
            'Mecha'            => '機甲',
            'Music'            => '音樂',
            'Mystery'          => '懸疑',
            'Psychological'    => '心理',
            'Romance'          => '戀愛',
            'Sci-Fi'           => '科幻',
            'Slice of Life'    => '日常',
            'Sports'           => '運動',
            'Supernatural'     => '超自然',
            'Thriller'         => '驚悚',
            'Ecchi'            => '輕度成人',
            'Hentai'           => '成人',
            'Boys Love'        => '男男戀愛',
            'Girls Love'       => '百合',
            'Isekai'           => '異世界',
            'Historical'       => '歷史',
            'Military'         => '軍事',
            'Harem'            => '後宮',
            'Game'             => '遊戲',
            'Dementia'         => '奇異',
            'School'           => '校園',
            'Space'            => '太空',
            'Vampire'          => '吸血鬼',
            'Martial Arts'     => '武術',
            'Police'           => '警察',
            'Samurai'          => '武士',
            'Shounen'          => '少年',
            'Shoujo'           => '少女',
            'Seinen'           => '青年',
            'Josei'            => '女性向',
            'Kids'             => '兒童',
        ];

        $result = [];
        foreach ( $genres as $genre ) {
            $result[] = $map[ $genre ] ?? $genre;
        }
        return array_unique( $result );
    }

    /**
     * 將 AniList format 代碼翻譯為繁體中文顯示名稱。
     *
     * @param string $format AniList format 代碼。
     * @return string        繁體中文名稱。
     */
    public function translate_format( string $format ): string {
        $map = [
            'TV'       => '電視動畫',
            'TV_SHORT' => '短篇電視動畫',
            'MOVIE'    => '劇場版',
            'SPECIAL'  => '特別篇',
            'OVA'      => 'OVA',
            'ONA'      => '網路動畫',
            'MUSIC'    => '音樂',
        ];
        return $map[ $format ] ?? $format;
    }

    /**
     * 將 AniList season + year 組合為繁體中文季度標籤。
     *
     * @param string $season      AniList season（WINTER/SPRING/SUMMER/FALL）。
     * @param int    $season_year 年份。
     * @return string             例：「2026 春季」。
     */
    private function translate_season( string $season, int $season_year ): string {
        $season_map = [
            'WINTER' => '冬季',
            'SPRING' => '春季',
            'SUMMER' => '夏季',
            'FALL'   => '秋季',
        ];
        $season_zh = $season_map[ $season ] ?? $season;
        return sprintf( '%d %s', $season_year, $season_zh );
    }

    /**
     * 將 AniList 日期物件格式化為 YYYY-MM-DD 字串。
     *
     * @param array $date AniList 日期物件 {year, month, day}。
     * @return string
     */
    private function format_anilist_date( array $date ): string {
        if ( empty( $date['year'] ) ) {
            return '';
        }
        return sprintf(
            '%04d-%02d-%02d',
            (int) $date['year'],
            (int) ( $date['month'] ?? 1 ),
            (int) ( $date['day'] ?? 1 )
        );
    }

    // =========================================================================
    // 輔助：文章查詢
    // =========================================================================

    /**
     * 以 AniList ID 查找已存在的文章 ID。
     *
     * @param int $anilist_id AniList ID。
     * @return int|null       文章 ID，不存在返回 null。
     */
    private function find_post_by_anilist_id( int $anilist_id ): ?int {
        $query = new WP_Query( [
            'post_type'      => 'anime',
            'post_status'    => [ 'publish', 'draft', 'pending', 'private' ],
            'posts_per_page' => 1,
            'meta_query'     => [
                [
                    'key'     => 'anime_anilist_id',
                    'value'   => $anilist_id,
                    'compare' => '=',
                    'type'    => 'NUMERIC',
                ],
            ],
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ] );

        return ! empty( $query->posts ) ? (int) $query->posts[0] : null;
    }

    /**
     * 取得所有已存在的 AniList ID 清單（用於季度匯入的重複過濾）。
     *
     * @return array int 陣列。
     */
    private function get_existing_anilist_ids(): array {
        global $wpdb;

        $results = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE pm.meta_key = %s
                   AND p.post_type = %s
                   AND p.post_status IN ('publish','draft','pending','private')",
                'anime_anilist_id',
                'anime'
            )
        );

        return array_map( 'intval', $results );
    }

    /**
     * 取得指定播出狀態的所有文章 ID。
     *
     * @param string $status 播出狀態（例：'RELEASING'）。
     * @return array         文章 ID 整數陣列。
     */
    private function get_posts_by_status( string $status ): array {
        $query = new WP_Query( [
            'post_type'      => 'anime',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => [
                [
                    'key'     => 'anime_status',
                    'value'   => $status,
                    'compare' => '=',
                ],
            ],
            'fields'         => 'ids',
            'no_found_rows'  => false,
        ] );

        return array_map( 'intval', $query->posts );
    }

    /**
     * 取得所有已發布的 anime 文章 ID。
     *
     * @return array int 陣列。
     */
    private function get_all_published_post_ids(): array {
        $query = new WP_Query( [
            'post_type'      => 'anime',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => false,
        ] );

        return array_map( 'intval', $query->posts );
    }

    // =========================================================================
    // 輔助：欄位更新（鎖定保護）
    // =========================================================================

    /**
     * 更新 post meta，但若該欄位已被鎖定則跳過。
     *
     * @param int    $post_id  文章 ID。
     * @param string $meta_key meta 鍵名。
     * @param mixed  $value    新值。
     * @return bool            true 表示已更新，false 表示被鎖定跳過。
     */
    private function update_meta_if_unlocked( int $post_id, string $meta_key, mixed $value ): bool {
        if ( Anime_Sync_ACF_Fields::is_field_locked( $post_id, $meta_key ) ) {
            return false;
        }
        update_post_meta( $post_id, $meta_key, $value );
        return true;
    }

    // =========================================================================
    // 輔助：記憶體清理
    // =========================================================================

    /**
     * 清理記憶體：釋放 WordPress 物件快取與轉換器快取。
     * 在批次處理每 N 筆後呼叫。
     *
     * @return void
     */
    private function cleanup_memory(): void {
        // 清除 WP_Query 的全域 post 物件
        wp_cache_flush_group( 'posts' );
        wp_cache_flush_group( 'post_meta' );

        // 釋放 CN Converter 靜態快取（若佔用過多記憶體）
        $memory_usage = memory_get_usage( true );
        $memory_limit = $this->get_memory_limit_bytes();
        if ( $memory_limit > 0 && $memory_usage > $memory_limit * 0.75 ) {
            Anime_Sync_CN_Converter::clear_cache();
        }
    }

    /**
     * 取得 PHP 記憶體上限（bytes）。
     *
     * @return int 記憶體限制 bytes，-1 表示無限制，0 表示無法解析。
     */
    private function get_memory_limit_bytes(): int {
        $limit = ini_get( 'memory_limit' );
        if ( '-1' === $limit ) {
            return -1;
        }
        $unit  = strtolower( substr( $limit, -1 ) );
        $value = (int) $limit;
        switch ( $unit ) {
            case 'g': return $value * 1073741824;
            case 'm': return $value * 1048576;
            case 'k': return $value * 1024;
            default:  return $value;
        }
    }

    // =========================================================================
    // 輔助：標準回傳格式
    // =========================================================================

    /**
     * 產生標準結果陣列。
     *
     * @param bool   $success  是否成功。
     * @param string $message  訊息。
     * @param int    $post_id  文章 ID（選填）。
     * @param string $edit_url 編輯連結（選填）。
     * @return array
     */
    private function result(
        bool $success,
        string $message,
        int $post_id = 0,
        string $edit_url = ''
    ): array {
        return compact( 'success', 'message', 'post_id', 'edit_url' );
    }
}
